document.addEventListener('DOMContentLoaded', function () {
    // Chatbot HTML Structure
    const chatWidget = document.createElement('div');
    chatWidget.className = 'chat-widget';
    chatWidget.innerHTML = `
        <div class="chat-window" id="chatWindow">
            <div class="chat-header">
                <div class="chat-header-info">
                    <div class="chat-avatar">
                        <i class="fas fa-user-tie"></i>
                    </div>
                    <div class="chat-title">
                        <h4>Temple Support</h4>
                        <p>Typically replies in minutes</p>
                    </div>
                </div>
                <button class="chat-close" id="chatClose">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="chat-body" id="chatBody">
                <div class="chat-date">Today</div>
                <div class="chat-message bot">
                    Namaste! 🙏 I'm your personal temple assistant. How can I help you find peace and blessings today?
                </div>
                <div class="quick-replies" id="quickReplies">
                    <button class="quick-reply-btn" onclick="sendQuickReply('Book a Puja')">📅 Book a Puja</button>
                    <button class="quick-reply-btn" onclick="sendQuickReply('Temple Timings')">⏰ Temple Timings</button>
                    <button class="quick-reply-btn" onclick="sendQuickReply('Talk to Priest')">🕉️ Talk to Priest</button>
                </div>
            </div>
            <div class="chat-footer">
                <div class="chat-input-wrapper">
                    <input type="text" class="chat-input" id="chatInput" placeholder="Type your message...">
                </div>
                <button class="chat-send" id="chatSend">
                    <i class="fas fa-paper-plane"></i>
                </button>
            </div>
        </div>
        <div class="chat-toggle-btn" id="chatToggle">
            <i class="fas fa-comment-dots"></i>
            <span class="notification-badge">1</span>
        </div>
    `;
    document.body.appendChild(chatWidget);

    // Elements
    const chatToggle = document.getElementById('chatToggle');
    const chatWindow = document.getElementById('chatWindow');
    const chatClose = document.getElementById('chatClose');
    const chatInput = document.getElementById('chatInput');
    const chatSend = document.getElementById('chatSend');
    const chatBody = document.getElementById('chatBody');
    const quickReplies = document.getElementById('quickReplies');

    // Toggle Chat
    chatToggle.addEventListener('click', () => {
        chatWindow.classList.toggle('active');
        chatWidget.classList.toggle('open');
        const badge = chatToggle.querySelector('.notification-badge');
        if (badge) badge.style.display = 'none';

        // Focus input when opening
        if (chatWindow.classList.contains('active')) {
            setTimeout(() => chatInput.focus(), 300);
        }
    });

    chatClose.addEventListener('click', () => {
        chatWindow.classList.remove('active');
        chatWidget.classList.remove('open');
    });

    // Send Message
    function sendMessage(message) {
        if (!message.trim()) return;

        // Add User Message
        addMessage(message, 'user');
        chatInput.value = '';

        // Simulate Typing
        showTyping();

        // Bot Response Logic
        setTimeout(() => {
            removeTyping();
            const response = getBotResponse(message);
            addMessage(response, 'bot');
        }, 1500 + Math.random() * 1000); // Random delay for realism
    }

    // Add Message to UI
    function addMessage(text, sender) {
        const msgDiv = document.createElement('div');
        msgDiv.className = `chat-message ${sender}`;
        msgDiv.innerHTML = text; // Allow HTML for formatting

        // Insert before quick replies if they exist
        if (quickReplies && quickReplies.parentNode === chatBody) {
            chatBody.insertBefore(msgDiv, quickReplies);
        } else {
            chatBody.appendChild(msgDiv);
        }

        // Scroll to bottom
        chatBody.scrollTop = chatBody.scrollHeight;
    }

    // Typing Indicator
    let typingDiv = null;
    function showTyping() {
        typingDiv = document.createElement('div');
        typingDiv.className = 'typing-indicator';
        typingDiv.innerHTML = `
            <div class="typing-dot"></div>
            <div class="typing-dot"></div>
            <div class="typing-dot"></div>
        `;
        if (quickReplies && quickReplies.parentNode === chatBody) {
            chatBody.insertBefore(typingDiv, quickReplies);
        } else {
            chatBody.appendChild(typingDiv);
        }
        chatBody.scrollTop = chatBody.scrollHeight;
    }

    function removeTyping() {
        if (typingDiv) {
            typingDiv.remove();
            typingDiv = null;
        }
    }

    // Bot Logic
    function getBotResponse(input) {
        input = input.toLowerCase();

        if (input.includes('book') || input.includes('puja')) {
            return "To book a puja, please visit our <a href='services.php' style='color:#dd2476;font-weight:bold;'>Services Page</a>. We offer Online, Temple, and Priest services. Would you like me to recommend a specific puja?";
        } else if (input.includes('temple') || input.includes('timing')) {
            return "Our temples are generally open from <strong>5:00 AM - 12:00 PM</strong> and <strong>4:00 PM - 9:00 PM</strong>. Special darshan timings apply during festivals.";
        } else if (input.includes('priest') || input.includes('talk')) {
            return "I can arrange a call with a priest for you. Please provide your phone number, and we will contact you shortly.";
        } else if (input.includes('contact') || input.includes('support')) {
            return "You can reach us at <strong>support@pujaservices.com</strong> or call <strong>+91-9876543210</strong>.";
        } else if (input.includes('hello') || input.includes('hi') || input.includes('namaste')) {
            return "Namaste! 🙏 It is a blessing to connect with you. How can I assist you today?";
        } else {
            return "Thank you for your message. One of our temple administrators will review your query and get back to you shortly. Is there anything else I can help with?";
        }
    }

    // Event Listeners
    chatSend.addEventListener('click', () => sendMessage(chatInput.value));

    chatInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') sendMessage(chatInput.value);
    });

    // Global function for quick replies
    window.sendQuickReply = function (text) {
        // Remove emoji for processing but keep for display
        const cleanText = text.replace(/([\u2700-\u27BF]|[\uE000-\uF8FF]|\uD83C[\uDC00-\uDFFF]|\uD83D[\uDC00-\uDFFF]|[\u2011-\u26FF]|\uD83E[\uDD10-\uDDFF])/g, '').trim();
        sendMessage(cleanText);

        // Hide quick replies after selection
        if (quickReplies) {
            quickReplies.style.opacity = '0';
            setTimeout(() => quickReplies.style.display = 'none', 300);
        }
    };
});
