// Mobile Menu Toggle
document.addEventListener('DOMContentLoaded', function () {
    const hamburger = document.querySelector('.hamburger');
    const navMenu = document.querySelector('.nav-menu');
    const navMenuNew = document.querySelector('.nav-menu-new');

    if (hamburger) {
        hamburger.addEventListener('click', function () {
            if (navMenu) navMenu.classList.toggle('active');
            if (navMenuNew) navMenuNew.classList.toggle('active');
        });

        // Close menu when clicking on a link
        document.querySelectorAll('.nav-menu a, .nav-menu-new a').forEach(link => {
            link.addEventListener('click', () => {
                if (navMenu) navMenu.classList.remove('active');
                if (navMenuNew) navMenuNew.classList.remove('active');
            });
        });
    }

    // Form validation
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function (e) {
            const requiredFields = form.querySelectorAll('[required]');
            let isValid = true;

            requiredFields.forEach(field => {
                if (!field.value.trim()) {
                    isValid = false;
                    field.style.borderColor = '#dc2626';
                } else {
                    field.style.borderColor = '#ddd';
                }
            });

            if (!isValid) {
                e.preventDefault();
                alert('Please fill in all required fields.');
            }
        });
    });

    // Auto-slide hero images
    autoSlideHero();

    // Enable "MORE" dropdown on click for touch devices
    document.querySelectorAll('.nav-more > a').forEach(trigger => {
        trigger.addEventListener('click', function (e) {
            // Only toggle if mobile or touch; prevent navigation
            e.preventDefault();
            const parent = this.parentElement;
            parent.classList.toggle('open');
        });
    });

    // Simple formatting for donation card inputs
    const cardInput = document.querySelector('input[name="card_number"]');
    const expInput = document.querySelector('input[name="card_exp"]');
    if (cardInput) {
        cardInput.addEventListener('input', function () {
            this.value = this.value.replace(/\D/g, '').replace(/(\d{4})(?=\d)/g, '$1 ').trim().slice(0, 19);
        });
    }
    if (expInput) {
        expInput.addEventListener('input', function () {
            let v = this.value.replace(/\D/g, '').slice(0, 4);
            if (v.length > 2) v = v.slice(0, 2) + '/' + v.slice(2);
            this.value = v;
        });
    }
});

// Hero Image Slider
let heroSlideIndex = 1;

function showHeroSlide(n) {
    const slides = document.getElementsByClassName('hero-slide');
    const dots = document.getElementsByClassName('dot');

    if (n > slides.length) {
        heroSlideIndex = 1;
    }
    if (n < 1) {
        heroSlideIndex = slides.length;
    }

    for (let i = 0; i < slides.length; i++) {
        slides[i].classList.remove('active');
    }

    for (let i = 0; i < dots.length; i++) {
        dots[i].classList.remove('active');
    }

    if (slides[heroSlideIndex - 1]) {
        slides[heroSlideIndex - 1].classList.add('active');
    }
    if (dots[heroSlideIndex - 1]) {
        dots[heroSlideIndex - 1].classList.add('active');
    }
}

function changeHeroSlide(n) {
    showHeroSlide(heroSlideIndex += n);
}

function currentHeroSlide(n) {
    showHeroSlide(heroSlideIndex = n);
}

function autoSlideHero() {
    setInterval(function () {
        changeHeroSlide(1);
    }, 5000); // Change slide every 5 seconds
}

// Initialize hero slider
showHeroSlide(heroSlideIndex);
// IntersectionObserver for scroll animations
const observerOptions = {
    threshold: 0.1
};
const observer = new IntersectionObserver((entries, obs) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('animate');
            obs.unobserve(entry.target);
        }
    });
}, observerOptions);

document.querySelectorAll('.animated').forEach(el => {
    observer.observe(el);
});

