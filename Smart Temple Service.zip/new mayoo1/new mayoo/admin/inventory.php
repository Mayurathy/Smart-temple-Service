<?php
require_once '../config/config.php';
requireAdminRole(['superadmin']);
$page_title = 'Inventory Management';
include 'includes/header.php';
?>

<h2>Temple Inventory</h2>

<div style="text-align: right; margin-bottom: 20px;">
    <a href="#" class="btn-admin btn-primary">
        <i class="fas fa-plus"></i> Add Item
    </a>
</div>

<div class="admin-table-container">
    <div class="admin-table">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Item Name</th>
                    <th>Category</th>
                    <th>Quantity</th>
                    <th>Unit</th>
                    <th>Reorder Level</th>
                    <th>Last Updated</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td colspan="8" style="text-align: center; padding: 40px;">
                        <i class="fas fa-boxes" style="font-size: 48px; color: #ddd; margin-bottom: 15px;"></i>
                        <p>No inventory items tracked. Click "Add Item" to start inventory management.</p>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<?php include 'includes/footer.php'; ?>