<?php
require_once '../config/config.php';
requireAdminRole(['superadmin', 'content']);
$page_title = 'Gallery Management';
include 'includes/header.php';
?>

<h2>Photo Gallery</h2>

<div style="text-align: right; margin-bottom: 20px;">
    <a href="#" class="btn-admin btn-primary">
        <i class="fas fa-upload"></i> Upload Images
    </a>
</div>

<div class="admin-table-container">
    <div style="padding: 40px; text-align: center;">
        <i class="fas fa-images" style="font-size: 64px; color: #D4AF37; margin-bottom: 20px;"></i>
        <h3>Image Gallery</h3>
        <p style="color: #666; margin: 20px 0;">Upload and manage temple photos, event images, and deity pictures.</p>
        <p style="color: #999;"><em>Gallery grid view will appear here once images are uploaded...</em></p>
    </div>
</div>

<?php include 'includes/footer.php'; ?>