<?php
require_once '../config/config.php';
requireAdminRole(['superadmin', 'manager']);
$page_title = 'Analytics Dashboard';
include 'includes/header.php';

$conn = getDBConnection();

// Get comprehensive analytics
$today = date('Y-m-d');
$this_week_start = date('Y-m-d', strtotime('monday this week'));
$this_month = date('Y-m');
$last_month = date('Y-m', strtotime('-1 month'));

// Compare this month vs last month
$stats = [];
$stats['this_month_bookings'] = $conn->query("SELECT COUNT(*) as count FROM bookings WHERE DATE_FORMAT(created_at, '%Y-%m') = '$this_month'")->fetch_assoc()['count'] ?? 0;
$stats['last_month_bookings'] = $conn->query("SELECT COUNT(*) as count FROM bookings WHERE DATE_FORMAT(created_at, '%Y-%m') = '$last_month'")->fetch_assoc()['count'] ?? 0;
$stats['this_month_revenue'] = $conn->query("SELECT COALESCE(SUM(amount), 0) as total FROM donations WHERE DATE_FORMAT(created_at, '%Y-%m') = '$this_month'")->fetch_assoc()['total'] ?? 0;
$stats['last_month_revenue'] = $conn->query("SELECT COALESCE(SUM(amount), 0) as total FROM donations WHERE DATE_FORMAT(created_at, '%Y-%m') = '$last_month'")->fetch_assoc()['total'] ?? 0;
$stats['this_week_contacts'] = $conn->query("SELECT COUNT(*) as count FROM contacts WHERE created_at >= '$this_week_start'")->fetch_assoc()['count'] ?? 0;
$stats['total_users'] = $conn->query("SELECT COUNT(*) as count FROM users")->fetch_assoc()['count'] ?? 0;
$stats['total_subscribers'] = $conn->query("SELECT COUNT(*) as count FROM subscribers")->fetch_assoc()['count'] ?? 0;

// Calculate growth
$booking_growth = $stats['last_month_bookings'] > 0 ? (($stats['this_month_bookings'] - $stats['last_month_bookings']) / $stats['last_month_bookings']) * 100 : 0;
$revenue_growth = $stats['last_month_revenue'] > 0 ? (($stats['this_month_revenue'] - $stats['last_month_revenue']) / $stats['last_month_revenue']) * 100 : 0;

// Top pujas
$top_pujas = $conn->query("SELECT p.name, COUNT(b.id) as booking_count 
                            FROM pujas p 
                            LEFT JOIN bookings b ON p.id = b.puja_id 
                            GROUP BY p.id 
                            ORDER BY booking_count DESC 
                            LIMIT 5");
?>

<div class="analytics-hero">
    <div class="hero-content">
        <h1><i class="fas fa-chart-pie"></i> Analytics & Insights</h1>
        <p>Comprehensive business intelligence and performance metrics</p>
    </div>
    <div class="period-selector">
        <button class="period-btn active">This Month</button>
        <button class="period-btn">Last Month</button>
        <button class="period-btn">This Year</button>
    </div>
</div>

<!-- KPI Cards -->
<div class="kpi-grid">
    <div class="kpi-card">
        <div class="kpi-header">
            <span class="kpi-label">Total Bookings</span>
            <i class="fas fa-calendar-check"></i>
        </div>
        <div class="kpi-value"><?php echo $stats['this_month_bookings']; ?></div>
        <div class="kpi-change <?php echo $booking_growth >= 0 ? 'positive' : 'negative'; ?>">
            <i class="fas fa-<?php echo $booking_growth >= 0 ? 'arrow-up' : 'arrow-down'; ?>"></i>
            <?php echo abs(round($booking_growth, 1)); ?>% vs last month
        </div>
        <div class="kpi-sparkline"></div>
    </div>

    <div class="kpi-card">
        <div class="kpi-header">
            <span class="kpi-label">Revenue</span>
            <i class="fas fa-rupee-sign"></i>
        </div>
        <div class="kpi-value">₹<?php echo number_format($stats['this_month_revenue'], 0); ?></div>
        <div class="kpi-change <?php echo $revenue_growth >= 0 ? 'positive' : 'negative'; ?>">
            <i class="fas fa-<?php echo $revenue_growth >= 0 ? 'arrow-up' : 'arrow-down'; ?>"></i>
            <?php echo abs(round($revenue_growth, 1)); ?>% vs last month
        </div>
    </div>

    <div class="kpi-card">
        <div class="kpi-header">
            <span class="kpi-label">New Contacts</span>
            <i class="fas fa-envelope"></i>
        </div>
        <div class="kpi-value"><?php echo $stats['this_week_contacts']; ?></div>
        <div class="kpi-change info">
            <i class="fas fa-info-circle"></i>
            This week
        </div>
    </div>

    <div class="kpi-card">
        <div class="kpi-header">
            <span class="kpi-label">Total Users</span>
            <i class="fas fa-users"></i>
        </div>
        <div class="kpi-value"><?php echo $stats['total_users']; ?></div>
        <div class="kpi-change info">
            <i class="fas fa-user-plus"></i>
            <?php echo $stats['total_subscribers']; ?> subscribers
        </div>
    </div>
</div>

<!-- Charts Section -->
<div class="analytics-charts-grid">
    <!-- Top Pujas -->
    <div class="analytics-panel">
        <div class="panel-header">
            <h3><i class="fas fa-trophy"></i> Top Performing Pujas</h3>
        </div>
        <div class="panel-body">
            <div class="top-items-list">
                <?php 
                $rank = 1;
                while($puja = $top_pujas->fetch_assoc()): 
                ?>
                    <div class="top-item">
                        <div class="rank-badge">#<?php echo $rank++; ?></div>
                        <div class="item-info">
                            <h4><?php echo htmlspecialchars($puja['name']); ?></h4>
                            <p><?php echo $puja['booking_count']; ?> bookings</p>
                        </div>
                        <div class="item-bar">
                            <div class="bar-fill" style="width: <?php echo min(100, $puja['booking_count'] * 10); ?>%"></div>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        </div>
    </div>

    <!-- Monthly Trend -->
    <div class="analytics-panel">
        <div class="panel-header">
            <h3><i class="fas fa-chart-line"></i> Monthly Trend</h3>
        </div>
        <div class="panel-body">
            <div class="trend-comparison">
                <div class="trend-item">
                    <span class="trend-label">This Month</span>
                    <span class="trend-value current"><?php echo $stats['this_month_bookings']; ?></span>
                    <div class="trend-bar current" style="width: <?php echo max(30, min(100, ($stats['this_month_bookings'] / max($stats['this_month_bookings'], $stats['last_month_bookings'])) * 100)); ?>%"></div>
                </div>
                <div class="trend-item">
                    <span class="trend-label">Last Month</span>
                    <span class="trend-value previous"><?php echo $stats['last_month_bookings']; ?></span>
                    <div class="trend-bar previous" style="width: <?php echo max(30, min(100, ($stats['last_month_bookings'] / max($stats['this_month_bookings'], $stats['last_month_bookings'])) * 100)); ?>%"></div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.analytics-hero {
    background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
    border-radius: 24px;
    padding: 40px;
    margin-bottom: 30px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    color: white;
}

.hero-content h1 {
    margin: 0 0 10px 0;
    font-size: 32px;
    font-weight: 700;
    display: flex;
    align-items: center;
    gap: 15px;
}

.hero-content p {
    margin: 0;
    opacity: 0.8;
    font-size: 16px;
}

.period-selector {
    display: flex;
    gap: 10px;
}

.period-btn {
    padding: 10px 20px;
    background: rgba(255,255,255,0.1);
    border: 1px solid rgba(255,255,255,0.2);
    color: white;
    border-radius: 10px;
    cursor: pointer;
    transition: all 0.3s ease;
    font-weight: 600;
}

.period-btn:hover, .period-btn.active {
    background: #D4AF37;
    border-color: #D4AF37;
}

/* KPI Cards */
.kpi-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
    gap: 25px;
    margin-bottom: 30px;
}

.kpi-card {
    background: white;
    border-radius: 20px;
    padding: 25px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.06);
    position: relative;
    overflow: hidden;
}

.kpi-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 15px;
}

.kpi-label {
    font-size: 13px;
    color: #6b7280;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.kpi-header i {
    font-size: 24px;
    color: #D4AF37;
    opacity: 0.3;
}

.kpi-value {
    font-size: 36px;
    font-weight: 800;
    color: #1a1a1a;
    margin-bottom: 10px;
}

.kpi-change {
    font-size: 13px;
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 5px;
}

.kpi-change.positive {
    color: #10b981;
}

.kpi-change.negative {
    color: #ef4444;
}

.kpi-change.info {
    color: #6b7280;
}

/* Analytics Charts */
.analytics-charts-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 25px;
}

.analytics-panel {
    background: white;
    border-radius: 20px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.06);
    overflow: hidden;
}

.panel-header {
    background: linear-gradient(135deg, #f8fafc, #f1f5f9);
    padding: 20px 25px;
    border-bottom: 2px solid #e2e8f0;
}

.panel-header h3 {
    margin: 0;
    font-size: 16px;
    font-weight: 700;
    color: #1e293b;
    display: flex;
    align-items: center;
    gap: 10px;
}

.panel-body {
    padding: 25px;
}

/* Top Items List */
.top-items-list {
    display: flex;
    flex-direction: column;
    gap: 15px;
}

.top-item {
    display: flex;
    align-items: center;
    gap: 15px;
}

.rank-badge {
    width: 35px;
    height: 35px;
    background: linear-gradient(135deg, #D4AF37, #F4E5BC);
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 800;
    color: #1a1a1a;
    font-size: 14px;
}

.item-info {
    flex: 1;
}

.item-info h4 {
    margin: 0 0 5px 0;
    font-size: 14px;
    font-weight: 700;
    color: #1a1a1a;
}

.item-info p {
    margin: 0;
    font-size: 12px;
    color: #6b7280;
}

.item-bar {
    width: 100px;
    height: 8px;
    background: #e5e7eb;
    border-radius: 4px;
    overflow: hidden;
}

.bar-fill {
    height: 100%;
    background: linear-gradient(90deg, #4a0404, #D4AF37);
    transition: width 1s ease;
}

/* Trend Comparison */
.trend-comparison {
    display: flex;
    flex-direction: column;
    gap: 25px;
}

.trend-item {
    display: flex;
    flex-direction: column;
    gap: 8px;
}

.trend-label {
    font-size: 13px;
    color: #6b7280;
    font-weight: 600;
}

.trend-value {
    font-size: 28px;
    font-weight: 800;
}

.trend-value.current {
    color: #4a0404;
}

.trend-value.previous {
    color: #9ca3af;
}

.trend-bar {
    height: 12px;
    border-radius: 6px;
    transition: width 1s ease;
}

.trend-bar.current {
    background: linear-gradient(90deg, #4a0404, #8B0000);
}

.trend-bar.previous {
    background: #e5e7eb;
}

@media (max-width: 1200px) {
    .analytics-charts-grid {
        grid-template-columns: 1fr;
    }
}
</style>

<?php
$conn->close();
include 'includes/footer.php';
?>
