<?php
require_once '../config/config.php';
requireAdminRole(['superadmin', 'content']);
$page_title = 'Manage Priests';
include 'includes/header.php';

$conn = getDBConnection();
$message = '';
$message_type = '';

// Handle delete
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    if ($conn->query("UPDATE priests SET status = 'inactive' WHERE id = $id")) {
        $message = 'Priest deleted successfully';
        $message_type = 'success';
    } else {
        $message = 'Error deleting priest';
        $message_type = 'error';
    }
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = sanitize($_POST['name']);
    $email = sanitize($_POST['email']);
    $phone = sanitize($_POST['phone']);
    $experience = intval($_POST['experience']);
    $specialization = sanitize($_POST['specialization']);
    $location = sanitize($_POST['location']);
    $status = sanitize($_POST['status']);

    // Handle image upload
    $image_name = '';
    $upload_dir = '../assets/images/priests/';

    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }

    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $upload_result = uploadImage($_FILES['image'], $upload_dir);
        if ($upload_result['success']) {
            $image_name = $upload_result['filename'];
        } else {
            $message = $upload_result['error'];
            $message_type = 'error';
        }
    }

    if (isset($_POST['priest_id']) && $_POST['priest_id'] > 0) {
        // Update
        $id = intval($_POST['priest_id']);

        if ($image_name) {
            $query = "UPDATE priests SET name = ?, email = ?, phone = ?, experience = ?, specialization = ?, location = ?, image = ?, status = ? WHERE id = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("sssissssi", $name, $email, $phone, $experience, $specialization, $location, $image_name, $status, $id);
        } else {
            $query = "UPDATE priests SET name = ?, email = ?, phone = ?, experience = ?, specialization = ?, location = ?, status = ? WHERE id = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("sssisssi", $name, $email, $phone, $experience, $specialization, $location, $status, $id);
        }

        if ($stmt->execute()) {
            $message = 'Priest updated successfully';
            $message_type = 'success';
        } else {
            $message = 'Error updating priest: ' . $conn->error;
            $message_type = 'error';
        }
        $stmt->close();
    } else {
        // Insert
        $query = "INSERT INTO priests (name, email, phone, experience, specialization, location, image, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ssisssss", $name, $email, $phone, $experience, $specialization, $location, $image_name, $status);

        if ($stmt->execute()) {
            $message = 'Priest added successfully';
            $message_type = 'success';
        } else {
            $message = 'Error adding priest: ' . $conn->error;
            $message_type = 'error';
        }
        $stmt->close();
    }
}

// Get priest for edit
$edit_priest = null;
if (isset($_GET['edit'])) {
    $id = intval($_GET['edit']);
    $result = $conn->query("SELECT * FROM priests WHERE id = $id");
    if ($result && $result->num_rows > 0) {
        $edit_priest = $result->fetch_assoc();
    }
}

// Get all priests
$priests = $conn->query("SELECT * FROM priests ORDER BY experience DESC, id DESC");
?>

<h2>Manage Priests</h2>

<?php if ($message): ?>
    <div class="alert <?php echo $message_type === 'success' ? 'alert-success' : 'alert-error'; ?>"
        style="margin-bottom: 20px;">
        <?php echo $message; ?>
    </div>
<?php endif; ?>

<button onclick="document.getElementById('priestForm').style.display='block'" class="btn-admin btn-primary"
    style="margin-bottom: 20px;">
    <i class="fas fa-plus"></i> <?php echo $edit_priest ? 'Update' : 'Add New'; ?> Priest
</button>

<!-- Priest Form -->
<div id="priestForm" class="form-container"
    style="display: <?php echo $edit_priest ? 'block' : 'none'; ?>; max-width: 900px; margin-bottom: 30px;">
    <h3><?php echo $edit_priest ? 'Edit' : 'Add New'; ?> Priest</h3>
    <form method="POST" action="" enctype="multipart/form-data">
        <input type="hidden" name="priest_id" value="<?php echo $edit_priest ? $edit_priest['id'] : 0; ?>">

        <div class="form-row" style="display: grid; grid-template-columns: 2fr 1fr; gap: 15px;">
            <div class="form-group">
                <label>Priest Name *</label>
                <input type="text" name="name"
                    value="<?php echo $edit_priest ? htmlspecialchars($edit_priest['name']) : ''; ?>" required
                    placeholder="e.g., Sri Ravi Shankar">
            </div>

            <div class="form-group">
                <label>Experience (Years) *</label>
                <input type="number" name="experience"
                    value="<?php echo $edit_priest ? $edit_priest['experience'] : 0; ?>" required min="0" max="99"
                    placeholder="e.g., 15">
            </div>
        </div>

        <div class="form-row" style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 15px;">
            <div class="form-group">
                <label>Email *</label>
                <input type="email" name="email"
                    value="<?php echo $edit_priest ? htmlspecialchars($edit_priest['email']) : ''; ?>" required
                    placeholder="priest@example.com">
            </div>

            <div class="form-group">
                <label>Phone *</label>
                <input type="tel" name="phone"
                    value="<?php echo $edit_priest ? htmlspecialchars($edit_priest['phone']) : ''; ?>" required
                    placeholder="+91 98765 43210">
            </div>

            <div class="form-group">
                <label>Status *</label>
                <select name="status" required>
                    <option value="active" <?php echo (!$edit_priest || $edit_priest['status'] == 'active') ? 'selected' : ''; ?>>Active</option>
                    <option value="inactive" <?php echo ($edit_priest && $edit_priest['status'] == 'inactive') ? 'selected' : ''; ?>>Inactive</option>
                </select>
            </div>
        </div>

        <div class="form-group">
            <label>Location/City *</label>
            <input type="text" name="location"
                value="<?php echo $edit_priest ? htmlspecialchars($edit_priest['location']) : ''; ?>" required
                placeholder="e.g., Hyderabad">
        </div>

        <div class="form-group">
            <label>Specialization *</label>
            <textarea name="specialization" rows="3" required
                placeholder="e.g., Vratham Pujas, Archana, Rudrabhishekam, Shiva Pujas..."><?php echo $edit_priest ? htmlspecialchars($edit_priest['specialization']) : ''; ?></textarea>
            <small style="color: #666; font-size: 12px;">List the priest's areas of expertise and puja
                specializations</small>
        </div>

        <div class="form-group">
            <label>Priest Photo</label>
            <?php if ($edit_priest && $edit_priest['image']): ?>
                <div style="margin-bottom: 10px;">
                    <img src="<?php echo SITE_URL; ?>/assets/images/priests/<?php echo $edit_priest['image']; ?>"
                        alt="Current Photo" style="max-width: 150px; border-radius: 8px; border: 2px solid #e5e7eb;">
                    <p style="font-size: 12px; color: #666; margin-top: 5px;">Current: <?php echo $edit_priest['image']; ?>
                    </p>
                </div>
            <?php endif; ?>
            <input type="file" name="image" accept="image/jpeg,image/jpg,image/png,image/webp">
            <small style="color: #666; font-size: 12px; display: block; margin-top: 5px;">
                Upload priest photo (JPG, PNG, or WEBP). Max 5MB.
                <?php echo $edit_priest ? 'Leave blank to keep current photo.' : ''; ?>
            </small>
        </div>

        <div style="display: flex; gap: 10px; margin-top: 20px;">
            <button type="submit" class="btn-admin btn-primary">
                <i class="fas fa-save"></i> <?php echo $edit_priest ? 'Update' : 'Add'; ?> Priest
            </button>
            <a href="<?php echo SITE_URL; ?>/admin/priests.php" class="btn-admin" style="text-decoration: none;">
                <i class="fas fa-times"></i> Cancel
            </a>
        </div>
    </form>
</div>

<!-- Priests Table -->
<div class="admin-table-container">
    <div class="admin-table">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Photo</th>
                    <th>Name</th>
                    <th>Contact</th>
                    <th>Experience</th>
                    <th>Specialization</th>
                    <th>Location</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($priests && $priests->num_rows > 0): ?>
                    <?php while ($priest = $priests->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $priest['id']; ?></td>
                            <td>
                                <?php if ($priest['image']): ?>
                                    <img src="<?php echo SITE_URL; ?>/assets/images/priests/<?php echo $priest['image']; ?>"
                                        alt="<?php echo htmlspecialchars($priest['name']); ?>"
                                        style="width: 50px; height: 50px; object-fit: cover; border-radius: 50%;">
                                <?php else: ?>
                                    <div
                                        style="width: 50px; height: 50px; background: #f3f4f6; border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                                        <i class="fas fa-user-tie" style="color: #9ca3af;"></i>
                                    </div>
                                <?php endif; ?>
                            </td>
                            <td><strong><?php echo htmlspecialchars($priest['name']); ?></strong></td>
                            <td>
                                <small style="display: block; color: #666;">
                                    <i class="fas fa-envelope"></i> <?php echo htmlspecialchars($priest['email']); ?>
                                </small>
                                <small style="display: block; color: #666;">
                                    <i class="fas fa-phone"></i> <?php echo htmlspecialchars($priest['phone']); ?>
                                </small>
                            </td>
                            <td>
                                <span
                                    style="padding: 4px 10px; background: #dbeafe; color: #1e40af; border-radius: 12px; font-size: 12px; font-weight: 600;">
                                    <?php echo $priest['experience']; ?> years
                                </span>
                            </td>
                            <td style="max-width: 200px;">
                                <small><?php echo truncate($priest['specialization'], 50); ?></small>
                            </td>
                            <td><?php echo htmlspecialchars($priest['location']); ?></td>
                            <td><?php echo getStatusBadge($priest['status']); ?></td>
                            <td>
                                <a href="<?php echo SITE_URL; ?>/admin/priests.php?edit=<?php echo $priest['id']; ?>"
                                    class="btn-icon" title="Edit">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <a href="<?php echo SITE_URL; ?>/admin/priests.php?delete=<?php echo $priest['id']; ?>"
                                    onclick="return confirm('Are you sure you want to delete this priest?')" class="btn-icon"
                                    title="Delete" style="color: #ef4444;">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="9" style="text-align: center; padding: 40px;">
                            <i class="fas fa-user-tie" style="font-size: 48px; color: #ddd; margin-bottom: 15px;"></i>
                            <p style="color: #666;">No priests found. Click "Add New Priest" to get started.</p>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<style>
    .form-container {
        background: white;
        padding: 25px;
        border-radius: 12px;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        animation: fadeIn 0.3s ease;
    }

    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translateY(-10px);
        }

        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .form-group {
        margin-bottom: 20px;
    }

    .form-group label {
        display: block;
        margin-bottom: 8px;
        font-weight: 600;
        color: #374151;
    }

    .form-group input,
    .form-group textarea,
    .form-group select {
        width: 100%;
        padding: 12px;
        border: 1px solid #e5e7eb;
        border-radius: 8px;
        font-size: 14px;
        transition: all 0.3s ease;
    }

    .form-group input:focus,
    .form-group textarea:focus,
    .form-group select:focus {
        outline: none;
        border-color: var(--primary-gold);
        box-shadow: 0 0 0 3px rgba(212, 175, 55, 0.1);
    }

    .btn-icon {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 32px;
        height: 32px;
        border-radius: 6px;
        transition: all 0.2s ease;
        color: var(--primary-gold);
        text-decoration: none;
        margin: 0 4px;
    }

    .btn-icon:hover {
        background: rgba(212, 175, 55, 0.1);
        transform: scale(1.1);
    }

    .alert {
        padding: 12px 20px;
        border-radius: 8px;
        font-weight: 500;
    }

    .alert-success {
        background: #d1fae5;
        color: #065f46;
        border: 1px solid #6ee7b7;
    }

    .alert-error {
        background: #fee2e2;
        color: #991b1b;
        border: 1px solid #fca5a5;
    }
</style>

<?php
$conn->close();
include 'includes/footer.php';
?>