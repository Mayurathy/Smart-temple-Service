<?php
require_once '../config/config.php';
requireAdminRole(['superadmin', 'manager']);
$page_title = 'Revenue Management';
include 'includes/header.php';

$conn = getDBConnection();

// Get revenue data grouped by month
$revenue_query = "
    SELECT 
        DATE_FORMAT(created_at, '%Y-%m') as month,
        SUM(amount) as total_revenue,
        COUNT(*) as transaction_count
    FROM donations 
    WHERE created_at >= DATE_SUB(NOW(), INTERVAL 12 MONTH)
    GROUP BY DATE_FORMAT(created_at, '%Y-%m')
    ORDER BY month DESC
";
$revenue_data = $conn->query($revenue_query);

// Get total revenue
$total_query = "SELECT SUM(amount) as total FROM donations";
$total_result = $conn->query($total_query);
$total_revenue = $total_result->fetch_assoc()['total'] ?? 0;
?>

<div class="dashboard-grid">
    <div class="stat-card">
        <h3>Total Revenue</h3>
        <div class="stat-number">₹<?php echo number_format($total_revenue, 2); ?></div>
        <i class="fas fa-rupee-sign stat-icon"></i>
    </div>
</div>

<h2>Monthly Revenue Report</h2>

<div class="admin-table-container">
    <div class="admin-table">
        <table>
            <thead>
                <tr>
                    <th>Month</th>
                    <th>Total Revenue</th>
                    <th>Transactions</th>
                    <th>Average</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($revenue_data && $revenue_data->num_rows > 0): ?>
                    <?php while ($row = $revenue_data->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo date('F Y', strtotime($row['month'] . '-01')); ?></td>
                            <td>₹<?php echo number_format($row['total_revenue'], 2); ?></td>
                            <td><?php echo $row['transaction_count']; ?></td>
                            <td>₹<?php echo number_format($row['total_revenue'] / $row['transaction_count'], 2); ?></td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="4" style="text-align: center;">No revenue data found</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php
$conn->close();
include 'includes/footer.php';
?>