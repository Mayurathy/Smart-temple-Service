<?php
require_once '../config/config.php';
requireAdminRole(['superadmin','operations']);
$page_title = 'Manage Bookings';
include 'includes/header.php';

$conn = getDBConnection();

// Handle status update
if (isset($_GET['update_status']) && isset($_GET['id'])) {
    $booking_id = intval($_GET['id']);
    $status = sanitize($_GET['update_status']);
    
    $update_query = "UPDATE bookings SET status = ? WHERE id = ?";
    $stmt = $conn->prepare($update_query);
    $stmt->bind_param("si", $status, $booking_id);
    $stmt->execute();
    $stmt->close();
    
    redirect('/admin/bookings.php');
}

// Get all bookings
$bookings_query = "SELECT b.*, p.name as puja_name, t.name as temple_name, pr.name as priest_name 
                   FROM bookings b 
                   LEFT JOIN pujas p ON b.puja_id = p.id 
                   LEFT JOIN temples t ON b.temple_id = t.id 
                   LEFT JOIN priests pr ON b.priest_id = pr.id 
                   ORDER BY b.created_at DESC";
$bookings = $conn->query($bookings_query);
?>

<h2>Manage Bookings</h2>

<div class="admin-table">
    <table>
        <thead>
            <tr>
                <th>Booking ID</th>
                <th>Customer Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Puja/Service</th>
                <th>Type</th>
                <th>Date</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($bookings && $bookings->num_rows > 0): ?>
                <?php while ($booking = $bookings->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($booking['booking_id']); ?></td>
                        <td><?php echo htmlspecialchars($booking['user_name']); ?></td>
                        <td><?php echo htmlspecialchars($booking['user_email']); ?></td>
                        <td><?php echo htmlspecialchars($booking['user_phone']); ?></td>
                        <td>
                            <?php 
                            if ($booking['puja_name']) {
                                echo htmlspecialchars($booking['puja_name']);
                            } elseif ($booking['temple_name']) {
                                echo htmlspecialchars($booking['temple_name']);
                            } elseif ($booking['priest_name']) {
                                echo htmlspecialchars($booking['priest_name']);
                            } else {
                                echo '-';
                            }
                            ?>
                        </td>
                        <td><?php echo ucfirst($booking['booking_type']); ?></td>
                        <td><?php echo date('d M Y', strtotime($booking['booking_date'])); ?></td>
                        <td>
                            <span class="status-badge status-<?php echo $booking['status']; ?>">
                                <?php echo ucfirst($booking['status']); ?>
                            </span>
                        </td>
                        <td>
                            <a href="<?php echo SITE_URL; ?>/admin/view-booking.php?id=<?php echo $booking['id']; ?>" style="text-decoration: none; color: var(--primary-color); margin-right: 10px;">
                                <i class="fas fa-eye"></i>
                            </a>
                            <select onchange="updateStatus(<?php echo $booking['id']; ?>, this.value)" style="padding: 5px;">
                                <option value="pending" <?php echo $booking['status'] == 'pending' ? 'selected' : ''; ?>>Pending</option>
                                <option value="confirmed" <?php echo $booking['status'] == 'confirmed' ? 'selected' : ''; ?>>Confirmed</option>
                                <option value="completed" <?php echo $booking['status'] == 'completed' ? 'selected' : ''; ?>>Completed</option>
                                <option value="cancelled" <?php echo $booking['status'] == 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                            </select>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="9" style="text-align: center;">No bookings found</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<script>
function updateStatus(id, status) {
    window.location.href = '<?php echo SITE_URL; ?>/admin/bookings.php?update_status=' + status + '&id=' + id;
}
</script>

<?php
$conn->close();
include 'includes/footer.php';
?>

