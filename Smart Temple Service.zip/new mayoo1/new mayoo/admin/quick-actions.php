<?php
require_once '../config/config.php';
requireAdminRole(['superadmin', 'manager', 'operations', 'content']);
$page_title = 'Quick Actions';
include 'includes/header.php';
?>

<div class="quick-actions-hero">
    <div class="hero-icon">
        <i class="fas fa-bolt"></i>
    </div>
    <div class="hero-text">
        <h1>Quick Actions Center</h1>
        <p>Access commonly used functions in one place</p>
    </div>
</div>

<!-- Quick Actions Grid -->
<div class="qa-grid">
    <!-- Booking Actions -->
    <div class="qa-section">
        <h3><i class="fas fa-calendar"></i> Bookings</h3>
        <div class="qa-buttons">
            <a href="bookings.php?status=pending" class="qa-btn urgent">
                <i class="fas fa-clock"></i>
                <span>View Pending</span>
                <div class="qa-badge">New</div>
            </a>
            <a href="bookings.php?action=new" class="qa-btn">
                <i class="fas fa-plus-circle"></i>
                <span>Create Booking</span>
            </a>
            <a href="bookings.php" class="qa-btn">
                <i class="fas fa-list"></i>
                <span>All Bookings</span>
            </a>
        </div>
    </div>

    <!-- Contact Actions -->
    <div class="qa-section">
        <h3><i class="fas fa-envelope"></i> Communications</h3>
        <div class="qa-buttons">
            <a href="contacts.php?status=new" class="qa-btn warning">
                <i class="fas fa-envelope-open"></i>
                <span>Unread Messages</span>
                <div class="qa-badge">!</div>
            </a>
            <a href="subscribers.php" class="qa-btn">
                <i class="fas fa-users"></i>
                <span>Subscribers</span>
            </a>
            <a href="contacts.php" class="qa-btn">
                <i class="fas fa-inbox"></i>
                <span>All Contacts</span>
            </a>
        </div>
    </div>

    <!-- Content Actions -->
    <?php if (adminHasRole(['superadmin', 'content'])): ?>
        <div class="qa-section">
            <h3><i class="fas fa-edit"></i> Content Management</h3>
            <div class="qa-buttons">
                <a href="pujas.php?action=new" class="qa-btn">
                    <i class="fas fa-pray"></i>
                    <span>Add Puja</span>
                </a>
                <a href="events.php?action=new" class="qa-btn">
                    <i class="fas fa-calendar-star"></i>
                    <span>Create Event</span>
                </a>
                <a href="blog.php?action=new" class="qa-btn">
                    <i class="fas fa-blog"></i>
                    <span>New Blog Post</span>
                </a>
                <a href="announcements.php?action=new" class="qa-btn">
                    <i class="fas fa-bullhorn"></i>
                    <span>Announcement</span>
                </a>
            </div>
        </div>
    <?php endif; ?>

    <!-- Financial Actions -->
    <?php if (adminHasRole(['superadmin', 'manager'])): ?>
        <div class="qa-section">
            <h3><i class="fas fa-rupee-sign"></i> Financial</h3>
            <div class="qa-buttons">
                <a href="donations.php" class="qa-btn success">
                    <i class="fas fa-hand-holding-usd"></i>
                    <span>View Donations</span>
                </a>
                <a href="revenue.php" class="qa-btn">
                    <i class="fas fa-chart-line"></i>
                    <span>Revenue Report</span>
                </a>
                <a href="reports.php" class="qa-btn">
                    <i class="fas fa-file-invoice-dollar"></i>
                    <span>Generate Report</span>
                </a>
            </div>
        </div>
    <?php endif; ?>

    <!-- System Actions -->
    <?php if (adminHasRole(['superadmin'])): ?>
        <div class="qa-section">
            <h3><i class="fas fa-cog"></i> System</h3>
            <div class="qa-buttons">
                <a href="users.php" class="qa-btn">
                    <i class="fas fa-users-cog"></i>
                    <span>User Management</span>
                </a>
                <a href="settings.php" class="qa-btn">
                    <i class="fas fa-sliders-h"></i>
                    <span>Settings</span>
                </a>
                <a href="staff.php" class="qa-btn">
                    <i class="fas fa-user-friends"></i>
                    <span>Staff Directory</span>
                </a>
            </div>
        </div>
    <?php endif; ?>

    <!-- Data Management -->
    <div class="qa-section">
        <h3><i class="fas fa-database"></i> Data & Reports</h3>
        <div class="qa-buttons">
            <a href="analytics.php" class="qa-btn info">
                <i class="fas fa-chart-pie"></i>
                <span>Analytics</span>
            </a>
            <a href="calendar.php" class="qa-btn">
                <i class="fas fa-calendar-alt"></i>
                <span>Calendar View</span>
            </a>
            <a href="gallery.php" class="qa-btn">
                <i class="fas fa-images"></i>
                <span>Gallery</span>
            </a>
        </div>
    </div>
</div>

<!-- Keyboard Shortcuts Guide -->
<div class="shortcuts-panel">
    <h3><i class="fas fa-keyboard"></i> Keyboard Shortcuts</h3>
    <div class="shortcuts-grid">
        <div class="shortcut-item">
            <kbd>Ctrl</kbd> + <kbd>B</kbd>
            <span>View Bookings</span>
        </div>
        <div class="shortcut-item">
            <kbd>Ctrl</kbd> + <kbd>M</kbd>
            <span>Check Messages</span>
        </div>
        <div class="shortcut-item">
            <kbd>Ctrl</kbd> + <kbd>D</kbd>
            <span>Dashboard</span>
        </div>
        <div class="shortcut-item">
            <kbd>Ctrl</kbd> + <kbd>A</kbd>
            <span>Analytics</span>
        </div>
    </div>
</div>

<style>
    .quick-actions-hero {
        background: linear-gradient(135deg, #D4AF37 0%, #F4E5BC 100%);
        border-radius: 24px;
        padding: 40px;
        margin-bottom: 35px;
        display: flex;
        align-items: center;
        gap: 25px;
        box-shadow: 0 10px 30px rgba(212, 175, 55, 0.3);
    }

    .hero-icon {
        width: 80px;
        height: 80px;
        background: linear-gradient(135deg, #4a0404, #8B0000);
        border-radius: 20px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 40px;
        color: #D4AF37;
        box-shadow: 0 8px 20px rgba(74, 4, 4, 0.4);
    }

    .hero-text h1 {
        margin: 0 0 8px 0;
        font-size: 32px;
        font-weight: 800;
        color: #1a1a1a;
    }

    .hero-text p {
        margin: 0;
        font-size: 16px;
        color: #4a4a4a;
    }

    /* Quick Actions Grid */
    .qa-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
        gap: 25px;
        margin-bottom: 35px;
    }

    .qa-section {
        background: white;
        border-radius: 20px;
        padding: 25px;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.06);
    }

    .qa-section h3 {
        margin: 0 0 20px 0;
        font-size: 16px;
        font-weight: 700;
        color: #1e293b;
        display: flex;
        align-items: center;
        gap: 10px;
        padding-bottom: 15px;
        border-bottom: 2px solid #e5e7eb;
    }

    .qa-buttons {
        display: flex;
        flex-direction: column;
        gap: 12px;
    }

    .qa-btn {
        display: flex;
        align-items: center;
        gap: 15px;
        padding: 16px 20px;
        background: #f9fafb;
        border-radius: 12px;
        text-decoration: none;
        color: #1a1a1a;
        font-weight: 600;
        transition: all 0.3s ease;
        position: relative;
        border: 2px solid transparent;
    }

    .qa-btn:hover {
        background: white;
        border-color: #D4AF37;
        transform: translateX(5px);
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
    }

    .qa-btn i {
        font-size: 20px;
        color: #6b7280;
        width: 24px;
        text-align: center;
    }

    .qa-btn.urgent {
        background: linear-gradient(135deg, #fef2f2, #fee2e2);
        border-color: #fecaca;
    }

    .qa-btn.urgent i {
        color: #dc2626;
    }

    .qa-btn.warning {
        background: linear-gradient(135deg, #fffbeb, #fef3c7);
        border-color: #fde68a;
    }

    .qa-btn.warning i {
        color: #f59e0b;
    }

    .qa-btn.success {
        background: linear-gradient(135deg, #f0fdf4, #dcfce7);
        border-color: #bbf7d0;
    }

    .qa-btn.success i {
        color: #10b981;
    }

    .qa-btn.info {
        background: linear-gradient(135deg, #eff6ff, #dbeafe);
        border-color: #bfdbfe;
    }

    .qa-btn.info i {
        color: #3b82f6;
    }

    .qa-badge {
        margin-left: auto;
        background: #dc2626;
        color: white;
        padding: 4px 10px;
        border-radius: 8px;
        font-size: 11px;
        font-weight: 700;
    }

    /* Shortcuts Panel */
    .shortcuts-panel {
        background: linear-gradient(135deg, #1e293b, #0f172a);
        border-radius: 20px;
        padding: 30px;
        color: white;
    }

    .shortcuts-panel h3 {
        margin: 0 0 20px 0;
        font-size: 18px;
        font-weight: 700;
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .shortcuts-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
        gap: 15px;
    }

    .shortcut-item {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 12px;
        background: rgba(255, 255, 255, 0.05);
        border-radius: 10px;
        font-size: 14px;
    }

    kbd {
        background: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 6px;
        padding: 4px 8px;
        font-size: 12px;
        font-weight: 700;
        font-family: monospace;
    }

    .shortcut-item span {
        color: rgba(255, 255, 255, 0.7);
    }

    @media (max-width: 768px) {
        .qa-grid {
            grid-template-columns: 1fr;
        }

        .shortcuts-grid {
            grid-template-columns: 1fr;
        }
    }
</style>

<?php include 'includes/footer.php'; ?>