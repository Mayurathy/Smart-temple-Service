<?php
require_once '../config/config.php';
requireAdminRole(['superadmin','operations']);
$page_title = 'Manage Contacts';
include 'includes/header.php';

$conn = getDBConnection();

// Mark as read
if (isset($_GET['mark_read'])) {
    $id = intval($_GET['mark_read']);
    $conn->query("UPDATE contacts SET status = 'read' WHERE id = $id");
    redirect('/admin/contacts.php');
}

// Get all contacts
$contacts = $conn->query("SELECT * FROM contacts ORDER BY created_at DESC");
?>

<h2>Contact Messages</h2>

<div class="admin-table">
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Subject</th>
                <th>Status</th>
                <th>Date</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($contacts && $contacts->num_rows > 0): ?>
                <?php while ($contact = $contacts->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $contact['id']; ?></td>
                        <td><?php echo htmlspecialchars($contact['name']); ?></td>
                        <td><?php echo htmlspecialchars($contact['email']); ?></td>
                        <td><?php echo htmlspecialchars($contact['phone']); ?></td>
                        <td><?php echo htmlspecialchars($contact['subject']); ?></td>
                        <td>
                            <span class="status-badge <?php echo $contact['status'] == 'new' ? 'status-pending' : ''; ?>">
                                <?php echo ucfirst($contact['status']); ?>
                            </span>
                        </td>
                        <td><?php echo date('d M Y', strtotime($contact['created_at'])); ?></td>
                        <td>
                            <a href="<?php echo SITE_URL; ?>/admin/view-contact.php?id=<?php echo $contact['id']; ?>" style="text-decoration: none; color: var(--primary-color); margin-right: 10px;">
                                <i class="fas fa-eye"></i> View
                            </a>
                            <?php if ($contact['status'] == 'new'): ?>
                            <a href="<?php echo SITE_URL; ?>/admin/contacts.php?mark_read=<?php echo $contact['id']; ?>" style="text-decoration: none; color: var(--primary-color);">
                                <i class="fas fa-check"></i> Mark Read
                            </a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="8" style="text-align: center;">No contacts found</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php
$conn->close();
include 'includes/footer.php';
?>

