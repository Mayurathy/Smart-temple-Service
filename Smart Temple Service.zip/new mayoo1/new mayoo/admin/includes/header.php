<?php
require_once '../config/config.php';
requireLogin();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? $page_title : 'Admin Panel'; ?> - Puja Services</title>
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>/assets/css/admin-premium.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>

<body>
    <!-- Sidebar -->
    <aside class="admin-sidebar">
        <div class="sidebar-header">
            <h2>Admin Panel</h2>
        </div>
        <ul class="sidebar-menu">
            <li><a href="<?php echo SITE_URL; ?>/admin/index.php"
                    class="<?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>"><i
                        class="fas fa-home"></i> Dashboard</a></li>

            <?php if (adminHasRole(['superadmin', 'manager', 'operations'])): ?>
                <li><a href="<?php echo SITE_URL; ?>/admin/operations.php"
                        class="<?php echo basename($_SERVER['PHP_SELF']) == 'operations.php' ? 'active' : ''; ?>"><i
                            class="fas fa-chart-line"></i> Operations</a></li>
                <li><a href="<?php echo SITE_URL; ?>/admin/analytics.php"
                        class="<?php echo basename($_SERVER['PHP_SELF']) == 'analytics.php' ? 'active' : ''; ?>"><i
                            class="fas fa-chart-pie"></i> Analytics</a></li>
                <li><a href="<?php echo SITE_URL; ?>/admin/quick-actions.php"
                        class="<?php echo basename($_SERVER['PHP_SELF']) == 'quick-actions.php' ? 'active' : ''; ?>"><i
                            class="fas fa-bolt"></i> Quick Actions</a></li>
            <?php endif; ?>

            <?php if (adminHasRole(['superadmin', 'manager'])): ?>
                <li><a href="<?php echo SITE_URL; ?>/admin/bookings.php"
                        class="<?php echo basename($_SERVER['PHP_SELF']) == 'bookings.php' ? 'active' : ''; ?>"><i
                            class="fas fa-calendar-check"></i> Bookings</a></li>
                <li><a href="<?php echo SITE_URL; ?>/admin/contacts.php"
                        class="<?php echo basename($_SERVER['PHP_SELF']) == 'contacts.php' ? 'active' : ''; ?>"><i
                            class="fas fa-envelope"></i> Contacts</a></li>
                <li><a href="<?php echo SITE_URL; ?>/admin/subscribers.php"
                        class="<?php echo basename($_SERVER['PHP_SELF']) == 'subscribers.php' ? 'active' : ''; ?>"><i
                            class="fas fa-users"></i> Subscribers</a></li>
                <li><a href="<?php echo SITE_URL; ?>/admin/donations.php"
                        class="<?php echo basename($_SERVER['PHP_SELF']) == 'donations.php' ? 'active' : ''; ?>"><i
                            class="fas fa-hand-holding-usd"></i> Donations</a></li>
                <li><a href="<?php echo SITE_URL; ?>/admin/revenue.php"
                        class="<?php echo basename($_SERVER['PHP_SELF']) == 'revenue.php' ? 'active' : ''; ?>"><i
                            class="fas fa-chart-line"></i> Revenue</a></li>
                <li><a href="<?php echo SITE_URL; ?>/admin/reports.php"
                        class="<?php echo basename($_SERVER['PHP_SELF']) == 'reports.php' ? 'active' : ''; ?>"><i
                            class="fas fa-file-chart"></i> Reports</a></li>
            <?php endif; ?>

            <?php if (adminHasRole(['superadmin', 'content'])): ?>
                <li><a href="<?php echo SITE_URL; ?>/admin/pujas.php"
                        class="<?php echo basename($_SERVER['PHP_SELF']) == 'pujas.php' ? 'active' : ''; ?>"><i
                            class="fas fa-pray"></i> Pujas</a></li>
                <li><a href="<?php echo SITE_URL; ?>/admin/sevas.php"
                        class="<?php echo basename($_SERVER['PHP_SELF']) == 'sevas.php' ? 'active' : ''; ?>"><i
                            class="fas fa-hands"></i> Sevas</a></li>
                <li><a href="<?php echo SITE_URL; ?>/admin/temples.php"
                        class="<?php echo basename($_SERVER['PHP_SELF']) == 'temples.php' ? 'active' : ''; ?>"><i
                            class="fas fa-temple-hindu"></i> Temples</a></li>
                <li><a href="<?php echo SITE_URL; ?>/admin/priests.php"
                        class="<?php echo basename($_SERVER['PHP_SELF']) == 'priests.php' ? 'active' : ''; ?>"><i
                            class="fas fa-user-tie"></i> Priests</a></li>
                <li><a href="<?php echo SITE_URL; ?>/admin/events.php"
                        class="<?php echo basename($_SERVER['PHP_SELF']) == 'events.php' ? 'active' : ''; ?>"><i
                            class="fas fa-calendar-star"></i> Events</a></li>
                <li><a href="<?php echo SITE_URL; ?>/admin/calendar.php"
                        class="<?php echo basename($_SERVER['PHP_SELF']) == 'calendar.php' ? 'active' : ''; ?>"><i
                            class="fas fa-calendar-alt"></i> Calendar</a></li>
                <li><a href="<?php echo SITE_URL; ?>/admin/darshan.php"
                        class="<?php echo basename($_SERVER['PHP_SELF']) == 'darshan.php' ? 'active' : ''; ?>"><i
                            class="fas fa-clock"></i> Darshan Times</a></li>
                <li><a href="<?php echo SITE_URL; ?>/admin/gallery.php"
                        class="<?php echo basename($_SERVER['PHP_SELF']) == 'gallery.php' ? 'active' : ''; ?>"><i
                            class="fas fa-images"></i> Gallery</a></li>
                <li><a href="<?php echo SITE_URL; ?>/admin/blog.php"
                        class="<?php echo basename($_SERVER['PHP_SELF']) == 'blog.php' ? 'active' : ''; ?>"><i
                            class="fas fa-blog"></i> Blog</a></li>
                <li><a href="<?php echo SITE_URL; ?>/admin/testimonials.php"
                        class="<?php echo basename($_SERVER['PHP_SELF']) == 'testimonials.php' ? 'active' : ''; ?>"><i
                            class="fas fa-quote-right"></i> Testimonials</a></li>
                <li><a href="<?php echo SITE_URL; ?>/admin/faq.php"
                        class="<?php echo basename($_SERVER['PHP_SELF']) == 'faq.php' ? 'active' : ''; ?>"><i
                            class="fas fa-question-circle"></i> FAQ</a></li>
                <li><a href="<?php echo SITE_URL; ?>/admin/announcements.php"
                        class="<?php echo basename($_SERVER['PHP_SELF']) == 'announcements.php' ? 'active' : ''; ?>"><i
                            class="fas fa-bullhorn"></i> Announcements</a></li>
            <?php endif; ?>

            <?php if (adminHasRole(['superadmin'])): ?>
                <li><a href="<?php echo SITE_URL; ?>/admin/staff.php"
                        class="<?php echo basename($_SERVER['PHP_SELF']) == 'staff.php' ? 'active' : ''; ?>"><i
                            class="fas fa-user-friends"></i> Staff</a></li>
                <li><a href="<?php echo SITE_URL; ?>/admin/inventory.php"
                        class="<?php echo basename($_SERVER['PHP_SELF']) == 'inventory.php' ? 'active' : ''; ?>"><i
                            class="fas fa-boxes"></i> Inventory</a></li>
                <li><a href="<?php echo SITE_URL; ?>/admin/users.php"
                        class="<?php echo basename($_SERVER['PHP_SELF']) == 'users.php' ? 'active' : ''; ?>"><i
                            class="fas fa-user"></i> Users</a></li>
                <li><a href="<?php echo SITE_URL; ?>/admin/settings.php"
                        class="<?php echo basename($_SERVER['PHP_SELF']) == 'settings.php' ? 'active' : ''; ?>"><i
                            class="fas fa-cog"></i> Settings</a></li>
            <?php endif; ?>
        </ul>
        <div class="sidebar-footer">
            <a href="<?php echo SITE_URL; ?>/admin/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
    </aside>

    <!-- Main Content Wrapper -->
    <main class="admin-main">
        <!-- Top Header -->
        <header class="admin-topbar">
            <div class="topbar-title">
                <h1><?php echo isset($page_title) ? $page_title : 'Dashboard'; ?></h1>
            </div>
            <div class="topbar-actions">
                <!-- Search Bar -->
                <div class="search-wrapper">
                    <i class="fas fa-search search-icon"></i>
                    <input type="text" class="search-input" placeholder="Search bookings, users...">
                </div>

                <!-- Notifications -->
                <div class="notification-wrapper">
                    <div class="notification-bell">
                        <i class="fas fa-bell"></i>
                        <span class="notification-badge">3</span>
                    </div>
                </div>

                <!-- Date Widget -->
                <div class="date-widget">
                    <i class="far fa-calendar-alt"></i>
                    <span><?php echo date('D, M d'); ?></span>
                </div>

                <a href="<?php echo SITE_URL; ?>/index.php" target="_blank" class="btn-admin btn-outline">
                    <i class="fas fa-external-link-alt"></i> Site
                </a>
                <div class="user-profile">
                    <div class="user-avatar">
                        <?php echo strtoupper(substr(getAdminRole(), 0, 1)); ?>
                    </div>
                    <span><?php echo ucfirst(getAdminRole()); ?></span>
                </div>
            </div>
        </header>

        <!-- Content Area -->
        <div class="admin-content">