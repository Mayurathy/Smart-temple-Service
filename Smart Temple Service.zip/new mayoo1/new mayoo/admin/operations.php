<?php
require_once '../config/config.php';
requireAdminRole(['superadmin', 'manager', 'operations']);
$page_title = 'Operations Dashboard';
include 'includes/header.php';

$conn = getDBConnection();

// Get real-time operational stats
$today = date('Y-m-d');
$this_month = date('Y-m');

// Today's stats
$stats = [];
$stats['today_bookings'] = $conn->query("SELECT COUNT(*) as count FROM bookings WHERE DATE(created_at) = '$today'")->fetch_assoc()['count'] ?? 0;
$stats['pending_bookings'] = $conn->query("SELECT COUNT(*) as count FROM bookings WHERE status = 'pending'")->fetch_assoc()['count'] ?? 0;
$stats['today_contacts'] = $conn->query("SELECT COUNT(*) as count FROM contacts WHERE DATE(created_at) = '$today'")->fetch_assoc()['count'] ?? 0;
$stats['unread_contacts'] = $conn->query("SELECT COUNT(*) as count FROM contacts WHERE status = 'new'")->fetch_assoc()['count'] ?? 0;
$stats['today_donations'] = $conn->query("SELECT COALESCE(SUM(amount), 0) as total FROM donations WHERE DATE(created_at) = '$today'")->fetch_assoc()['total'] ?? 0;
$stats['month_revenue'] = $conn->query("SELECT COALESCE(SUM(amount), 0) as total FROM donations WHERE DATE_FORMAT(created_at, '%Y-%m') = '$this_month'")->fetch_assoc()['total'] ?? 0;

// Recent pending bookings
$pending_bookings = $conn->query("SELECT b.*, p.name as puja_name FROM bookings b 
                                   LEFT JOIN pujas p ON b.puja_id = p.id 
                                   WHERE b.status = 'pending' 
                                   ORDER BY b.created_at DESC LIMIT 10");

// Recent contacts
$recent_contacts = $conn->query("SELECT * FROM contacts WHERE status = 'new' ORDER BY created_at DESC LIMIT 8");
?>

<!-- Operations Header -->
<div class="operations-header">
    <div class="operations-title">
        <i class="fas fa-chart-line"></i>
        <div>
            <h2>Operations Control Center</h2>
            <p>Real-time operational metrics and pending tasks</p>
        </div>
    </div>
    <div class="operations-date">
        <i class="far fa-calendar-alt"></i>
        <span><?php echo date('l, F j, Y'); ?></span>
    </div>
</div>

<!-- Quick Stats Grid -->
<div class="operations-stats-grid">
    <div class="ops-stat-card urgent">
        <div class="ops-stat-icon">
            <i class="fas fa-exclamation-circle"></i>
        </div>
        <div class="ops-stat-content">
            <h3>Pending Bookings</h3>
            <div class="ops-stat-number"><?php echo $stats['pending_bookings']; ?></div>
            <p>Require immediate attention</p>
        </div>
        <div class="ops-stat-action">
            <a href="bookings.php" class="btn-ops-action">Review</a>
        </div>
    </div>

    <div class="ops-stat-card info">
        <div class="ops-stat-icon">
            <i class="fas fa-calendar-check"></i>
        </div>
        <div class="ops-stat-content">
            <h3>Today's Bookings</h3>
            <div class="ops-stat-number"><?php echo $stats['today_bookings']; ?></div>
            <p>New bookings today</p>
        </div>
    </div>

    <div class="ops-stat-card warning">
        <div class="ops-stat-icon">
            <i class="fas fa-envelope-open"></i>
        </div>
        <div class="ops-stat-content">
            <h3>Unread Messages</h3>
            <div class="ops-stat-number"><?php echo $stats['unread_contacts']; ?></div>
            <p>Contact inquiries</p>
        </div>
        <div class="ops-stat-action">
            <a href="contacts.php" class="btn-ops-action">Reply</a>
        </div>
    </div>

    <div class="ops-stat-card success">
        <div class="ops-stat-icon">
            <i class="fas fa-rupee-sign"></i>
        </div>
        <div class="ops-stat-content">
            <h3>Today's Revenue</h3>
            <div class="ops-stat-number">₹<?php echo number_format($stats['today_donations'], 0); ?></div>
            <p>Total donations today</p>
        </div>
    </div>
</div>

<!-- Operations Grid -->
<div class="operations-grid">
    <!-- Pending Actions -->
    <div class="ops-panel">
        <div class="ops-panel-header">
            <h3><i class="fas fa-tasks"></i> Pending Actions</h3>
            <span class="ops-badge"><?php echo $stats['pending_bookings']; ?></span>
        </div>
        <div class="ops-panel-body">
            <?php if ($pending_bookings && $pending_bookings->num_rows > 0): ?>
                <div class="ops-list">
                    <?php while ($booking = $pending_bookings->fetch_assoc()): ?>
                        <div class="ops-list-item">
                            <div class="ops-item-icon pending">
                                <i class="fas fa-clock"></i>
                            </div>
                            <div class="ops-item-content">
                                <h4><?php echo htmlspecialchars($booking['puja_name'] ?? 'Booking'); ?></h4>
                                <p><?php echo htmlspecialchars($booking['name']); ?> · <?php echo $booking['phone']; ?></p>
                                <span
                                    class="ops-time"><?php echo date('M d, h:i A', strtotime($booking['created_at'])); ?></span>
                            </div>
                            <div class="ops-item-actions">
                                <a href="bookings.php?id=<?php echo $booking['id']; ?>" class="btn-ops-quick">
                                    <i class="fas fa-check"></i>
                                </a>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php else: ?>
                <div class="ops-empty">
                    <i class="fas fa-check-circle"></i>
                    <p>All caught up! No pending bookings.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Recent Contacts -->
    <div class="ops-panel">
        <div class="ops-panel-header">
            <h3><i class="fas fa-comments"></i> New Inquiries</h3>
            <span class="ops-badge warning"><?php echo $stats['unread_contacts']; ?></span>
        </div>
        <div class="ops-panel-body">
            <?php if ($recent_contacts && $recent_contacts->num_rows > 0): ?>
                <div class="ops-list">
                    <?php while ($contact = $recent_contacts->fetch_assoc()): ?>
                        <div class="ops-list-item">
                            <div class="ops-item-icon info">
                                <i class="fas fa-user"></i>
                            </div>
                            <div class="ops-item-content">
                                <h4><?php echo htmlspecialchars($contact['name']); ?></h4>
                                <p><?php echo htmlspecialchars(substr($contact['message'], 0, 60)) . '...'; ?></p>
                                <span
                                    class="ops-time"><?php echo date('M d, h:i A', strtotime($contact['created_at'])); ?></span>
                            </div>
                            <div class="ops-item-actions">
                                <a href="contacts.php?id=<?php echo $contact['id']; ?>" class="btn-ops-quick">
                                    <i class="fas fa-reply"></i>
                                </a>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php else: ?>
                <div class="ops-empty">
                    <i class="fas fa-inbox"></i>
                    <p>No new inquiries</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Performance Summary -->
<div class="performance-summary">
    <div class="performance-card">
        <div class="performance-header">
            <h3>This Month's Performance</h3>
            <i class="fas fa-chart-line"></i>
        </div>
        <div class="performance-stats">
            <div class="perf-item">
                <span class="perf-label">Total Revenue</span>
                <span class="perf-value">₹<?php echo number_format($stats['month_revenue'], 2); ?></span>
            </div>
            <div class="perf-divider"></div>
            <div class="perf-item">
                <span class="perf-label">Avg. Daily</span>
                <span class="perf-value">₹<?php echo number_format($stats['month_revenue'] / date('d'), 2); ?></span>
            </div>
        </div>
    </div>
</div>

<style>
    /* Operations Dashboard Specific Styles */
    .operations-header {
        background: linear-gradient(135deg, #4a0404 0%, #2a0202 100%);
        border-radius: 20px;
        padding: 30px 40px;
        margin-bottom: 30px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        color: white;
        box-shadow: 0 10px 30px rgba(74, 4, 4, 0.3);
    }

    .operations-title {
        display: flex;
        align-items: center;
        gap: 20px;
    }

    .operations-title>i {
        font-size: 48px;
        color: #D4AF37;
    }

    .operations-title h2 {
        margin: 0;
        font-size: 28px;
        font-weight: 700;
        color: #D4AF37;
    }

    .operations-title p {
        margin: 5px 0 0 0;
        opacity: 0.9;
        font-size: 14px;
    }

    .operations-date {
        display: flex;
        align-items: center;
        gap: 10px;
        background: rgba(255, 255, 255, 0.1);
        padding: 12px 20px;
        border-radius: 12px;
        font-weight: 600;
    }

    /* Operations Stats Grid */
    .operations-stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
        gap: 25px;
        margin-bottom: 35px;
    }

    .ops-stat-card {
        background: white;
        border-radius: 18px;
        padding: 25px;
        display: flex;
        gap: 20px;
        align-items: center;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
        border-left: 4px solid;
        transition: all 0.3s ease;
    }

    .ops-stat-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 8px 25px rgba(0, 0, 0, 0.12);
    }

    .ops-stat-card.urgent {
        border-left-color: #dc2626;
    }

    .ops-stat-card.info {
        border-left-color: #3b82f6;
    }

    .ops-stat-card.warning {
        border-left-color: #f59e0b;
    }

    .ops-stat-card.success {
        border-left-color: #10b981;
    }

    .ops-stat-icon {
        width: 60px;
        height: 60px;
        border-radius: 14px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 26px;
        flex-shrink: 0;
    }

    .urgent .ops-stat-icon {
        background: linear-gradient(135deg, #fee2e2, #fecaca);
        color: #dc2626;
    }

    .info .ops-stat-icon {
        background: linear-gradient(135deg, #dbeafe, #bfdbfe);
        color: #3b82f6;
    }

    .warning .ops-stat-icon {
        background: linear-gradient(135deg, #fef3c7, #fde68a);
        color: #f59e0b;
    }

    .success .ops-stat-icon {
        background: linear-gradient(135deg, #d1fae5, #a7f3d0);
        color: #10b981;
    }

    .ops-stat-content {
        flex: 1;
    }

    .ops-stat-content h3 {
        margin: 0 0 8px 0;
        font-size: 13px;
        font-weight: 600;
        color: #6b7280;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    .ops-stat-number {
        font-size: 32px;
        font-weight: 800;
        color: #1a1a1a;
        line-height: 1;
        margin-bottom: 5px;
    }

    .ops-stat-content p {
        margin: 0;
        font-size: 12px;
        color: #9ca3af;
    }

    .btn-ops-action {
        background: linear-gradient(135deg, #4a0404, #8B0000);
        color: white;
        padding: 8px 20px;
        border-radius: 8px;
        text-decoration: none;
        font-size: 13px;
        font-weight: 600;
        transition: all 0.3s ease;
    }

    .btn-ops-action:hover {
        transform: scale(1.05);
        box-shadow: 0 4px 15px rgba(139, 0, 0, 0.3);
    }

    /* Operations Grid */
    .operations-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 25px;
        margin-bottom: 30px;
    }

    .ops-panel {
        background: white;
        border-radius: 20px;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.06);
        overflow: hidden;
    }

    .ops-panel-header {
        background: linear-gradient(135deg, #f8fafc, #f1f5f9);
        padding: 20px 25px;
        border-bottom: 2px solid #e2e8f0;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .ops-panel-header h3 {
        margin: 0;
        font-size: 16px;
        font-weight: 700;
        color: #1e293b;
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .ops-badge {
        background: #4a0404;
        color: white;
        padding: 4px 12px;
        border-radius: 12px;
        font-size: 12px;
        font-weight: 700;
    }

    .ops-badge.warning {
        background: #f59e0b;
    }

    .ops-panel-body {
        padding: 20px;
        max-height: 500px;
        overflow-y: auto;
    }

    .ops-list {
        display: flex;
        flex-direction: column;
        gap: 12px;
    }

    .ops-list-item {
        display: flex;
        gap: 15px;
        padding: 15px;
        background: #fafafa;
        border-radius: 12px;
        transition: all 0.3s ease;
    }

    .ops-list-item:hover {
        background: #f0f0f0;
        transform: translateX(5px);
    }

    .ops-item-icon {
        width: 40px;
        height: 40px;
        border-radius: 10px;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
    }

    .ops-item-icon.pending {
        background: #fef3c7;
        color: #f59e0b;
    }

    .ops-item-icon.info {
        background: #dbeafe;
        color: #3b82f6;
    }

    .ops-item-content {
        flex: 1;
    }

    .ops-item-content h4 {
        margin: 0 0 5px 0;
        font-size: 14px;
        font-weight: 700;
        color: #1a1a1a;
    }

    .ops-item-content p {
        margin: 0 0 5px 0;
        font-size: 13px;
        color: #6b7280;
    }

    .ops-time {
        font-size: 11px;
        color: #9ca3af;
    }

    .btn-ops-quick {
        width: 36px;
        height: 36px;
        border-radius: 8px;
        background: linear-gradient(135deg, #4a0404, #8B0000);
        color: white;
        display: flex;
        align-items: center;
        justify-content: center;
        text-decoration: none;
        transition: all 0.3s ease;
    }

    .btn-ops-quick:hover {
        transform: scale(1.1);
        box-shadow: 0 4px 12px rgba(139, 0, 0, 0.3);
    }

    .ops-empty {
        text-align: center;
        padding: 40px 20px;
        color: #9ca3af;
    }

    .ops-empty i {
        font-size: 48px;
        margin-bottom: 15px;
        color: #d1d5db;
    }

    /* Performance Summary */
    .performance-summary {
        margin-top: 30px;
    }

    .performance-card {
        background: linear-gradient(135deg, #D4AF37, #F4E5BC);
        border-radius: 20px;
        padding: 30px;
        color: #1a1a1a;
    }

    .performance-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
    }

    .performance-header h3 {
        margin: 0;
        font-size: 20px;
        font-weight: 700;
    }

    .performance-header i {
        font-size: 32px;
        opacity: 0.3;
    }

    .performance-stats {
        display: flex;
        gap: 30px;
        align-items: center;
    }

    .perf-item {
        display: flex;
        flex-direction: column;
        gap: 5px;
    }

    .perf-label {
        font-size: 13px;
        opacity: 0.8;
        font-weight: 600;
    }

    .perf-value {
        font-size: 32px;
        font-weight: 800;
    }

    .perf-divider {
        width: 2px;
        height: 50px;
        background: rgba(0, 0, 0, 0.2);
    }

    @media (max-width: 1200px) {
        .operations-grid {
            grid-template-columns: 1fr;
        }
    }

    @media (max-width: 768px) {
        .operations-header {
            flex-direction: column;
            gap: 20px;
            text-align: center;
        }

        .operations-stats-grid {
            grid-template-columns: 1fr;
        }
    }
</style>

<?php
$conn->close();
include 'includes/footer.php';
?>