<?php
require_once '../config/config.php';
$page_title = 'Manage Users';
include 'includes/header.php';

$conn = getDBConnection();
$message = '';

// Ensure users table exists (for installs where signup hasn't run yet)
$conn->query("CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    phone VARCHAR(25) NOT NULL,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// Delete user
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    // Do not allow deleting currently logged in admin by mistake (separate tables, but guard anyway)
    $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $stmt->close();
    $message = 'User removed.';
}

// List users
$users = $conn->query("SELECT id, name, email, phone, created_at FROM users ORDER BY id DESC");
?>

<h2>Users</h2>

<?php if ($message): ?>
    <div class="success-message"><?php echo $message; ?></div>
<?php endif; ?>

<div class="admin-table">
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Created</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($users && $users->num_rows > 0): ?>
                <?php while ($u = $users->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $u['id']; ?></td>
                        <td><?php echo htmlspecialchars($u['name']); ?></td>
                        <td><?php echo htmlspecialchars($u['email']); ?></td>
                        <td><?php echo htmlspecialchars($u['phone']); ?></td>
                        <td><?php echo date('d M Y', strtotime($u['created_at'])); ?></td>
                        <td>
                            <a href="<?php echo SITE_URL; ?>/admin/users.php?delete=<?php echo $u['id']; ?>" onclick="return confirm('Delete this user?')" style="text-decoration: none; color: #dc2626;">
                                <i class="fas fa-trash"></i> Delete
                            </a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="6" style="text-align:center;">No users yet.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
    
</div>

<?php
$conn->close();
include 'includes/footer.php';
?>


