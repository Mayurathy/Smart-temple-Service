<?php
require_once '../config/config.php';
requireAdminRole(['superadmin','operations']);
$page_title = 'Manage Subscribers';
include 'includes/header.php';

$conn = getDBConnection();

// Handle delete
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $conn->query("DELETE FROM subscribers WHERE id = $id");
    redirect('/admin/subscribers.php');
}

// Get all subscribers
$subscribers = $conn->query("SELECT * FROM subscribers ORDER BY subscribed_at DESC");
?>

<h2>Email Subscribers</h2>

<div class="admin-table">
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Email</th>
                <th>Subscribed Date</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($subscribers && $subscribers->num_rows > 0): ?>
                <?php while ($subscriber = $subscribers->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $subscriber['id']; ?></td>
                        <td><?php echo htmlspecialchars($subscriber['email']); ?></td>
                        <td><?php echo date('d M Y', strtotime($subscriber['subscribed_at'])); ?></td>
                        <td>
                            <a href="<?php echo SITE_URL; ?>/admin/subscribers.php?delete=<?php echo $subscriber['id']; ?>" onclick="return confirm('Are you sure?')" style="text-decoration: none; color: #dc2626;">
                                <i class="fas fa-trash"></i> Delete
                            </a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="4" style="text-align: center;">No subscribers found</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php
$conn->close();
include 'includes/footer.php';
?>

