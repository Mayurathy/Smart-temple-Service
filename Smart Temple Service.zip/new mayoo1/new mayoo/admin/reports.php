<?php
require_once '../config/config.php';
requireAdminRole(['superadmin', 'manager']);
$page_title = 'Reports & Analytics';
include 'includes/header.php';
?>

<h2>Reports & Analytics</h2>

<div class="dashboard-grid">
    <div class="stat-card">
        <h3>System Reports</h3>
        <p style="margin-top: 15px;">Generate and download comprehensive reports for bookings, revenue, users, and more.
        </p>
        <i class="fas fa-chart-bar stat-icon"></i>
    </div>

    <div class="stat-card">
        <h3>Export Data</h3>
        <p style="margin-top: 15px;">Export data to CSV, PDF, or Excel format for further analysis.</p>
        <i class="fas fa-file-export stat-icon"></i>
    </div>
</div>

<div class="admin-table-container">
    <h3>Available Reports</h3>
    <ul style="list-style: none; padding: 20px;">
        <li style="margin-bottom: 10px;">📊 Monthly Revenue Report</li>
        <li style="margin-bottom: 10px;">📅 Booking Statistics</li>
        <li style="margin-bottom: 10px;">👥 User Activity Report</li>
        <li style="margin-bottom: 10px;">💰 Donation Summary</li>
        <li style="margin-bottom: 10px;">📧 Email Campaign Analytics</li>
    </ul>
    <p style="padding: 20px; color: #666;"><em>Full reporting functionality coming soon...</em></p>
</div>

<?php include 'includes/footer.php'; ?>