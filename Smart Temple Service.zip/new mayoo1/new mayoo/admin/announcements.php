<?php
require_once '../config/config.php';
requireAdminRole(['superadmin', 'content']);
$page_title = 'Manage Announcements';
include 'includes/header.php';

$conn = getDBConnection();
$message = '';
$message_type = '';

// Create announcements table if not exists
$conn->query("CREATE TABLE IF NOT EXISTS announcements (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    priority ENUM('low', 'medium', 'high', 'urgent') DEFAULT 'medium',
    start_date DATE NOT NULL,
    end_date DATE,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_status (status),
    INDEX idx_dates (start_date, end_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

// Handle delete
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    if ($conn->query("DELETE FROM announcements WHERE id = $id")) {
        $message = 'Announcement deleted successfully';
        $message_type = 'success';
    } else {
        $message = 'Error deleting announcement';
        $message_type = 'error';
    }
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = sanitize($_POST['title']);
    $announcement_message = sanitize($_POST['message']);
    $priority = sanitize($_POST['priority']);
    $start_date = sanitize($_POST['start_date']);
    $end_date = !empty($_POST['end_date']) ? sanitize($_POST['end_date']) : NULL;
    $status = sanitize($_POST['status']);
    $created_by = $_SESSION['admin_id'];

    if (isset($_POST['announcement_id']) && $_POST['announcement_id'] > 0) {
        // Update
        $id = intval($_POST['announcement_id']);
        $query = "UPDATE announcements SET title = ?, message = ?, priority = ?, start_date = ?, end_date = ?, status = ? WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ssssssi", $title, $announcement_message, $priority, $start_date, $end_date, $status, $id);

        if ($stmt->execute()) {
            $message = 'Announcement updated successfully';
            $message_type = 'success';
        } else {
            $message = 'Error updating announcement';
            $message_type = 'error';
        }
        $stmt->close();
    } else {
        // Insert
        $query = "INSERT INTO announcements (title, message, priority, start_date, end_date, status, created_by) VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ssssssi", $title, $announcement_message, $priority, $start_date, $end_date, $status, $created_by);

        if ($stmt->execute()) {
            $message = 'Announcement created successfully';
            $message_type = 'success';
        } else {
            $message = 'Error creating announcement: ' . $conn->error;
            $message_type = 'error';
        }
        $stmt->close();
    }
}

// Get announcement for edit
$edit_announcement = null;
if (isset($_GET['edit'])) {
    $id = intval($_GET['edit']);
    $result = $conn->query("SELECT * FROM announcements WHERE id = $id");
    if ($result && $result->num_rows > 0) {
        $edit_announcement = $result->fetch_assoc();
    }
}

// Get all announcements
$announcements = $conn->query("SELECT * FROM announcements ORDER BY priority DESC, created_at DESC");
?>

<h2>Manage Announcements</h2>

<?php if ($message): ?>
    <div class="alert <?php echo $message_type === 'success' ? 'alert-success' : 'alert-error'; ?>"
        style="margin-bottom: 20px;">
        <?php echo $message; ?>
    </div>
<?php endif; ?>

<button onclick="document.getElementById('announcementForm').style.display='block'" class="btn-admin btn-primary"
    style="margin-bottom: 20px;">
    <i class="fas fa-plus"></i> <?php echo $edit_announcement ? 'Update' : 'Create New'; ?> Announcement
</button>

<!-- Announcement Form -->
<div id="announcementForm" class="form-container"
    style="display: <?php echo $edit_announcement ? 'block' : 'none'; ?>; max-width: 800px; margin-bottom: 30px; background: white; padding: 25px; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
    <h3><?php echo $edit_announcement ? 'Edit' : 'Create New'; ?> Announcement</h3>
    <form method="POST" action="">
        <input type="hidden" name="announcement_id"
            value="<?php echo $edit_announcement ? $edit_announcement['id'] : 0; ?>">

        <div class="form-group">
            <label>Title *</label>
            <input type="text" name="title"
                value="<?php echo $edit_announcement ? htmlspecialchars($edit_announcement['title']) : ''; ?>" required
                placeholder="e.g., Special Puja on Diwali">
        </div>

        <div class="form-group">
            <label>Message *</label>
            <textarea name="message" required rows="5"
                placeholder="Enter announcement details..."><?php echo $edit_announcement ? htmlspecialchars($edit_announcement['message']) : ''; ?></textarea>
        </div>

        <div class="form-row" style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
            <div class="form-group">
                <label>Priority *</label>
                <select name="priority" required>
                    <option value="low" <?php echo ($edit_announcement && $edit_announcement['priority'] == 'low') ? 'selected' : ''; ?>>🟢 Low</option>
                    <option value="medium" <?php echo (!$edit_announcement || $edit_announcement['priority'] == 'medium') ? 'selected' : ''; ?>>🟡 Medium</option>
                    <option value="high" <?php echo ($edit_announcement && $edit_announcement['priority'] == 'high') ? 'selected' : ''; ?>>🟠 High</option>
                    <option value="urgent" <?php echo ($edit_announcement && $edit_announcement['priority'] == 'urgent') ? 'selected' : ''; ?>>🔴 Urgent</option>
                </select>
            </div>

            <div class="form-group">
                <label>Status *</label>
                <select name="status" required>
                    <option value="active" <?php echo (!$edit_announcement || $edit_announcement['status'] == 'active') ? 'selected' : ''; ?>>Active</option>
                    <option value="inactive" <?php echo ($edit_announcement && $edit_announcement['status'] == 'inactive') ? 'selected' : ''; ?>>Inactive</option>
                </select>
            </div>
        </div>

        <div class="form-row" style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
            <div class="form-group">
                <label>Start Date *</label>
                <input type="date" name="start_date"
                    value="<?php echo $edit_announcement ? $edit_announcement['start_date'] : date('Y-m-d'); ?>"
                    required>
            </div>

            <div class="form-group">
                <label>End Date <small>(Optional)</small></label>
                <input type="date" name="end_date"
                    value="<?php echo $edit_announcement ? $edit_announcement['end_date'] : ''; ?>">
            </div>
        </div>

        <div style="display: flex; gap: 10px; margin-top: 20px;">
            <button type="submit" class="btn-admin btn-primary">
                <i class="fas fa-save"></i> <?php echo $edit_announcement ? 'Update' : 'Create'; ?> Announcement
            </button>
            <a href="<?php echo SITE_URL; ?>/admin/announcements.php" class="btn-admin" style="text-decoration: none;">
                <i class="fas fa-times"></i> Cancel
            </a>
        </div>
    </form>
</div>

<!-- Announcements Table -->
<div class="admin-table-container">
    <div class="admin-table">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Title</th>
                    <th>Priority</th>
                    <th>Start Date</th>
                    <th>End Date</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($announcements && $announcements->num_rows > 0): ?>
                    <?php while ($announcement = $announcements->fetch_assoc()):
                        $priority_colors = [
                            'low' => '#10b981',
                            'medium' => '#f59e0b',
                            'high' => '#f97316',
                            'urgent' => '#ef4444'
                        ];
                        $priority_icons = [
                            'low' => '🟢',
                            'medium' => '🟡',
                            'high' => '🟠',
                            'urgent' => '🔴'
                        ];
                        ?>
                        <tr>
                            <td><?php echo $announcement['id']; ?></td>
                            <td>
                                <strong><?php echo htmlspecialchars($announcement['title']); ?></strong>
                                <br>
                                <small style="color: #666;"><?php echo truncate($announcement['message'], 60); ?></small>
                            </td>
                            <td>
                                <span
                                    style="padding: 4px 12px; background: <?php echo $priority_colors[$announcement['priority']]; ?>; color: white; border-radius: 12px; font-size: 12px; font-weight: 500;">
                                    <?php echo $priority_icons[$announcement['priority']] . ' ' . ucfirst($announcement['priority']); ?>
                                </span>
                            </td>
                            <td><?php echo date('M d, Y', strtotime($announcement['start_date'])); ?></td>
                            <td><?php echo $announcement['end_date'] ? date('M d, Y', strtotime($announcement['end_date'])) : '<em>No expiry</em>'; ?>
                            </td>
                            <td><?php echo getStatusBadge($announcement['status']); ?></td>
                            <td>
                                <a href="<?php echo SITE_URL; ?>/admin/announcements.php?edit=<?php echo $announcement['id']; ?>"
                                    class="btn-icon" title="Edit">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <a href="<?php echo SITE_URL; ?>/admin/announcements.php?delete=<?php echo $announcement['id']; ?>"
                                    onclick="return confirm('Are you sure you want to delete this announcement?')"
                                    class="btn-icon" title="Delete" style="color: #ef4444;">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" style="text-align: center; padding: 40px;">
                            <i class="fas fa-bullhorn" style="font-size: 48px; color: #ddd; margin-bottom: 15px;"></i>
                            <p style="color: #666;">No announcements posted. Click "Create New Announcement" to notify
                                devotees.</p>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<style>
    .form-container {
        animation: fadeIn 0.3s ease;
    }

    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translateY(-10px);
        }

        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .form-group {
        margin-bottom: 20px;
    }

    .form-group label {
        display: block;
        margin-bottom: 8px;
        font-weight: 600;
        color: #374151;
    }

    .form-group label small {
        font-weight: 400;
        color: #9ca3af;
    }

    .form-group input,
    .form-group textarea,
    .form-group select {
        width: 100%;
        padding: 12px;
        border: 1px solid #e5e7eb;
        border-radius: 8px;
        font-size: 14px;
        transition: all 0.3s ease;
    }

    .form-group input:focus,
    .form-group textarea:focus,
    .form-group select:focus {
        outline: none;
        border-color: var(--primary-gold);
        box-shadow: 0 0 0 3px rgba(212, 175, 55, 0.1);
    }

    .btn-icon {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 32px;
        height: 32px;
        border-radius: 6px;
        transition: all 0.2s ease;
        color: var(--primary-gold);
        text-decoration: none;
        margin: 0 4px;
    }

    .btn-icon:hover {
        background: rgba(212, 175, 55, 0.1);
        transform: scale(1.1);
    }

    .alert {
        padding: 12px 20px;
        border-radius: 8px;
        font-weight: 500;
    }

    .alert-success {
        background: #d1fae5;
        color: #065f46;
        border: 1px solid #6ee7b7;
    }

    .alert-error {
        background: #fee2e2;
        color: #991b1b;
        border: 1px solid #fca5a5;
    }
</style>

<?php
$conn->close();
include 'includes/footer.php';
?>