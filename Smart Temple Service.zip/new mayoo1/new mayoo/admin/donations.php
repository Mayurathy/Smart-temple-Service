<?php
require_once '../config/config.php';
requireAdminRole(['superadmin','operations']);
$page_title = 'Donations';
include 'includes/header.php';

$conn = getDBConnection();
// Ensure table exists
$conn->query("CREATE TABLE IF NOT EXISTS donations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    donor_name VARCHAR(255) NOT NULL,
    donor_email VARCHAR(255) NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    purpose VARCHAR(255) DEFAULT NULL,
    card_last4 VARCHAR(4) DEFAULT NULL,
    status ENUM('received','failed') DEFAULT 'received',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$donations = $conn->query("SELECT * FROM donations ORDER BY created_at DESC");
?>

<h2>Donations</h2>

<div class="admin-table">
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Donor</th>
                <th>Email</th>
                <th>Amount</th>
                <th>Purpose</th>
                <th>Card last4</th>
                <th>Date</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($donations && $donations->num_rows > 0): ?>
                <?php while ($d = $donations->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $d['id']; ?></td>
                        <td><?php echo htmlspecialchars($d['donor_name']); ?></td>
                        <td><?php echo htmlspecialchars($d['donor_email']); ?></td>
                        <td>₹<?php echo number_format($d['amount'], 2); ?></td>
                        <td><?php echo htmlspecialchars($d['purpose']); ?></td>
                        <td><?php echo htmlspecialchars($d['card_last4']); ?></td>
                        <td><?php echo date('d M Y H:i', strtotime($d['created_at'])); ?></td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="7" style="text-align:center;">No donations yet.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php include 'includes/footer.php'; ?>


