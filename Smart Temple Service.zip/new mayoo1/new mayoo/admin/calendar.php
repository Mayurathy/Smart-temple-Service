<?php
require_once '../config/config.php';
requireAdminRole(['superadmin', 'content']);
$page_title = 'Temple Calendar';
include 'includes/header.php';
?>

<h2>Temple Calendar</h2>

<div class="admin-table-container">
    <div style="padding: 40px; text-align: center;">
        <i class="fas fa-calendar-alt" style="font-size: 64px; color: #D4AF37; margin-bottom: 20px;"></i>
        <h3>Calendar View</h3>
        <p style="color: #666; margin: 20px 0;">Full calendar with events, pujas, and festival dates will be displayed
            here.</p>
        <p style="color: #999;"><em>Calendar integration coming soon...</em></p>
    </div>
</div>

<?php include 'includes/footer.php'; ?>