<?php
require_once '../config/config.php';
$page_title = 'View Contact';
include 'includes/header.php';

$conn = getDBConnection();
$contact_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

$query = "SELECT * FROM contacts WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $contact_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    redirect('/admin/contacts.php');
}

$contact = $result->fetch_assoc();

// Mark as read
if ($contact['status'] == 'new') {
    $conn->query("UPDATE contacts SET status = 'read' WHERE id = $contact_id");
}
?>

<h2>Contact Message Details</h2>

<div class="form-container" style="max-width: 800px;">
    <table style="width: 100%;">
        <tr>
            <td style="padding: 10px; font-weight: bold;">Name:</td>
            <td style="padding: 10px;"><?php echo htmlspecialchars($contact['name']); ?></td>
        </tr>
        <tr>
            <td style="padding: 10px; font-weight: bold;">Email:</td>
            <td style="padding: 10px;"><?php echo htmlspecialchars($contact['email']); ?></td>
        </tr>
        <tr>
            <td style="padding: 10px; font-weight: bold;">Phone:</td>
            <td style="padding: 10px;"><?php echo htmlspecialchars($contact['phone']); ?></td>
        </tr>
        <tr>
            <td style="padding: 10px; font-weight: bold;">Subject:</td>
            <td style="padding: 10px;"><?php echo htmlspecialchars($contact['subject']); ?></td>
        </tr>
        <tr>
            <td style="padding: 10px; font-weight: bold;">Message:</td>
            <td style="padding: 10px;"><?php echo nl2br(htmlspecialchars($contact['message'])); ?></td>
        </tr>
        <tr>
            <td style="padding: 10px; font-weight: bold;">Date:</td>
            <td style="padding: 10px;"><?php echo date('d M Y H:i', strtotime($contact['created_at'])); ?></td>
        </tr>
    </table>
    
    <div style="margin-top: 30px;">
        <a href="<?php echo SITE_URL; ?>/admin/contacts.php" class="btn">Back to Contacts</a>
    </div>
</div>

<?php
$stmt->close();
$conn->close();
include 'includes/footer.php';
?>

