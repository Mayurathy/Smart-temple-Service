<?php
require_once '../config/config.php';
requireAdminRole(['superadmin','operations']);
$page_title = 'View Booking';
include 'includes/header.php';

$conn = getDBConnection();
$booking_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

$query = "SELECT b.*, p.name as puja_name, p.price as puja_price, 
          t.name as temple_name, pr.name as priest_name 
          FROM bookings b 
          LEFT JOIN pujas p ON b.puja_id = p.id 
          LEFT JOIN temples t ON b.temple_id = t.id 
          LEFT JOIN priests pr ON b.priest_id = pr.id 
          WHERE b.id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $booking_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    redirect('/admin/bookings.php');
}

$booking = $result->fetch_assoc();
?>

<h2>Booking Details</h2>

<div class="form-container" style="max-width: 800px;">
    <div style="background: #f3f4f6; padding: 20px; border-radius: 5px; margin-bottom: 20px;">
        <h3>Booking ID: <?php echo htmlspecialchars($booking['booking_id']); ?></h3>
        <p><strong>Status:</strong> 
            <span class="status-badge status-<?php echo $booking['status']; ?>">
                <?php echo ucfirst($booking['status']); ?>
            </span>
        </p>
    </div>
    
    <h3 style="margin-top: 30px; margin-bottom: 15px;">Customer Information</h3>
    <table style="width: 100%; margin-bottom: 30px;">
        <tr>
            <td style="padding: 10px; font-weight: bold;">Name:</td>
            <td style="padding: 10px;"><?php echo htmlspecialchars($booking['user_name']); ?></td>
        </tr>
        <tr>
            <td style="padding: 10px; font-weight: bold;">Email:</td>
            <td style="padding: 10px;"><?php echo htmlspecialchars($booking['user_email']); ?></td>
        </tr>
        <tr>
            <td style="padding: 10px; font-weight: bold;">Phone:</td>
            <td style="padding: 10px;"><?php echo htmlspecialchars($booking['user_phone']); ?></td>
        </tr>
    </table>
    
    <h3 style="margin-top: 30px; margin-bottom: 15px;">Booking Information</h3>
    <table style="width: 100%; margin-bottom: 30px;">
        <tr>
            <td style="padding: 10px; font-weight: bold;">Booking Type:</td>
            <td style="padding: 10px;"><?php echo ucfirst($booking['booking_type']); ?></td>
        </tr>
        <?php if ($booking['puja_name']): ?>
        <tr>
            <td style="padding: 10px; font-weight: bold;">Puja:</td>
            <td style="padding: 10px;"><?php echo htmlspecialchars($booking['puja_name']); ?> - ₹<?php echo number_format($booking['puja_price'], 2); ?></td>
        </tr>
        <?php endif; ?>
        <?php if ($booking['temple_name']): ?>
        <tr>
            <td style="padding: 10px; font-weight: bold;">Temple:</td>
            <td style="padding: 10px;"><?php echo htmlspecialchars($booking['temple_name']); ?></td>
        </tr>
        <?php endif; ?>
        <?php if ($booking['priest_name']): ?>
        <tr>
            <td style="padding: 10px; font-weight: bold;">Priest:</td>
            <td style="padding: 10px;"><?php echo htmlspecialchars($booking['priest_name']); ?></td>
        </tr>
        <?php endif; ?>
        <tr>
            <td style="padding: 10px; font-weight: bold;">Booking Date:</td>
            <td style="padding: 10px;"><?php echo date('d M Y', strtotime($booking['booking_date'])); ?></td>
        </tr>
        <tr>
            <td style="padding: 10px; font-weight: bold;">Booking Time:</td>
            <td style="padding: 10px;"><?php echo date('h:i A', strtotime($booking['booking_time'])); ?></td>
        </tr>
        <?php if ($booking['address']): ?>
        <tr>
            <td style="padding: 10px; font-weight: bold;">Address:</td>
            <td style="padding: 10px;"><?php echo nl2br(htmlspecialchars($booking['address'])); ?></td>
        </tr>
        <?php endif; ?>
        <?php if ($booking['special_requests']): ?>
        <tr>
            <td style="padding: 10px; font-weight: bold;">Special Requests:</td>
            <td style="padding: 10px;"><?php echo nl2br(htmlspecialchars($booking['special_requests'])); ?></td>
        </tr>
        <?php endif; ?>
    </table>
    
    <div style="margin-top: 30px;">
        <a href="<?php echo SITE_URL; ?>/admin/bookings.php" class="btn">Back to Bookings</a>
    </div>
</div>

<?php
$stmt->close();
$conn->close();
include 'includes/footer.php';
?>

