<?php
require_once '../config/config.php';
requireAdminRole(['superadmin', 'content']);
$page_title = 'Manage Sevas';
include 'includes/header.php';
?>

<h2>Seva Services</h2>

<div style="text-align: right; margin-bottom: 20px;">
    <a href="#" class="btn-admin btn-primary">
        <i class="fas fa-plus"></i> Add New Seva
    </a>
</div>

<div class="admin-table-container">
    <div class="admin-table">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Seva Name</th>
                    <th>Price</th>
                    <th>Duration</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td colspan="6" style="text-align: center; padding: 40px;">
                        <i class="fas fa-hands" style="font-size: 48px; color: #ddd; margin-bottom: 15px;"></i>
                        <p>No sevas found. Click "Add New Seva" to get started.</p>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<?php include 'includes/footer.php'; ?>