<?php
require_once '../config/config.php';
requireAdminRole(['superadmin', 'content']);
$page_title = 'Manage Pujas';
include 'includes/header.php';

$conn = getDBConnection();
$message = '';

// Handle delete
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $conn->query("UPDATE pujas SET status = 'inactive' WHERE id = $id");
    $message = 'Puja deleted successfully';
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = sanitize($_POST['name']);
    $slug = strtolower(str_replace(' ', '-', $name));
    $description = sanitize($_POST['description']);
    $significance = sanitize($_POST['significance']);
    $when_to_perform = sanitize($_POST['when_to_perform']);
    $advantages = sanitize($_POST['advantages']);
    $price = floatval($_POST['price']);
    $category = sanitize($_POST['category']);

    // Handle image upload
    $image_name = '';
    $upload_dir = '../assets/images/pujas/';

    // Create directory if it doesn't exist
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }

    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $allowed_types = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
        $file_type = $_FILES['image']['type'];

        if (in_array($file_type, $allowed_types)) {
            $file_extension = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
            $image_name = $slug . '-' . time() . '.' . $file_extension;
            $upload_path = $upload_dir . $image_name;

            if (move_uploaded_file($_FILES['image']['tmp_name'], $upload_path)) {
                // Image uploaded successfully
            } else {
                $message = 'Failed to upload image';
            }
        } else {
            $message = 'Invalid image type. Only JPG, PNG, and WEBP are allowed';
        }
    }

    if (isset($_POST['puja_id']) && $_POST['puja_id'] > 0) {
        // Update
        $id = intval($_POST['puja_id']);

        if ($image_name) {
            // If new image uploaded, update with image
            $update_query = "UPDATE pujas SET name = ?, slug = ?, description = ?, significance = ?, when_to_perform = ?, advantages = ?, price = ?, category = ?, image = ? WHERE id = ?";
            $stmt = $conn->prepare($update_query);
            $stmt->bind_param("ssssssdssi", $name, $slug, $description, $significance, $when_to_perform, $advantages, $price, $category, $image_name, $id);
        } else {
            // Update without changing image
            $update_query = "UPDATE pujas SET name = ?, slug = ?, description = ?, significance = ?, when_to_perform = ?, advantages = ?, price = ?, category = ? WHERE id = ?";
            $stmt = $conn->prepare($update_query);
            $stmt->bind_param("ssssssdsi", $name, $slug, $description, $significance, $when_to_perform, $advantages, $price, $category, $id);
        }
        $stmt->execute();
        $message = 'Puja updated successfully';
    } else {
        // Insert
        $insert_query = "INSERT INTO pujas (name, slug, description, significance, when_to_perform, advantages, price, category, image) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($insert_query);
        $stmt->bind_param("ssssssdss", $name, $slug, $description, $significance, $when_to_perform, $advantages, $price, $category, $image_name);
        $stmt->execute();
        $message = 'Puja added successfully';
    }
    $stmt->close();
}

// Get puja for edit
$edit_puja = null;
if (isset($_GET['edit'])) {
    $id = intval($_GET['edit']);
    $result = $conn->query("SELECT * FROM pujas WHERE id = $id");
    if ($result->num_rows > 0) {
        $edit_puja = $result->fetch_assoc();
    }
}

// Get all pujas
$pujas = $conn->query("SELECT * FROM pujas ORDER BY id DESC");
?>

<h2>Manage Pujas</h2>

<?php if ($message): ?>
    <div class="success-message"><?php echo $message; ?></div>
<?php endif; ?>

<button onclick="document.getElementById('pujaForm').style.display='block'" class="btn btn-primary"
    style="margin-bottom: 20px;">
    <?php echo $edit_puja ? 'Update' : 'Add New'; ?> Puja
</button>

<div id="pujaForm" class="form-container"
    style="display: <?php echo $edit_puja ? 'block' : 'none'; ?>; max-width: 800px; margin-bottom: 30px;">
    <h3><?php echo $edit_puja ? 'Edit' : 'Add New'; ?> Puja</h3>
    <form method="POST" enctype="multipart/form-data">
        <input type="hidden" name="puja_id" value="<?php echo $edit_puja ? $edit_puja['id'] : 0; ?>">

        <div class="form-group">
            <label>Name *</label>
            <input type="text" name="name" value="<?php echo $edit_puja ? htmlspecialchars($edit_puja['name']) : ''; ?>"
                required>
        </div>

        <div class="form-group">
            <label>Category *</label>
            <select name="category" required>
                <option value="">Select Category</option>
                <option value="wealth" <?php echo ($edit_puja && $edit_puja['category'] == 'wealth') ? 'selected' : ''; ?>>Wealth</option>
                <option value="health" <?php echo ($edit_puja && $edit_puja['category'] == 'health') ? 'selected' : ''; ?>>Health</option>
                <option value="marriage" <?php echo ($edit_puja && $edit_puja['category'] == 'marriage') ? 'selected' : ''; ?>>Marriage</option>
                <option value="dosha" <?php echo ($edit_puja && $edit_puja['category'] == 'dosha') ? 'selected' : ''; ?>>Dosha</option>
            </select>
        </div>

        <div class="form-group">
            <label>Puja Image</label>
            <?php if ($edit_puja && $edit_puja['image']): ?>
                <div style="margin-bottom: 10px;">
                    <img src="<?php echo SITE_URL; ?>/assets/images/pujas/<?php echo $edit_puja['image']; ?>" alt="Current Image" style="max-width: 200px; border-radius: 8px;">
                    <p style="font-size: 12px; color: #666;">Current Image: <?php echo $edit_puja['image']; ?></p>
                </div>
            <?php endif; ?>
            <input type="file" name="image" accept="image/jpeg,image/jpg,image/png,image/webp">
            <small style="color: #666; font-size: 12px;">Upload a new image (JPG, PNG, or WEBP). <?php echo $edit_puja ? 'Leave blank to keep current image.' : ''; ?></small>
        </div>

        <div class="form-group">
            <label>Description *</label>
            <textarea name="description"
                required><?php echo $edit_puja ? htmlspecialchars($edit_puja['description']) : ''; ?></textarea>
        </div>

        <div class="form-group">
            <label>Significance</label>
            <textarea
                name="significance"><?php echo $edit_puja ? htmlspecialchars($edit_puja['significance']) : ''; ?></textarea>
        </div>

        <div class="form-group">
            <label>When to Perform</label>
            <textarea
                name="when_to_perform"><?php echo $edit_puja ? htmlspecialchars($edit_puja['when_to_perform']) : ''; ?></textarea>
        </div>

        <div class="form-group">
            <label>Advantages</label>
            <textarea
                name="advantages"><?php echo $edit_puja ? htmlspecialchars($edit_puja['advantages']) : ''; ?></textarea>
        </div>

        <div class="form-group">
            <label>Price *</label>
            <input type="number" name="price" step="0.01" value="<?php echo $edit_puja ? $edit_puja['price'] : ''; ?>"
                required>
        </div>

        <button type="submit" class="btn btn-primary"><?php echo $edit_puja ? 'Update' : 'Add'; ?> Puja</button>
        <a href="<?php echo SITE_URL; ?>/admin/pujas.php" class="btn">Cancel</a>
    </form>
</div>

<div class="admin-table">
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Price</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($pujas && $pujas->num_rows > 0): ?>
                <?php while ($puja = $pujas->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $puja['id']; ?></td>
                        <td><?php echo htmlspecialchars($puja['name']); ?></td>
                        <td>₹<?php echo number_format($puja['price'], 2); ?></td>
                        <td><?php echo ucfirst($puja['status']); ?></td>
                        <td>
                            <a href="<?php echo SITE_URL; ?>/admin/pujas.php?edit=<?php echo $puja['id']; ?>"
                                style="text-decoration: none; color: var(--primary-color); margin-right: 10px;">
                                <i class="fas fa-edit"></i> Edit
                            </a>
                            <a href="<?php echo SITE_URL; ?>/admin/pujas.php?delete=<?php echo $puja['id']; ?>"
                                onclick="return confirm('Are you sure?')" style="text-decoration: none; color: #dc2626;">
                                <i class="fas fa-trash"></i> Delete
                            </a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="5" style="text-align: center;">No pujas found</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php
$conn->close();
include 'includes/footer.php';
?>