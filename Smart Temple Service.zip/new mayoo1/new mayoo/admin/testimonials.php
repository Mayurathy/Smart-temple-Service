<?php
require_once '../config/config.php';
requireAdminRole(['superadmin', 'content']);
$page_title = 'Testimonials';
include 'includes/header.php';
?>

<h2>Customer Testimonials</h2>

<div style="text-align: right; margin-bottom: 20px;">
    <a href="#" class="btn-admin btn-primary">
        <i class="fas fa-plus"></i> Add Testimonial
    </a>
</div>

<div class="admin-table-container">
    <div class="admin-table">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Review</th>
                    <th>Rating</th>
                    <th>Date</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td colspan="7" style="text-align: center; padding: 40px;">
                        <i class="fas fa-quote-right" style="font-size: 48px; color: #ddd; margin-bottom: 15px;"></i>
                        <p>No testimonials yet. Click "Add Testimonial" to add customer reviews.</p>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<?php include 'includes/footer.php'; ?>