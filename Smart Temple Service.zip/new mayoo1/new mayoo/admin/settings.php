<?php
require_once '../config/config.php';
$page_title = 'Site Settings';
include 'includes/header.php';

$conn = getDBConnection();

// Simple key-value settings store
$conn->query("CREATE TABLE IF NOT EXISTS settings (
    `key` VARCHAR(100) PRIMARY KEY,
    `value` TEXT NOT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$message = '';

// Save settings
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($_POST as $k => $v) {
        $key = sanitize($k);
        $val = trim($v);
        if ($key === 'save') continue;
        $stmt = $conn->prepare("INSERT INTO settings (`key`,`value`) VALUES (?, ?) ON DUPLICATE KEY UPDATE `value` = VALUES(`value`)");
        $stmt->bind_param('ss', $key, $val);
        $stmt->execute();
        $stmt->close();
    }
    $message = 'Settings saved.';
}

// Fetch all settings
$settings = [];
$res = $conn->query("SELECT `key`,`value` FROM settings");
if ($res) {
    while ($row = $res->fetch_assoc()) { $settings[$row['key']] = $row['value']; }
}

function sget($k, $d = '') { global $settings; return isset($settings[$k]) ? htmlspecialchars($settings[$k]) : $d; }
?>

<h2>Site Settings</h2>
<?php if ($message): ?><div class="success-message"><?php echo $message; ?></div><?php endif; ?>

<div class="form-container" style="max-width: 900px;">
    <form method="POST" action="">
        <div class="form-group">
            <label>Site Name</label>
            <input type="text" name="site_name" value="<?php echo sget('site_name', SITE_NAME); ?>">
        </div>

        <h3 style="margin: 20px 0 10px; color: var(--primary-color);">Homepage Images</h3>
        <div class="form-group">
            <label>Karthika Masam Image URL</label>
            <input type="text" name="karthika_image_url" value="<?php echo sget('karthika_image_url'); ?>" placeholder="https://...">
        </div>
        <div class="form-group">
            <label>Vedic Ashirvaad Image URL</label>
            <input type="text" name="vedic_image_url" value="<?php echo sget('vedic_image_url'); ?>" placeholder="https://...">
        </div>
        <div class="form-group">
            <label>Contact Section Image URL</label>
            <input type="text" name="contact_image_url" value="<?php echo sget('contact_image_url'); ?>" placeholder="https://...">
        </div>

        <button type="submit" name="save" class="btn btn-primary">Save Settings</button>
    </form>
</div>

<p style="margin-top:20px; color:#666;">Note: Advanced integration (auto‑apply images on homepage) can be wired up on request. Settings are stored and available to templates via the <code>settings</code> table.</p>

<?php
$conn->close();
include 'includes/footer.php';
?>


