<?php
require_once '../config/config.php';
$page_title = 'Admin Dashboard';
include 'includes/header.php';

// Include enhanced dashboard styles
echo '<link rel="stylesheet" href="' . SITE_URL . '/assets/css/admin-dashboard-enhanced.css">';

$conn = getDBConnection();

// Get statistics
$stats = [];

// Total bookings
$result = $conn->query("SELECT COUNT(*) as count FROM bookings");
$stats['bookings'] = $result->fetch_assoc()['count'];

// Pending bookings
$result = $conn->query("SELECT COUNT(*) as count FROM bookings WHERE status = 'pending'");
$stats['pending_bookings'] = $result->fetch_assoc()['count'];

// Superadmin specific stats
if (adminHasRole(['superadmin'])) {
    // System health metrics
    $today = date('Y-m-d');
    $this_month = date('Y-m');

    // Today's activity
    $stats['today_bookings'] = $conn->query("SELECT COUNT(*) as count FROM bookings WHERE DATE(created_at) = '$today'")->fetch_assoc()['count'] ?? 0;
    $stats['today_revenue'] = $conn->query("SELECT COALESCE(SUM(amount), 0) as total FROM donations WHERE DATE(created_at) = '$today'")->fetch_assoc()['total'] ?? 0;
    $stats['month_revenue'] = $conn->query("SELECT COALESCE(SUM(amount), 0) as total FROM donations WHERE DATE_FORMAT(created_at, '%Y-%m') = '$this_month'")->fetch_assoc()['total'] ?? 0;

    // User stats
    $stats['total_users'] = $conn->query("SELECT COUNT(*) as count FROM users")->fetch_assoc()['count'] ?? 0;
    $stats['total_admins'] = $conn->query("SELECT COUNT(*) as count FROM admins")->fetch_assoc()['count'] ?? 0;
    $stats['total_subscribers'] = $conn->query("SELECT COUNT(*) as count FROM subscribers")->fetch_assoc()['count'] ?? 0;

    // Recent user signups
    $week_ago = date('Y-m-d', strtotime('-7 days'));
    $stats['new_users_week'] = $conn->query("SELECT COUNT(*) as count FROM users WHERE created_at >= '$week_ago'")->fetch_assoc()['count'] ?? 0;
}

// Total pujas
if (adminHasRole(['superadmin', 'content'])) {
    $result = $conn->query("SELECT COUNT(*) as count FROM pujas WHERE status = 'active'");
    $stats['pujas'] = $result->fetch_assoc()['count'];

    // Total temples
    $result = $conn->query("SELECT COUNT(*) as count FROM temples WHERE status = 'active'");
    $stats['temples'] = $result->fetch_assoc()['count'];

    // Total priests
    $result = $conn->query("SELECT COUNT(*) as count FROM priests WHERE status = 'active'");
    $stats['priests'] = $result->fetch_assoc()['count'];
}

// New contacts
if (adminHasRole(['superadmin', 'operations'])) {
    $result = $conn->query("SELECT COUNT(*) as count FROM contacts WHERE status = 'new'");
    $stats['new_contacts'] = $result->fetch_assoc()['count'];
}

// Recent bookings
$recent_bookings_query = "SELECT b.*, p.name as puja_name FROM bookings b 
                          LEFT JOIN pujas p ON b.puja_id = p.id 
                          ORDER BY b.created_at DESC LIMIT 10";
$recent_bookings = $conn->query($recent_bookings_query);
?>

<?php if (adminHasRole(['superadmin'])): ?>
    <!-- Superadmin Control Panel -->
    <div class="superadmin-panel">
        <div class="sa-header">
            <div class="sa-icon">
                <i class="fas fa-shield-halved"></i>
            </div>
            <div class="sa-title">
                <h2>Superadmin Control Center</h2>
                <p>Complete system overview & management</p>
            </div>
            <div class="sa-status">
                <span class="status-dot active"></span>
                <span>System Active</span>
            </div>
        </div>

        <!-- Super Stats Row -->
        <div class="super-stats-grid">
            <div class="super-stat gold">
                <div class="ss-icon">
                    <i class="fas fa-chart-line"></i>
                </div>
                <div class="ss-content">
                    <h4>Today's Revenue</h4>
                    <div class="ss-value">₹<?php echo number_format($stats['today_revenue'], 0); ?></div>
                    <p class="ss-subtitle">₹<?php echo number_format($stats['month_revenue'], 0); ?> this month</p>
                </div>
            </div>

            <div class="super-stat blue">
                <div class="ss-icon">
                    <i class="fas fa-users"></i>
                </div>
                <div class="ss-content">
                    <h4>Total Users</h4>
                    <div class="ss-value"><?php echo $stats['total_users']; ?></div>
                    <p class="ss-subtitle">+<?php echo $stats['new_users_week']; ?> this week</p>
                </div>
            </div>

            <div class="super-stat green">
                <div class="ss-icon">
                    <i class="fas fa-calendar-day"></i>
                </div>
                <div class="ss-content">
                    <h4>Today's Bookings</h4>
                    <div class="ss-value"><?php echo $stats['today_bookings']; ?></div>
                    <p class="ss-subtitle"><?php echo $stats['bookings']; ?> total bookings</p>
                </div>
            </div>

            <div class="super-stat purple">
                <div class="ss-icon">
                    <i class="fas fa-user-shield"></i>
                </div>
                <div class="ss-content">
                    <h4>Admin Team</h4>
                    <div class="ss-value"><?php echo $stats['total_admins']; ?></div>
                    <p class="ss-subtitle"><?php echo $stats['total_subscribers']; ?> subscribers</p>
                </div>
            </div>
        </div>

        <!-- Quick Admin Actions -->
        <div class="sa-quick-actions">
            <a href="users.php" class="sa-action-btn">
                <i class="fas fa-users-cog"></i>
                <span>Manage Users</span>
            </a>
            <a href="settings.php" class="sa-action-btn">
                <i class="fas fa-cog"></i>
                <span>System Settings</span>
            </a>
            <a href="analytics.php" class="sa-action-btn">
                <i class="fas fa-chart-pie"></i>
                <span>Analytics</span>
            </a>
            <a href="reports.php" class="sa-action-btn">
                <i class="fas fa-file-invoice"></i>
                <span>Reports</span>
            </a>
        </div>
    </div>

    <style>
        .superadmin-panel {
            background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
            border-radius: 24px;
            padding: 30px;
            margin-bottom: 35px;
            color: white;
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.3);
            position: relative;
            overflow: hidden;
        }

        .superadmin-panel::before {
            content: '';
            position: absolute;
            top: 0;
            right: 0;
            width: 400px;
            height: 400px;
            background: radial-gradient(circle, rgba(212, 175, 55, 0.1) 0%, transparent 70%);
            pointer-events: none;
        }

        .sa-header {
            display: flex;
            align-items: center;
            gap: 20px;
            margin-bottom: 30px;
            position: relative;
            z-index: 1;
        }

        .sa-icon {
            width: 70px;
            height: 70px;
            background: linear-gradient(135deg, #D4AF37, #F4E5BC);
            border-radius: 18px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 32px;
            color: #1a1a1a;
            box-shadow: 0 8px 20px rgba(212, 175, 55, 0.4);
        }

        .sa-title {
            flex: 1;
        }

        .sa-title h2 {
            margin: 0 0 5px 0;
            font-size: 28px;
            font-weight: 800;
            color: #D4AF37;
        }

        .sa-title p {
            margin: 0;
            opacity: 0.8;
            font-size use: 14px;
        }

        .sa-status {
            display: flex;
            align-items: center;
            gap: 8px;
            background: rgba(255, 255, 255, 0.1);
            padding: 10px 20px;
            border-radius: 12px;
            font-weight: 600;
            font-size: 13px;
        }

        .status-dot {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background: #10b981;
            animation: statusPulse 2s ease-in-out infinite;
        }

        @keyframes statusPulse {

            0%,
            100% {
                opacity: 1;
            }

            50% {
                opacity: 0.5;
            }
        }

        /* Super Stats Grid */
        .super-stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 20px;
            margin-bottom: 25px;
            position: relative;
            z-index: 1;
        }

        .super-stat {
            background: rgba(255, 255, 255, 0.08);
            border-radius: 16px;
            padding: 20px;
            display: flex;
            gap: 15px;
            align-items: flex-start;
            border: 1px solid rgba(255, 255, 255, 0.1);
            transition: all 0.3s ease;
        }

        .super-stat:hover {
            background: rgba(255, 255, 255, 0.12);
            transform: translateY(-3px);
        }

        .ss-icon {
            width: 50px;
            height: 50px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 22px;
            flex-shrink: 0;
        }

        .super-stat.gold .ss-icon {
            background: linear-gradient(135deg, #F4E5BC, #D4AF37);
            color: #1a1a1a;
        }

        .super-stat.blue .ss-icon {
            background: linear-gradient(135deg, #bfdbfe, #3b82f6);
            color: #1e3a8a;
        }

        .super-stat.green .ss-icon {
            background: linear-gradient(135deg, #a7f3d0, #10b981);
            color: #064e3b;
        }

        .super-stat.purple .ss-icon {
            background: linear-gradient(135deg, #e9d5ff, #a855f7);
            color: #581c87;
        }

        .ss-content {
            flex: 1;
        }

        .ss-content h4 {
            margin: 0 0 8px 0;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            opacity: 0.8;
        }

        .ss-value {
            font-size: 28px;
            font-weight: 800;
            margin-bottom: 5px;
        }

        .ss-subtitle {
            margin: 0;
            font-size: 11px;
            opacity: 0.7;
        }

        /* Quick Admin Actions */
        .sa-quick-actions {
            display: flex;
            gap: 12px;
            position: relative;
            z-index: 1;
        }

        .sa-action-btn {
            flex: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 8px;
            padding: 15px;
            background: rgba(255, 255, 255, 0.08);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 12px;
            color: white;
            text-decoration: none;
            transition: all 0.3s ease;
            font-weight: 600;
            font-size: 13px;
        }

        .sa-action-btn:hover {
            background: rgba(212, 175, 55, 0.2);
            border-color: #D4AF37;
            transform: translateY(-2px);
        }

        .sa-action-btn i {
            font-size: 20px;
            color: #D4AF37;
        }

        @media (max-width: 768px) {
            .sa-header {
                flex-direction: column;
                text-align: center;
            }

            .super-stats-grid {
                grid-template-columns: 1fr;
            }

            .sa-quick-actions {
                flex-direction: column;
            }
        }
    </style>
<?php endif; ?>

<!-- Welcome Banner -->
<div class="welcome-banner animated fade-in-up">
    <div class="welcome-text">
        <h2>Good <?php echo (date('H') < 12) ? 'Morning' : ((date('H') < 17) ? 'Afternoon' : 'Evening'); ?>, Admin!</h2>
        <p>Here's what's happening with your temple services today.</p>
    </div>
    <div class="welcome-decoration">
        <i class="fas fa-om"></i>
    </div>
</div>

<div class="dashboard-grid">
    <div class="stat-card">
        <h3>Total Bookings</h3>
        <div class="stat-number"><?php echo $stats['bookings']; ?></div>
        <i class="fas fa-calendar-check stat-icon"></i>
    </div>

    <div class="stat-card">
        <h3>Pending Bookings</h3>
        <div class="stat-number"><?php echo $stats['pending_bookings']; ?></div>
        <i class="fas fa-clock stat-icon"></i>
    </div>

    <?php if (adminHasRole(['superadmin', 'content'])): ?>
        <div class="stat-card">
            <h3>Active Pujas</h3>
            <div class="stat-number"><?php echo $stats['pujas']; ?></div>
            <i class="fas fa-pray stat-icon"></i>
        </div>

        <div class="stat-card">
            <h3>Active Temples</h3>
            <div class="stat-number"><?php echo $stats['temples']; ?></div>
            <i class="fas fa-gopuram stat-icon"></i>
        </div>

        <div class="stat-card">
            <h3>Active Priests</h3>
            <div class="stat-number"><?php echo $stats['priests']; ?></div>
            <i class="fas fa-user-tie stat-icon"></i>
        </div>
    <?php endif; ?>

    <?php if (adminHasRole(['superadmin', 'operations'])): ?>
        <div class="stat-card">
            <h3>New Contacts</h3>
            <div class="stat-number"><?php echo $stats['new_contacts']; ?></div>
            <i class="fas fa-envelope stat-icon"></i>
        </div>
    <?php endif; ?>
</div>

<!-- Analytics Section (Dual Charts) -->
<div class="analytics-grid animated fade-in-up delay-100">
    <!-- Bookings Chart -->
    <div class="chart-container">
        <div class="chart-header">
            <h3>Bookings Overview</h3>
            <select class="chart-filter">
                <option>Monthly</option>
                <option>Weekly</option>
            </select>
        </div>
        <canvas id="bookingsChart"></canvas>
    </div>

    <!-- Revenue Chart -->
    <div class="chart-container">
        <div class="chart-header">
            <h3>Revenue Trends</h3>
            <div class="chart-legend">
                <span class="legend-item"><span class="dot dot-gold"></span> Pujas</span>
                <span class="legend-item"><span class="dot dot-crimson"></span> Donations</span>
            </div>
        </div>
        <canvas id="revenueChart"></canvas>
    </div>
</div>

<div class="dashboard-columns">
    <!-- Left Column: Recent Bookings -->
    <div class="main-column">
        <?php if (adminHasRole(['superadmin', 'operations'])): ?>
            <div class="section-header-flex">
                <h3 style="color: var(--primary-dark); margin: 0;">Recent Bookings</h3>
                <a href="bookings.php" class="btn-admin btn-outline">View All</a>
            </div>
            <div class="admin-table-container animated fade-in-up delay-200">
                <div class="admin-table">
                    <table>
                        <thead>
                            <tr>
                                <th>Booking ID</th>
                                <th>Customer</th>
                                <th>Service</th>
                                <th>Date</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($recent_bookings && $recent_bookings->num_rows > 0): ?>
                                <?php while ($booking = $recent_bookings->fetch_assoc()): ?>
                                    <tr>
                                        <td>#<?php echo htmlspecialchars($booking['booking_id']); ?></td>
                                        <td>
                                            <div class="user-cell">
                                                <div class="user-avatar-small">
                                                    <?php echo strtoupper(substr($booking['user_name'], 0, 1)); ?>
                                                </div>
                                                <span><?php echo htmlspecialchars($booking['user_name']); ?></span>
                                            </div>
                                        </td>
                                        <td><?php echo $booking['puja_name'] ? htmlspecialchars($booking['puja_name']) : $booking['booking_type']; ?>
                                        </td>
                                        <td><?php echo date('M d, Y', strtotime($booking['booking_date'])); ?></td>
                                        <td>
                                            <span class="status-badge status-<?php echo $booking['status']; ?>">
                                                <?php echo ucfirst($booking['status']); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <a href="<?php echo SITE_URL; ?>/admin/view-booking.php?id=<?php echo $booking['id']; ?>"
                                                class="btn-icon" title="View Details">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="6" style="text-align: center; padding: 30px;">
                                        <i class="fas fa-inbox" style="font-size: 40px; color: #ccc; margin-bottom: 10px;"></i>
                                        <p>No bookings found</p>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <!-- Right Column: Widgets -->
    <div class="side-column">
        <!-- Quick Actions -->
        <div class="widget-card animated fade-in-up delay-300">
            <h3>Quick Actions</h3>
            <div class="quick-actions-grid">
                <a href="bookings.php" class="quick-action-btn">
                    <div class="icon-box bg-blue"><i class="fas fa-calendar-plus"></i></div>
                    <span>New Booking</span>
                </a>
                <a href="pujas.php" class="quick-action-btn">
                    <div class="icon-box bg-red"><i class="fas fa-pray"></i></div>
                    <span>Add Puja</span>
                </a>
                <a href="users.php" class="quick-action-btn">
                    <div class="icon-box bg-green"><i class="fas fa-user-plus"></i></div>
                    <span>Add User</span>
                </a>
                <a href="contacts.php" class="quick-action-btn">
                    <div class="icon-box bg-gold"><i class="fas fa-envelope"></i></div>
                    <span>Messages</span>
                </a>
            </div>
        </div>

        <!-- Activity Feed -->
        <div class="widget-card animated fade-in-up delay-400">
            <h3>Recent Activity</h3>
            <div class="activity-feed">
                <?php
                // Fetch recent activities (Bookings, Users, Contacts)
                $activities = [];

                // Recent Bookings
                $res_bookings = $conn->query("SELECT 'booking' as type, created_at, user_name as name, id FROM bookings ORDER BY created_at DESC LIMIT 3");
                while ($row = $res_bookings->fetch_assoc())
                    $activities[] = $row;

                // Recent Users (if superadmin)
                if (adminHasRole(['superadmin'])) {
                    $res_users = $conn->query("SELECT 'user' as type, created_at, name, id FROM users ORDER BY created_at DESC LIMIT 3");
                    while ($row = $res_users->fetch_assoc())
                        $activities[] = $row;
                }

                // Recent Contacts (if superadmin/operations)
                if (adminHasRole(['superadmin', 'operations'])) {
                    $res_contacts = $conn->query("SELECT 'contact' as type, created_at, name, id FROM contacts ORDER BY created_at DESC LIMIT 3");
                    while ($row = $res_contacts->fetch_assoc())
                        $activities[] = $row;
                }

                // Sort by date desc
                usort($activities, function ($a, $b) {
                    return strtotime($b['created_at']) - strtotime($a['created_at']);
                });

                // Slice to top 5
                $activities = array_slice($activities, 0, 5);

                foreach ($activities as $activity):
                    $icon = '';
                    $bg_class = '';
                    $text = '';

                    switch ($activity['type']) {
                        case 'booking':
                            $icon = 'fa-calendar-check';
                            $bg_class = 'bg-blue';
                            $text = "<strong>New Booking</strong> from <span class='highlight'>" . htmlspecialchars($activity['name']) . "</span>";
                            break;
                        case 'user':
                            $icon = 'fa-user-plus';
                            $bg_class = 'bg-green';
                            $text = "<strong>New User</strong> registered: <span class='highlight'>" . htmlspecialchars($activity['name']) . "</span>";
                            break;
                        case 'contact':
                            $icon = 'fa-envelope';
                            $bg_class = 'bg-gold';
                            $text = "<strong>New Message</strong> from <span class='highlight'>" . htmlspecialchars($activity['name']) . "</span>";
                            break;
                    }

                    // Calculate time ago
                    $time_ago = '';
                    $diff = time() - strtotime($activity['created_at']);
                    if ($diff < 60)
                        $time_ago = 'Just now';
                    elseif ($diff < 3600)
                        $time_ago = floor($diff / 60) . ' mins ago';
                    elseif ($diff < 86400)
                        $time_ago = floor($diff / 3600) . ' hours ago';
                    else
                        $time_ago = floor($diff / 86400) . ' days ago';
                    ?>
                    <div class="activity-item">
                        <div class="activity-icon <?php echo $bg_class; ?>"><i class="fas <?php echo $icon; ?>"></i></div>
                        <div class="activity-content">
                            <p><?php echo $text; ?></p>
                            <span class="activity-time"><?php echo $time_ago; ?></span>
                        </div>
                    </div>
                <?php endforeach; ?>

                <?php if (empty($activities)): ?>
                    <p class="text-muted" style="text-align:center; font-size:13px;">No recent activity.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        // Charts Initialization with Gradients
        document.addEventListener('DOMContentLoaded', function () {
            // Bookings Chart
            const ctxBookings = document.getElementById('bookingsChart').getContext('2d');

            // Create Gradient for Bookings
            const gradientBookings = ctxBookings.createLinearGradient(0, 0, 0, 400);
            gradientBookings.addColorStop(0, 'rgba(212, 175, 55, 0.4)'); // Gold
            gradientBookings.addColorStop(1, 'rgba(212, 175, 55, 0.0)');

            const bookingsChart = new Chart(ctxBookings, {
                type: 'line',
                data: {
                    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                    datasets: [{
                        label: 'Monthly Bookings',
                        data: [12, 19, 15, 25, 22, 30],
                        borderColor: '#D4AF37', // Gold
                        backgroundColor: gradientBookings,
                        borderWidth: 3,
                        tension: 0.4, // Smooth curves
                        pointBackgroundColor: '#fff',
                        pointBorderColor: '#D4AF37',
                        pointBorderWidth: 2,
                        pointRadius: 4,
                        pointHoverRadius: 6,
                        fill: true
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        },
                        tooltip: {
                            backgroundColor: 'rgba(255, 255, 255, 0.9)',
                            titleColor: '#1a1a1a',
                            bodyColor: '#4a4a4a',
                            borderColor: 'rgba(0,0,0,0.05)',
                            borderWidth: 1,
                            padding: 10,
                            displayColors: false,
                            callbacks: {
                                label: function (context) {
                                    return context.parsed.y + ' Bookings';
                                }
                            }
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: {
                                color: 'rgba(0, 0, 0, 0.03)',
                                drawBorder: false
                            },
                            ticks: {
                                font: {
                                    family: "'Outfit', sans-serif"
                                }
                            }
                        },
                        x: {
                            grid: {
                                display: false
                            },
                            ticks: {
                                font: {
                                    family: "'Outfit', sans-serif"
                                }
                            }
                        }
                    },
                    interaction: {
                        intersect: false,
                        mode: 'index',
                    },
                }
            });

            // Revenue Chart
            const ctxRevenue = document.getElementById('revenueChart').getContext('2d');

            // Gradients for Revenue
            const gradientPujas = ctxRevenue.createLinearGradient(0, 0, 0, 400);
            gradientPujas.addColorStop(0, '#D4AF37');
            gradientPujas.addColorStop(1, '#F4E5BC');

            const gradientDonations = ctxRevenue.createLinearGradient(0, 0, 0, 400);
            gradientDonations.addColorStop(0, '#8B0000');
            gradientDonations.addColorStop(1, '#4a0404');

            const revenueChart = new Chart(ctxRevenue, {
                type: 'bar',
                data: {
                    labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
                    datasets: [{
                        label: 'Pujas',
                        data: [1500, 2300, 1800, 3200, 2900, 4500, 5100],
                        backgroundColor: gradientPujas,
                        borderRadius: 4,
                        barPercentage: 0.6,
                        categoryPercentage: 0.8
                    }, {
                        label: 'Donations',
                        data: [500, 800, 600, 1200, 900, 1500, 2000],
                        backgroundColor: gradientDonations,
                        borderRadius: 4,
                        barPercentage: 0.6,
                        categoryPercentage: 0.8
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        },
                        tooltip: {
                            backgroundColor: 'rgba(255, 255, 255, 0.9)',
                            titleColor: '#1a1a1a',
                            bodyColor: '#4a4a4a',
                            borderColor: 'rgba(0,0,0,0.05)',
                            borderWidth: 1,
                            padding: 10
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: {
                                color: 'rgba(0, 0, 0, 0.03)',
                                drawBorder: false
                            },
                            ticks: {
                                callback: function (value) {
                                    return '₹' + value;
                                },
                                font: {
                                    family: "'Outfit', sans-serif"
                                }
                            }
                        },
                        x: {
                            grid: {
                                display: false
                            },
                            ticks: {
                                font: {
                                    family: "'Outfit', sans-serif"
                                }
                            }
                        }
                    }
                }
            });
        });
</script>

<?php
$conn->close();
include 'includes/footer.php';
?>