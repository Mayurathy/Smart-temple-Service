<?php
require_once '../config/config.php';
requireAdminRole(['superadmin', 'content']);
$page_title = 'Blog Management';
include 'includes/header.php';
?>

<h2>Blog Posts</h2>

<div style="text-align: right; margin-bottom: 20px;">
    <a href="#" class="btn-admin btn-primary">
        <i class="fas fa-plus"></i> Create New Post
    </a>
</div>

<div class="admin-table-container">
    <div class="admin-table">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Title</th>
                    <th>Author</th>
                    <th>Category</th>
                    <th>Published Date</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td colspan="7" style="text-align: center; padding: 40px;">
                        <i class="fas fa-blog" style="font-size: 48px; color: #ddd; margin-bottom: 15px;"></i>
                        <p>No blog posts yet. Click "Create New Post" to write your first article.</p>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<?php include 'includes/footer.php'; ?>