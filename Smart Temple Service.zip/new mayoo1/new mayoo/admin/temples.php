<?php
require_once '../config/config.php';
requireAdminRole(['superadmin', 'content']);
$page_title = 'Manage Temples';
include 'includes/header.php';

$conn = getDBConnection();
$message = '';
$message_type = '';

// Handle delete
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    if ($conn->query("UPDATE temples SET status = 'inactive' WHERE id = $id")) {
        $message = 'Temple deleted successfully';
        $message_type = 'success';
    } else {
        $message = 'Error deleting temple';
        $message_type = 'error';
    }
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = sanitize($_POST['name']);
    $location = sanitize($_POST['location']);
    $city = sanitize($_POST['city']);
    $state = sanitize($_POST['state']);
    $description = sanitize($_POST['description']);
    $status = sanitize($_POST['status']);

    // Handle image upload
    $image_name = '';
    $upload_dir = '../assets/images/temples/';

    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }

    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $upload_result = uploadImage($_FILES['image'], $upload_dir);
        if ($upload_result['success']) {
            $image_name = $upload_result['filename'];
        } else {
            $message = $upload_result['error'];
            $message_type = 'error';
        }
    }

    if (isset($_POST['temple_id']) && $_POST['temple_id'] > 0) {
        // Update
        $id = intval($_POST['temple_id']);

        if ($image_name) {
            $query = "UPDATE temples SET name = ?, location = ?, city = ?, state = ?, description = ?, image = ?, status = ? WHERE id = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("sssssssi", $name, $location, $city, $state, $description, $image_name, $status, $id);
        } else {
            $query = "UPDATE temples SET name = ?, location = ?, city = ?, state = ?, description = ?, status = ? WHERE id = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("ssssssi", $name, $location, $city, $state, $description, $status, $id);
        }

        if ($stmt->execute()) {
            $message = 'Temple updated successfully';
            $message_type = 'success';
        } else {
            $message = 'Error updating temple';
            $message_type = 'error';
        }
        $stmt->close();
    } else {
        // Insert
        $query = "INSERT INTO temples (name, location, city, state, description, image, status) VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("sssssss", $name, $location, $city, $state, $description, $image_name, $status);

        if ($stmt->execute()) {
            $message = 'Temple added successfully';
            $message_type = 'success';
        } else {
            $message = 'Error adding temple';
            $message_type = 'error';
        }
        $stmt->close();
    }
}

// Get temple for edit
$edit_temple = null;
if (isset($_GET['edit'])) {
    $id = intval($_GET['edit']);
    $result = $conn->query("SELECT * FROM temples WHERE id = $id");
    if ($result && $result->num_rows > 0) {
        $edit_temple = $result->fetch_assoc();
    }
}

// Get all temples
$temples = $conn->query("SELECT * FROM temples ORDER BY id DESC");
?>

<h2>Manage Temples</h2>

<?php if ($message): ?>
    <div class="alert <?php echo $message_type === 'success' ? 'alert-success' : 'alert-error'; ?>"
        style="margin-bottom: 20px;">
        <?php echo $message; ?>
    </div>
<?php endif; ?>

<button onclick="document.getElementById('templeForm').style.display='block'" class="btn-admin btn-primary"
    style="margin-bottom: 20px;">
    <i class="fas fa-plus"></i> <?php echo $edit_temple ? 'Update' : 'Add New'; ?> Temple
</button>

<!-- Temple Form -->
<div id="templeForm" class="form-container"
    style="display: <?php echo $edit_temple ? 'block' : 'none'; ?>; max-width: 900px; margin-bottom: 30px;">
    <h3><?php echo $edit_temple ? 'Edit' : 'Add New'; ?> Temple</h3>
    <form method="POST" action="" enctype="multipart/form-data">
        <input type="hidden" name="temple_id" value="<?php echo $edit_temple ? $edit_temple['id'] : 0; ?>">

        <div class="form-row" style="display: grid; grid-template-columns: 2fr 1fr; gap: 15px;">
            <div class="form-group">
                <label>Temple Name *</label>
                <input type="text" name="name"
                    value="<?php echo $edit_temple ? htmlspecialchars($edit_temple['name']) : ''; ?>" required
                    placeholder="e.g., Sri Venkateswara Temple">
            </div>

            <div class="form-group">
                <label>Status *</label>
                <select name="status" required>
                    <option value="active" <?php echo (!$edit_temple || $edit_temple['status'] == 'active') ? 'selected' : ''; ?>>Active</option>
                    <option value="inactive" <?php echo ($edit_temple && $edit_temple['status'] == 'inactive') ? 'selected' : ''; ?>>Inactive</option>
                </select>
            </div>
        </div>

        <div class="form-row" style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 15px;">
            <div class="form-group">
                <label>Location/Area *</label>
                <input type="text" name="location"
                    value="<?php echo $edit_temple ? htmlspecialchars($edit_temple['location']) : ''; ?>" required
                    placeholder="e.g., Tirumala Hills">
            </div>

            <div class="form-group">
                <label>City *</label>
                <input type="text" name="city"
                    value="<?php echo $edit_temple ? htmlspecialchars($edit_temple['city']) : ''; ?>" required
                    placeholder="e.g., Tirupati">
            </div>

            <div class="form-group">
                <label>State *</label>
                <input type="text" name="state"
                    value="<?php echo $edit_temple ? htmlspecialchars($edit_temple['state']) : ''; ?>" required
                    placeholder="e.g., Andhra Pradesh">
            </div>
        </div>

        <div class="form-group">
            <label>Description</label>
            <textarea name="description" rows="4"
                placeholder="Enter temple description, history, and significance..."><?php echo $edit_temple ? htmlspecialchars($edit_temple['description']) : ''; ?></textarea>
        </div>

        <div class="form-group">
            <label>Temple Image</label>
            <?php if ($edit_temple && $edit_temple['image']): ?>
                <div style="margin-bottom: 10px;">
                    <img src="<?php echo SITE_URL; ?>/assets/images/temples/<?php echo $edit_temple['image']; ?>"
                        alt="Current Image" style="max-width: 200px; border-radius: 8px; border: 2px solid #e5e7eb;">
                    <p style="font-size: 12px; color: #666; margin-top: 5px;">Current: <?php echo $edit_temple['image']; ?>
                    </p>
                </div>
            <?php endif; ?>
            <input type="file" name="image" accept="image/jpeg,image/jpg,image/png,image/webp">
            <small style="color: #666; font-size: 12px; display: block; margin-top: 5px;">
                Upload temple image (JPG, PNG, or WEBP). Max 5MB.
                <?php echo $edit_temple ? 'Leave blank to keep current image.' : ''; ?>
            </small>
        </div>

        <div style="display: flex; gap: 10px; margin-top: 20px;">
            <button type="submit" class="btn-admin btn-primary">
                <i class="fas fa-save"></i> <?php echo $edit_temple ? 'Update' : 'Add'; ?> Temple
            </button>
            <a href="<?php echo SITE_URL; ?>/admin/temples.php" class="btn-admin" style="text-decoration: none;">
                <i class="fas fa-times"></i> Cancel
            </a>
        </div>
    </form>
</div>

<!-- Temples Table -->
<div class="admin-table-container">
    <div class="admin-table">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Image</th>
                    <th>Temple Name</th>
                    <th>Location</th>
                    <th>City / State</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($temples && $temples->num_rows > 0): ?>
                    <?php while ($temple = $temples->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $temple['id']; ?></td>
                            <td>
                                <?php if ($temple['image']): ?>
                                    <img src="<?php echo SITE_URL; ?>/assets/images/temples/<?php echo $temple['image']; ?>"
                                        alt="<?php echo htmlspecialchars($temple['name']); ?>"
                                        style="width: 50px; height: 50px; object-fit: cover; border-radius: 6px;">
                                <?php else: ?>
                                    <div
                                        style="width: 50px; height: 50px; background: #f3f4f6; border-radius: 6px; display: flex; align-items: center; justify-content: center;">
                                        <i class="fas fa-gopuram" style="color: #9ca3af;"></i>
                                    </div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <strong><?php echo htmlspecialchars($temple['name']); ?></strong>
                                <?php if ($temple['description']): ?>
                                    <br><small style="color: #666;"><?php echo truncate($temple['description'], 50); ?></small>
                                <?php endif; ?>
                            </td>
                            <td><?php echo htmlspecialchars($temple['location']); ?></td>
                            <td><?php echo htmlspecialchars($temple['city']) . ', ' . htmlspecialchars($temple['state']); ?>
                            </td>
                            <td><?php echo getStatusBadge($temple['status']); ?></td>
                            <td>
                                <a href="<?php echo SITE_URL; ?>/admin/temples.php?edit=<?php echo $temple['id']; ?>"
                                    class="btn-icon" title="Edit">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <a href="<?php echo SITE_URL; ?>/admin/temples.php?delete=<?php echo $temple['id']; ?>"
                                    onclick="return confirm('Are you sure you want to delete this temple?')" class="btn-icon"
                                    title="Delete" style="color: #ef4444;">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" style="text-align: center; padding: 40px;">
                            <i class="fas fa-gopuram" style="font-size: 48px; color: #ddd; margin-bottom: 15px;"></i>
                            <p style="color: #666;">No temples found. Click "Add New Temple" to get started.</p>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<style>
    .form-container {
        background: white;
        padding: 25px;
        border-radius: 12px;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        animation: fadeIn 0.3s ease;
    }

    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translateY(-10px);
        }

        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .form-group {
        margin-bottom: 20px;
    }

    .form-group label {
        display: block;
        margin-bottom: 8px;
        font-weight: 600;
        color: #374151;
    }

    .form-group input,
    .form-group textarea,
    .form-group select {
        width: 100%;
        padding: 12px;
        border: 1px solid #e5e7eb;
        border-radius: 8px;
        font-size: 14px;
        transition: all 0.3s ease;
    }

    .form-group input:focus,
    .form-group textarea:focus,
    .form-group select:focus {
        outline: none;
        border-color: var(--primary-gold);
        box-shadow: 0 0 0 3px rgba(212, 175, 55, 0.1);
    }

    .btn-icon {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 32px;
        height: 32px;
        border-radius: 6px;
        transition: all 0.2s ease;
        color: var(--primary-gold);
        text-decoration: none;
        margin: 0 4px;
    }

    .btn-icon:hover {
        background: rgba(212, 175, 55, 0.1);
        transform: scale(1.1);
    }

    .alert {
        padding: 12px 20px;
        border-radius: 8px;
        font-weight: 500;
    }

    .alert-success {
        background: #d1fae5;
        color: #065f46;
        border: 1px solid #6ee7b7;
    }

    .alert-error {
        background: #fee2e2;
        color: #991b1b;
        border: 1px solid #fca5a5;
    }
</style>

<?php
$conn->close();
include 'includes/footer.php';
?>