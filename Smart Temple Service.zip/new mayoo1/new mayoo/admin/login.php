<?php
require_once '../config/config.php';

// Redirect if already logged in
if (isLoggedIn()) {
    redirect('/admin/index.php');
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = sanitize($_POST['username']);
    $password = $_POST['password'];

    $conn = getDBConnection();
    // Ensure role column exists and seed default admins
    $colRes = $conn->query("SHOW COLUMNS FROM admins LIKE 'role'");
    if ($colRes && $colRes->num_rows === 0) {
        $conn->query("ALTER TABLE admins ADD COLUMN role ENUM('superadmin','content','operations','manager') DEFAULT 'superadmin'");
    }
    // Seed default admins if missing
    $defaultHash = '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi'; // password
    $conn->query("INSERT IGNORE INTO admins (username, email, password, role) VALUES
        ('admin','admin@pujaservices.com','$defaultHash','superadmin'),
        ('content','content@pujaservices.com','$defaultHash','content'),
        ('ops','ops@pujaservices.com','$defaultHash','operations'),
        ('manager','manager@pujaservices.com','$defaultHash','manager')");

    $query = "SELECT * FROM admins WHERE username = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $admin = $result->fetch_assoc();
        if (password_verify($password, $admin['password'])) {
            $_SESSION['admin_id'] = $admin['id'];
            $_SESSION['admin_username'] = $admin['username'];
            $_SESSION['admin_role'] = isset($admin['role']) ? $admin['role'] : 'superadmin';
            redirect('/admin/index.php');
        } else {
            $error = 'Invalid username or password';
        }
    } else {
        $error = 'Invalid username or password';
    }
    $stmt->close();
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - Puja Services</title>
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>/assets/css/admin-login.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>

<body>
    <!-- Animated Particles Background -->
    <div class="particles">
        <div class="particle" style="left: 10%; animation-delay: 0s;"></div>
        <div class="particle" style="left: 20%; animation-delay: 2s;"></div>
        <div class="particle" style="left: 30%; animation-delay: 4s;"></div>
        <div class="particle" style="left: 40%; animation-delay: 1s;"></div>
        <div class="particle" style="left: 50%; animation-delay: 3s;"></div>
        <div class="particle" style="left: 60%; animation-delay: 5s;"></div>
        <div class="particle" style="left: 70%; animation-delay: 2.5s;"></div>
        <div class="particle" style="left: 80%; animation-delay: 4.5s;"></div>
        <div class="particle" style="left: 90%; animation-delay: 1.5s;"></div>
    </div>

    <div class="login-wrapper">
        <div class="login-container">
            <!-- Header -->
            <div class="login-header">
                <div class="login-icon">
                    <i class="fas fa-shield-halved"></i>
                </div>
                <h1>Admin Portal</h1>
                <p>Secure access to temple management system</p>
            </div>

            <!-- Error Message -->
            <?php if ($error): ?>
                <div class="alert alert-error">
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <!-- Login Form -->
            <form method="POST" action="" class="login-form">
                <div class="form-group">
                    <label>Username</label>
                    <div class="input-wrapper">
                        <input type="text" name="username" required autofocus placeholder="Enter your username">
                        <i class="fas fa-user input-icon"></i>
                    </div>
                </div>

                <div class="form-group">
                    <label>Password</label>
                    <div class="input-wrapper">
                        <input type="password" name="password" required placeholder="Enter your password">
                        <i class="fas fa-lock input-icon"></i>
                    </div>
                </div>

                <button type="submit" class="btn-login">
                    <span>Sign In to Dashboard</span>
                    <i class="fas fa-arrow-right" style="margin-left: 10px;"></i>
                </button>
            </form>

            <!-- Footer -->
            <div class="login-footer">
                <div class="default-credentials">
                    <p><i class="fas fa-info-circle" style="margin-right: 5px;"></i> Default: <code>admin</code> /
                        <code>admin123</code></p>
                </div>
                <a href="<?php echo SITE_URL; ?>/index.php" class="back-to-site">
                    <i class="fas fa-arrow-left"></i>
                    <span>Back to Website</span>
                </a>
            </div>
        </div>
    </div>
</body>

</html>