<?php
require_once '../config/config.php';
requireAdminRole(['superadmin', 'content']);
$page_title = 'Darshan Timings';
include 'includes/header.php';
?>

<h2>Darshan Timings</h2>

<div style="text-align: right; margin-bottom: 20px;">
    <a href="#" class="btn-admin btn-primary">
        <i class="fas fa-plus"></i> Add New Timing
    </a>
</div>

<div class="admin-table-container">
    <div class="admin-table">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Deity/Temple</th>
                    <th>Morning Darshan</th>
                    <th>Evening Darshan</th>
                    <th>Special Timings</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td colspan="6" style="text-align: center; padding: 40px;">
                        <i class="fas fa-clock" style="font-size: 48px; color: #ddd; margin-bottom: 15px;"></i>
                        <p>No darshan timings configured. Click "Add New Timing" to set schedule.</p>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<?php include 'includes/footer.php'; ?>