<?php
require_once 'config/config.php';

$message = '';
$message_type = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = sanitize($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($email && $password) {
        $conn = getDBConnection();
        // Ensure table exists (in case SQL not imported)
        $conn->query("CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            email VARCHAR(255) NOT NULL UNIQUE,
            phone VARCHAR(25) NOT NULL,
            password VARCHAR(255) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        // 1) Try front-end user by email
        $stmt = $conn->prepare("SELECT id, name, password FROM users WHERE email = ? LIMIT 1");
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $res = $stmt->get_result();
        if ($res && $res->num_rows === 1) {
            $row = $res->fetch_assoc();
            if (password_verify($password, $row['password'])) {
                $_SESSION['user_id'] = $row['id'];
                $_SESSION['user_name'] = $row['name'];
                $stmt->close();
                $conn->close();
                redirect('/index.php');
            }
        }
        $stmt->close();

        // 2) If not a user, try admin (allow username OR email typed into email field)
        // Ensure admins.role exists
        $colRes = $conn->query("SHOW COLUMNS FROM admins LIKE 'role'");
        if ($colRes && $colRes->num_rows === 0) {
            $conn->query("ALTER TABLE admins ADD COLUMN role ENUM('superadmin','content','operations') DEFAULT 'superadmin'");
        }

        $query = "SELECT id, username, password, role FROM admins WHERE username = ? OR email = ? LIMIT 1";
        $a = $conn->prepare($query);
        $a->bind_param('ss', $email, $email);
        if ($a->execute()) {
            $ar = $a->get_result();
            if ($ar && $ar->num_rows === 1) {
                $admin = $ar->fetch_assoc();
                if (password_verify($password, $admin['password'])) {
                    $_SESSION['admin_id'] = $admin['id'];
                    $_SESSION['admin_username'] = $admin['username'];
                    $_SESSION['admin_role'] = isset($admin['role']) ? $admin['role'] : 'superadmin';
                    $a->close();
                    $conn->close();
                    redirect('/admin/index.php');
                }
            }
        }
        $a->close();
        $conn->close();

        // If neither matched
        $message = 'Invalid email/username or password.';
        $message_type = 'error';
    } else {
        $message = 'Please enter email and password.';
        $message_type = 'error';
    }
}

$page_title = 'Sign In - Puja Services';
include 'includes/header.php';
?>

<link rel="stylesheet" href="assets/css/auth-premium.css">

<!-- Hero Section -->
<section class="auth-hero">
    <div class="container">
        <h1>Welcome Back</h1>
        <p>Sign in to access your account and manage your bookings.</p>
    </div>
</section>

<section class="auth-section">
    <div class="auth-container">

        <?php if ($message): ?>
            <div class="alert <?php echo $message_type === 'error' ? 'alert-error' : 'alert-success'; ?>">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <div class="auth-form-card">
            <div class="form-header">
                <h3>Sign In</h3>
            </div>
            <form method="POST" action="">
                <div class="form-group">
                    <label>Email Address</label>
                    <input type="email" name="email" required placeholder="email@example.com">
                </div>

                <div class="form-group">
                    <label>Password</label>
                    <div class="password-wrapper">
                        <input type="password" id="signinPassword" name="password" required
                            placeholder="Enter your password">
                        <i class="fas fa-eye password-toggle" onclick="togglePassword('signinPassword', this)"></i>
                    </div>
                </div>

                <button type="submit" class="btn-auth">
                    <span>Sign In</span>
                    <i class="fas fa-sign-in-alt"></i>
                </button>
            </form>

            <div class="auth-footer">
                Don't have an account? <a href="<?php echo SITE_URL; ?>/signup.php">Sign Up</a>
            </div>
        </div>
    </div>
</section>

<style>
    .password-wrapper {
        position: relative;
    }

    .password-toggle {
        position: absolute;
        right: 15px;
        top: 50%;
        transform: translateY(-50%);
        cursor: pointer;
        color: #6b7280;
        transition: color 0.3s ease;
        font-size: 16px;
    }

    .password-toggle:hover {
        color: var(--primary-crimson);
    }

    .password-wrapper input {
        padding-right: 45px;
    }
</style>

<script>
    function togglePassword(inputId, icon) {
        const input = document.getElementById(inputId);
        if (input.type === 'password') {
            input.type = 'text';
            icon.classList.remove('fa-eye');
            icon.classList.add('fa-eye-slash');
        } else {
            input.type = 'password';
            icon.classList.remove('fa-eye-slash');
            icon.classList.add('fa-eye');
        }
    }
</script>

<?php include 'includes/footer.php'; ?>