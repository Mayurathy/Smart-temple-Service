-- Add products table to database
CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    slug VARCHAR(255) NOT NULL UNIQUE,
    description TEXT,
    category ENUM('puja_items', 'prasad', 'devotional', 'miscellaneous') NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    quantity_unit VARCHAR(50),
    image VARCHAR(255),
    stock_status ENUM('in_stock', 'out_of_stock', 'seasonal') DEFAULT 'in_stock',
    sku VARCHAR(50),
    special_notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('active', 'inactive') DEFAULT 'active'
);

-- Clear existing products (if any)
TRUNCATE TABLE products;

-- Insert your specific products
INSERT INTO products (name, slug, description, category, price, quantity_unit, image, stock_status) VALUES
-- Puja Items
('Incense Sticks', 'incense-sticks', 
 'Natural herbal incense sticks, ideal for daily pooja', 
 'puja_items', 150.00, '20 sticks/pack', 'assets/products/incense.jpg', 'in_stock'),

('Oil Lamp (Kuthuvilakku)', 'oil-lamp-kuthuvilakku', 
 'Traditional brass oil lamp, used during rituals', 
 'puja_items', 1200.00, '1 lamp', 'assets/products/lamp.jpg', 'in_stock'),

('Camphor Tablets', 'camphor-tablets', 
 'Pure camphor for pooja rituals', 
 'puja_items', 200.00, '10 tablets/pack', 'assets/products/camphor.jpg', 'in_stock'),

('Temple Garlands', 'temple-garlands', 
 'Fresh flower garlands for deity decoration', 
 'puja_items', 300.00, '1 garland', 'assets/products/garland.jpg', 'seasonal'),

-- Prasad Items
('Coconut', 'coconut', 
 'Fresh coconut for offerings', 
 'prasad', 250.00, '1 coconut', 'assets/products/coconut.jpg', 'in_stock'),

('Honey Jar', 'honey-jar', 
 'Organic honey for religious offerings', 
 'prasad', 800.00, '250ml jar', 'assets/products/honey.jpg', 'in_stock'),

-- Devotional Items
('Devotional Book', 'devotional-book', 
 'Temple prayer book with chants and instructions', 
 'devotional', 500.00, '1 book', 'assets/products/book.jpg', 'in_stock'),

('Temple Calendar', 'temple-calendar', 
 'Annual calendar with temple events and festival dates', 
 'devotional', 250.00, '1 calendar', 'assets/products/calendar.jpg', 'in_stock');

-- Verify insertion
SELECT 'Products inserted successfully!' as message;
SELECT COUNT(*) as total_products FROM products;
