<?php
require_once 'config/config.php';

$conn = getDBConnection();
$page_title = 'Track Booking - Puja Services';

$message = '';
$message_type = '';
$booking = null;

$prefill_booking_id = isset($_GET['booking_id']) ? sanitize($_GET['booking_id']) : '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $lookup_booking_id = sanitize($_POST['booking_id'] ?? '');
    $lookup_email = sanitize($_POST['user_email'] ?? '');
    $lookup_phone = sanitize($_POST['user_phone'] ?? '');

    if (!empty($lookup_booking_id)) {
        // Validation
        if (!empty($lookup_email) && !filter_var($lookup_email, FILTER_VALIDATE_EMAIL)) {
            $message = "Please enter a valid email address.";
            $message_type = 'error';
        } else {
            // Build query dynamically depending on provided identity (email/phone)
            if (!empty($lookup_email) || !empty($lookup_phone)) {
                $query = "SELECT b.*, p.name AS puja_name, t.name AS temple_name, pr.name AS priest_name
                          FROM bookings b
                          LEFT JOIN pujas p ON b.puja_id = p.id
                          LEFT JOIN temples t ON b.temple_id = t.id
                          LEFT JOIN priests pr ON b.priest_id = pr.id
                          WHERE b.booking_id = ? AND (b.user_email = ? OR b.user_phone = ?)
                          LIMIT 1";
                $stmt = $conn->prepare($query);
                $stmt->bind_param('sss', $lookup_booking_id, $lookup_email, $lookup_phone);
            } else {
                $query = "SELECT b.*, p.name AS puja_name, t.name AS temple_name, pr.name AS priest_name
                          FROM bookings b
                          LEFT JOIN pujas p ON b.puja_id = p.id
                          LEFT JOIN temples t ON b.temple_id = t.id
                          LEFT JOIN priests pr ON b.priest_id = pr.id
                          WHERE b.booking_id = ?
                          LIMIT 1";
                $stmt = $conn->prepare($query);
                $stmt->bind_param('s', $lookup_booking_id);
            }

            if ($stmt->execute()) {
                $res = $stmt->get_result();
                if ($res && $res->num_rows === 1) {
                    $booking = $res->fetch_assoc();
                } else {
                    $message = 'No booking found. Please double‑check the Booking ID and details.';
                    $message_type = 'error';
                }
            } else {
                $message = 'Unable to search right now.';
                $message_type = 'error';
            }
            $stmt->close();
        }
    } else {
        $message = 'Please enter your Booking ID.';
        $message_type = 'error';
    }
}

include 'includes/header.php';
?>

<link rel="stylesheet" href="assets/css/track-booking-premium.css">

<!-- Hero Section -->
<section class="track-hero">
    <div class="container">
        <h1>Track Your Booking</h1>
        <p>Check the status of your puja or service booking instantly.</p>
    </div>
</section>

<section class="track-section">
    <div class="track-container">

        <?php if ($message): ?>
            <div class="alert <?php echo $message_type === 'error' ? 'alert-error' : 'alert-success'; ?>">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <div class="track-form-card">
            <div class="form-header">
                <h3>Enter Booking Details</h3>
            </div>
            <form method="POST" action="">
                <div class="form-group">
                    <label>Booking ID *</label>
                    <input type="text" name="booking_id" required
                        value="<?php echo htmlspecialchars($prefill_booking_id); ?>" placeholder="e.g. BK-12345">
                </div>
                <div class="form-group">
                    <label>Email (Optional)</label>
                    <input type="email" name="user_email" placeholder="email@example.com">
                </div>
                <div class="form-group">
                    <label>Phone (Optional)</label>
                    <input type="tel" name="user_phone" placeholder="Your phone number">
                </div>
                <button type="submit" class="btn-track">
                    <span>Track Booking</span>
                    <i class="fas fa-search"></i>
                </button>
            </form>
        </div>

        <?php if ($booking): ?>
            <div class="booking-result-card">
                <div class="result-header">
                    <h4>Booking Details</h4>
                    <span class="status-badge status-<?php echo htmlspecialchars($booking['status']); ?>">
                        <?php echo ucfirst($booking['status']); ?>
                    </span>
                </div>
                <div class="result-body">
                    <div class="info-row">
                        <span class="info-label">Booking ID</span>
                        <span class="info-value"><?php echo htmlspecialchars($booking['booking_id']); ?></span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Name</span>
                        <span class="info-value"><?php echo htmlspecialchars($booking['user_name']); ?></span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Service</span>
                        <span class="info-value">
                            <?php
                            if ($booking['puja_name']) {
                                echo htmlspecialchars($booking['puja_name']);
                            } elseif ($booking['temple_name']) {
                                echo 'Temple: ' . htmlspecialchars($booking['temple_name']);
                            } elseif ($booking['priest_name']) {
                                echo 'Priest: ' . htmlspecialchars($booking['priest_name']);
                            } else {
                                echo ucfirst($booking['booking_type']);
                            }
                            ?>
                        </span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Date & Time</span>
                        <span class="info-value">
                            <?php echo date('d M Y', strtotime($booking['booking_date'])) . ' ' . ($booking['booking_time'] ? date('h:i A', strtotime($booking['booking_time'])) : ''); ?>
                        </span>
                    </div>
                    <?php if (!empty($booking['address'])): ?>
                        <div class="info-row">
                            <span class="info-label">Address</span>
                            <span class="info-value"><?php echo nl2br(htmlspecialchars($booking['address'])); ?></span>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
</section>

<?php include 'includes/footer.php'; ?>