<?php
require_once 'config/config.php';
$page_title = 'Services - Puja Services';
include 'includes/header.php';

$conn = getDBConnection();
$service_type = isset($_GET['type']) ? $_GET['type'] : 'all';
?>
<link rel="stylesheet" href="<?php echo SITE_URL; ?>/assets/css/services-premium.css?v=<?php echo time(); ?>">

<!-- Services Hero Section -->
<section class="services-hero">
    <div class="container">
        <h1class="animated zoom-in">Divine Services for Your Spiritual Journey</h1>
            <p class="animated fade-in-up delay-200">Experience the essence of Hindu traditions with our comprehensive
                range of spiritual services, from online
                pujas to personalized astrology consultations.</p>
            <div class="hero-buttons animated fade-in-up delay-400">
                <a href="#primary-services" class="btn btn-primary">Explore Services</a>
                <a href="contact.php" class="btn btn-outline-light">Contact Us</a>
            </div>
    </div>
</section>

<!-- Trust Strip -->
<div class="trust-strip">
    <div class="container">
        <div class="trust-grid">
            <div class="trust-item animated fade-in-up delay-100">
                <div class="trust-icon">
                    <i class="fas fa-om"></i>
                </div>
                <div class="trust-text">
                    <h4>Vedic Rituals</h4>
                    <p>Authentic & Traditional</p>
                </div>
            </div>
            <div class="trust-item animated fade-in-up delay-200">
                <div class="trust-icon">
                    <i class="fas fa-user-tie"></i>
                </div>
                <div class="trust-text">
                    <h4>Expert Pandits</h4>
                    <p>Certified & Experienced</p>
                </div>
            </div>
            <div class="trust-item animated fade-in-up delay-300">
                <div class="trust-icon">
                    <i class="fas fa-globe"></i>
                </div>
                <div class="trust-text">
                    <h4>Global Access</h4>
                    <p>Online & Offline Services</p>
                </div>
            </div>
            <div class="trust-item animated fade-in-up delay-400">
                <div class="trust-icon">
                    <i class="fas fa-heart"></i>
                </div>
                <div class="trust-text">
                    <h4>100% Satisfaction</h4>
                    <p>Devotee Focused</p>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Shop by Intention -->
<section class="intention-section">
    <div class="container">
        <span class="section-label animated fade-in-up">Your Purpose</span>
        <h2 class="section-heading text-center animated fade-in-up delay-100">Shop by Intention</h2>
        <div class="intention-grid">
            <div class="intention-card animated zoom-in delay-100"
                onclick="window.location.href='pujas.php?intention=wealth'">
                <div class="intention-icon-wrapper">
                    <img src="https://images.unsplash.com/photo-1605792657660-596af9009e82?q=80&w=400&auto=format&fit=crop"
                        alt="Wealth" onerror="this.src='https://via.placeholder.com/150/FFD700/000000?text=Wealth'">
                </div>
                <h4>Wealth & Prosperity</h4>
            </div>
            <div class="intention-card animated zoom-in delay-200"
                onclick="window.location.href='pujas.php?intention=health'">
                <div class="intention-icon-wrapper">
                    <img src="https://images.unsplash.com/photo-1506126613408-eca07ce68773?q=80&w=1000&auto=format&fit=crop"
                        alt="Health" onerror="this.src='https://via.placeholder.com/150?text=Health'">
                </div>
                <h4>Health & Wellness</h4>
            </div>
            <div class="intention-card animated zoom-in delay-300"
                onclick="window.location.href='pujas.php?intention=career'">
                <div class="intention-icon-wrapper">
                    <img src="https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?q=80&w=1000&auto=format&fit=crop"
                        alt="Career" onerror="this.src='https://via.placeholder.com/150?text=Career'">
                </div>
                <h4>Career & Success</h4>
            </div>
            <div class="intention-card animated zoom-in delay-400"
                onclick="window.location.href='pujas.php?intention=marriage'">
                <div class="intention-icon-wrapper">
                    <img src="https://images.unsplash.com/photo-1583939003579-730e3918a45a?q=80&w=1000&auto=format&fit=crop"
                        alt="Marriage" onerror="this.src='https://via.placeholder.com/150?text=Marriage'">
                </div>
                <h4>Love & Marriage</h4>
            </div>
            <div class="intention-card animated zoom-in delay-500"
                onclick="window.location.href='pujas.php?intention=peace'">
                <div class="intention-icon-wrapper">
                    <img src="https://images.unsplash.com/photo-1528319725582-ddc096101511?q=80&w=1000&auto=format&fit=crop"
                        alt="Peace" onerror="this.src='https://via.placeholder.com/150?text=Peace'">
                </div>
                <h4>Peace & Harmony</h4>
            </div>
            <div class="intention-card animated zoom-in delay-600"
                onclick="window.location.href='pujas.php?intention=education'">
                <div class="intention-icon-wrapper">
                    <img src="https://images.unsplash.com/photo-1503676260728-1c00da094a0b?q=80&w=1000&auto=format&fit=crop"
                        alt="Education" onerror="this.src='https://via.placeholder.com/150?text=Education'">
                </div>
                <h4>Education & Wisdom</h4>
            </div>
        </div>
    </div>
</section>

<!-- Primary Services -->
<section class="services-section" id="primary-services">
    <div class="container">
        <div class="primary-services-header">
            <span class="section-label animated fade-in-up">Our Offerings</span>
            <h2 class="primary-services-title animated fade-in-up delay-100">Our Core Services</h2>
        </div>

        <div class="primary-services-grid">
            <!-- Online Puja -->
            <div class="primary-service-card animated fade-in-up delay-100">
                <div class="primary-service-icon">
                    <i class="fas fa-laptop-house"></i>
                </div>
                <h3>Online E-Puja</h3>
                <p>Participate in sacred rituals from the comfort of your home via live video streaming.</p>
            </div>

            <!-- Temple Puja -->
            <div class="primary-service-card animated fade-in-up delay-200">
                <div class="primary-service-icon">
                    <i class="fas fa-gopuram"></i>
                </div>
                <h3>Temple Puja</h3>
                <p>We perform pujas at famous temples across India on your behalf with full Vedic rites.</p>
            </div>

            <!-- Astrology -->
            <div class="primary-service-card animated fade-in-up delay-300">
                <div class="primary-service-icon">
                    <i class="fas fa-star-and-crescent"></i>
                </div>
                <h3>Astrology</h3>
                <p>Get detailed horoscope analysis and remedies from expert astrologers.</p>
            </div>

            <!-- Homa & Yagna -->
            <div class="primary-service-card animated fade-in-up delay-400">
                <div class="primary-service-icon">
                    <i class="fas fa-fire-alt"></i>
                </div>
                <h3>Homa & Yagna</h3>
                <p>Powerful fire rituals performed by learned priests for specific benefits.</p>
            </div>
        </div>

        <!-- Detailed Services Grid -->
        <div class="services-grid">
            <!-- Dosha Nivaran -->
            <div class="service-card animated zoom-in delay-100">
                <i class="fas fa-shield-alt"></i>
                <h3>Dosha Nivaran</h3>
                <ul>
                    <li><i class="fas fa-check-circle"></i> Kaal Sarp Dosh</li>
                    <li><i class="fas fa-check-circle"></i> Mangal Dosh</li>
                    <li><i class="fas fa-check-circle"></i> Pitra Dosh</li>
                </ul>
                <a href="pujas.php?category=dosha" class="btn btn-primary">Book Now</a>
            </div>

            <!-- Sanskaras -->
            <div class="service-card animated zoom-in delay-200">
                <i class="fas fa-baby"></i>
                <h3>Sanskaras</h3>
                <ul>
                    <li><i class="fas fa-check-circle"></i> Namkaran</li>
                    <li><i class="fas fa-check-circle"></i> Mundan</li>
                    <li><i class="fas fa-check-circle"></i> Annaprashan</li>
                </ul>
                <a href="pujas.php?category=sanskar" class="btn btn-primary">Book Now</a>
            </div>

            <!-- Festival Pujas -->
            <div class="service-card animated zoom-in delay-300">
                <i class="fas fa-calendar-alt"></i>
                <h3>Festival Pujas</h3>
                <ul>
                    <li><i class="fas fa-check-circle"></i> Diwali Lakshmi Puja</li>
                    <li><i class="fas fa-check-circle"></i> Navratri Puja</li>
                    <li><i class="fas fa-check-circle"></i> Ganesh Chaturthi</li>
                </ul>
                <a href="pujas.php?category=festival" class="btn btn-primary">Book Now</a>
            </div>
        </div>
    </div>
</section>

<!-- How It Works -->
<section class="how-it-works-section">
    <div class="container">
        <div class="text-center">
            <span class="section-label animated fade-in-up">Process</span>
            <h2 class="section-heading animated fade-in-up delay-100">How It Works</h2>
        </div>
        <div class="steps-grid">
            <div class="step-card animated fade-in-left delay-100">
                <div class="step-number">1</div>
                <div class="step-icon">
                    <i class="fas fa-search"></i>
                </div>
                <h3>Select Service</h3>
                <p>Choose from our wide range of pujas and spiritual services.</p>
            </div>
            <div class="step-card animated fade-in-left delay-200">
                <div class="step-number">2</div>
                <div class="step-icon">
                    <i class="fas fa-calendar-check"></i>
                </div>
                <h3>Book & Pay</h3>
                <p>Provide details and make a secure online payment.</p>
            </div>
            <div class="step-card animated fade-in-left delay-300">
                <div class="step-number">3</div>
                <div class="step-icon">
                    <i class="fas fa-praying-hands"></i>
                </div>
                <h3>We Perform</h3>
                <p>Our pandits perform the puja with full Vedic rituals.</p>
            </div>
            <div class="step-card animated fade-in-left delay-400">
                <div class="step-number">4</div>
                <div class="step-icon">
                    <i class="fas fa-gift"></i>
                </div>
                <h3>Receive Prasad</h3>
                <p>Get the divine blessings (Prasad) delivered to your doorstep.</p>
            </div>
        </div>
    </div>
</section>

<!-- Spiritual Tools (Premium Dark Section) -->
<section class="spiritual-tools-section">
    <div class="container">

    </div>
    <div class="service-card animated zoom-in delay-300">
        <div style="height: 200px; overflow: hidden; border-radius: 15px; margin-bottom: 20px;">
            <img src="https://images.unsplash.com/photo-1516233758813-a38d024919c5?w=600&h=400&fit=crop"
                alt="Rudra Abhishekam"
                style="width: 100%; height: 100%; object-fit: cover; transition: transform 0.5s ease;">
        </div>
        <h3>Rudra Abhishekam</h3>
        <p>Invoke Lord Shiva's grace for health, peace, and protection from negativity.</p>
        <a href="<?php echo SITE_URL; ?>/book-puja.php?puja=rudra" class="btn btn-primary"
            style="width: 100%; text-align: center;">Book Now</a>
    </div>
    </div>
    </div>
</section>

<!-- FAQ Section -->
<section class="faq-section">
    <div class="container">
        <div class="section-header text-center">
            <span class="section-label" style="color: #dc2626; font-weight: 700; letter-spacing: 2px;">FAQ</span>
            <h2 class="section-heading" style="font-size: 42px; font-weight: 900; margin-top: 10px;">Common Questions
            </h2>
        </div>
        <div class="faq-grid">
            <div class="faq-item animated fade-in-up delay-100">
                <h3><i class="fas fa-question-circle"></i> How do Online Pujas work?</h3>
                <p>Our priests perform the puja at the temple/venue while you participate via live video call. Prasad is
                    shipped to your address.</p>
            </div>
            <div class="faq-item animated fade-in-up delay-200">
                <h3><i class="fas fa-user-check"></i> Are the priests verified?</h3>
                <p>Yes, all our priests are certified Vedic scholars with years of experience in performing rituals.</p>
            </div>
            <div class="faq-item animated fade-in-up delay-300">
                <h3><i class="fas fa-calendar-alt"></i> Can I choose the date and time?</h3>
                <p>Absolutely! You can select your preferred date and time during the booking process.</p>
            </div>
            <div class="faq-item animated fade-in-up delay-400">
                <h3><i class="fas fa-credit-card"></i> Is payment secure?</h3>
                <p>We use industry-standard encryption and secure payment gateways to ensure your transaction is safe.
                </p>
            </div>
        </div>
    </div>
</section>

<!-- CTA Banner -->
<section class="cta-section"
    style="background: linear-gradient(135deg, #1f2937 0%, #111827 100%); padding: 80px 0; text-align: center; color: white;">
    <div class="container">
        <h2 style="font-size: 36px; font-weight: 900; margin-bottom: 20px; color: #ffffff;">Not Sure Which Puja to
            Choose?</h2>
        <p
            style="font-size: 18px; opacity: 0.9; margin-bottom: 30px; max-width: 600px; margin-left: auto; margin-right: auto; color: #ffffff;">
            Consult with our expert astrologers to find the perfect ritual for your specific needs and dosha pariharam.
        </p>
        <a href="<?php echo SITE_URL; ?>/contact.php" class="btn btn-primary"
            style="background: white; color: #dc2626; border: none;">Talk to Expert</a>
    </div>
</section>

<?php
// Show temples if temple service
if ($service_type == 'temple'):
    $temples_query = "SELECT * FROM temples WHERE status = 'active'";
    $temples_result = $conn->query($temples_query);
    ?>
    <section class="puja-section" style="padding: 80px 0; background: #f9fafb;">
        <div class="container">
            <h2 class="section-title" style="text-align: center; font-size: 36px; font-weight: 800; margin-bottom: 50px;">
                Available Temples</h2>
            <div class="puja-grid">
                <?php if ($temples_result && $temples_result->num_rows > 0): ?>
                    <?php while ($temple = $temples_result->fetch_assoc()): ?>
                        <div class="puja-card"
                            style="border-radius: 20px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.1);">
                            <div
                                style="background: linear-gradient(135deg, #1f2937 0%, #374151 100%); height: 200px; display: flex; align-items: center; justify-content: center; color: white; font-size: 48px;">
                                <i class="fas fa-gopuram"></i>
                            </div>
                            <div class="puja-card-content" style="padding: 25px;">
                                <h3 style="font-size: 22px; font-weight: 700; margin-bottom: 10px;">
                                    <?php echo htmlspecialchars($temple['name']); ?>
                                </h3>
                                <p style="color: #666; margin-bottom: 15px;"><i class="fas fa-map-marker-alt"
                                        style="color: #dc2626;"></i>
                                    <?php echo htmlspecialchars($temple['location'] . ', ' . $temple['city'] . ', ' . $temple['state']); ?>
                                </p>
                                <p style="margin-bottom: 20px;">
                                    <?php echo htmlspecialchars(substr($temple['description'], 0, 100)) . '...'; ?>
                                </p>
                                <a href="<?php echo SITE_URL; ?>/book-puja.php?type=temple&temple_id=<?php echo $temple['id']; ?>"
                                    class="btn btn-primary" style="width: 100%; text-align: center;">Book Puja Here</a>
                            </div>
                        </div>
                    <?php endwhile; ?>
                <?php endif; ?>
            </div>
        </div>
    </section>
<?php endif; ?>

<?php
// Show priests if priest service
if ($service_type == 'priest'):
    $priests_query = "SELECT * FROM priests WHERE status = 'active'";
    $priests_result = $conn->query($priests_query);
    ?>
    <section class="puja-section" style="padding: 80px 0; background: #f9fafb;">
        <div class="container">
            <h2 class="section-title" style="text-align: center; font-size: 36px; font-weight: 800; margin-bottom: 50px;">
                Available Priests</h2>
            <div class="puja-grid">
                <?php if ($priests_result && $priests_result->num_rows > 0): ?>
                    <?php while ($priest = $priests_result->fetch_assoc()): ?>
                        <div class="puja-card"
                            style="border-radius: 20px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.1);">
                            <div
                                style="background: linear-gradient(135deg, #065f46 0%, #047857 100%); height: 200px; display: flex; align-items: center; justify-content: center; color: white; font-size: 48px;">
                                <i class="fas fa-user-tie"></i>
                            </div>
                            <div class="puja-card-content" style="padding: 25px;">
                                <h3 style="font-size: 22px; font-weight: 700; margin-bottom: 10px;">
                                    <?php echo htmlspecialchars($priest['name']); ?>
                                </h3>
                                <p style="margin-bottom: 8px;"><i class="fas fa-star" style="color: #fbbf24;"></i>
                                    <?php echo $priest['experience']; ?> Years Experience</p>
                                <p style="margin-bottom: 8px;"><i class="fas fa-map-marker-alt" style="color: #dc2626;"></i>
                                    <?php echo htmlspecialchars($priest['location']); ?></p>
                                <p style="margin-bottom: 20px;"><strong>Specialization:</strong>
                                    <?php echo htmlspecialchars($priest['specialization']); ?></p>
                                <a href="<?php echo SITE_URL; ?>/book-puja.php?type=priest&priest_id=<?php echo $priest['id']; ?>"
                                    class="btn btn-primary" style="width: 100%; text-align: center;">Book This Priest</a>
                            </div>
                        </div>
                    <?php endwhile; ?>
                <?php endif; ?>
            </div>
        </div>
    </section>
<?php endif; ?>

<?php
$conn->close();
include 'includes/footer.php';
?>