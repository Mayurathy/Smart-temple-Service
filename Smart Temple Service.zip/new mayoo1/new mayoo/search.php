<?php
require_once 'config/config.php';
$page_title = 'Search - Puja Services';

$conn = getDBConnection();
$search_query = isset($_GET['q']) ? sanitize($_GET['q']) : '';
$results = [];

if (!empty($search_query)) {
    // Search in pujas
    $pujas_query = "SELECT 'puja' as type, id, name, description, slug FROM pujas WHERE (name LIKE ? OR description LIKE ?) AND status = 'active'";
    $stmt = $conn->prepare($pujas_query);
    $search_param = "%{$search_query}%";
    $stmt->bind_param('ss', $search_param, $search_param);
    $stmt->execute();
    $pujas_result = $stmt->get_result();
    while ($row = $pujas_result->fetch_assoc()) {
        $results[] = $row;
    }
    $stmt->close();

    // Search in temples
    $temples_query = "SELECT 'temple' as type, id, name, description, '' as slug FROM temples WHERE (name LIKE ? OR description LIKE ?) AND status = 'active'";
    $stmt = $conn->prepare($temples_query);
    $stmt->bind_param('ss', $search_param, $search_param);
    $stmt->execute();
    $temples_result = $stmt->get_result();
    while ($row = $temples_result->fetch_assoc()) {
        $results[] = $row;
    }
    $stmt->close();
}

include 'includes/header.php';
?>

<link rel="stylesheet" href="assets/css/search-premium.css">

<section class="search-hero">
    <div class="container">
        <h1>Search Puja Services</h1>
        <p>Find the perfect puja, temple, or service for your spiritual needs</p>
    </div>
</section>

<section class="search-section">
    <div class="container">
        <div class="search-bar-wrapper">
            <form method="GET" action="">
                <div class="search-input-group">
                    <i class="fas fa-search"></i>
                    <input type="text" name="q" value="<?php echo htmlspecialchars($search_query); ?>"
                        placeholder="Search for pujas, temples, priests..." required>
                    <button type="submit" class="btn-search">Search</button>
                </div>
            </form>
        </div>

        <?php if (!empty($search_query)): ?>
            <div class="search-results">
                <h2>Search Results for "<?php echo htmlspecialchars($search_query); ?>"</h2>
                <p class="results-count"><?php echo count($results); ?> results found</p>

                <?php if (!empty($results)): ?>
                    <div class="results-grid">
                        <?php foreach ($results as $item): ?>
                            <div class="result-card">
                                <div class="result-type-badge"><?php echo ucfirst($item['type']); ?></div>
                                <h3><?php echo htmlspecialchars($item['name']); ?></h3>
                                <p><?php echo htmlspecialchars(substr($item['description'], 0, 150)) . '...'; ?></p>
                                <?php if ($item['type'] === 'puja'): ?>
                                    <a href="puja-details.php?slug=<?php echo $item['slug']; ?>" class="btn-view">View Details</a>
                                <?php elseif ($item['type'] === 'temple'): ?>
                                    <a href="book-puja.php?type=temple&temple_id=<?php echo $item['id']; ?>" class="btn-view">Book
                                        Puja</a>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="no-results">
                        <i class="fas fa-search"></i>
                        <h3>No results found</h3>
                        <p>Try different keywords or browse our services</p>
                        <a href="services.php" class="btn-browse">Browse Services</a>
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</section>

<?php
$conn->close();
include 'includes/footer.php';
?>