<?php
$page_title = 'Home - Puja Services';
require_once 'config/config.php';
include 'includes/header.php';

$conn = getDBConnection();

// Get featured pujas
$featured_pujas = $conn->query("SELECT * FROM pujas WHERE status = 'active' ORDER BY id DESC LIMIT 6");

// Get active temples count
$temples_count = $conn->query("SELECT COUNT(*) as count FROM temples WHERE status = 'active'")->fetch_assoc()['count'];

// Get total bookings count
$bookings_count = $conn->query("SELECT COUNT(*) as count FROM bookings")->fetch_assoc()['count'];

// Get active priests count
$priests_count = $conn->query("SELECT COUNT(*) as count FROM priests WHERE status = 'active'")->fetch_assoc()['count'];
?>

<!-- Hero Section -->
<section class="hero-section">
    <div class="hero-overlay"></div>
    <div class="hero-content">
        <div class="container">
            <div class="hero-text animated fade-in-up">
                <h1 class="hero-title">Sacred Rituals, <span class="highlight">Divine Blessings</span></h1>
                <p class="hero-subtitle">Experience authentic Vedic pujas performed by experienced priests. Book your
                    divine service today.</p>
                <div class="hero-buttons">
                    <a href="<?php echo SITE_URL; ?>/pujas.php" class="btn btn-primary btn-lg">
                        <i class="fas fa-pray"></i> Explore Pujas
                    </a>
                    <a href="<?php echo SITE_URL; ?>/book-puja.php" class="btn btn-outline btn-lg">
                        <i class="fas fa-calendar-alt"></i> Book Now
                    </a>
                </div>
            </div>

            <!-- Floating Stats -->
            <div class="hero-stats animated fade-in-up delay-200">
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-gopuram"></i></div>
                    <div class="stat-content">
                        <h3>
                            <?php echo $temples_count; ?>+
                        </h3>
                        <p>Temples</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-user-tie"></i></div>
                    <div class="stat-content">
                        <h3>
                            <?php echo $priests_count; ?>+
                        </h3>
                        <p>Expert Priests</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-calendar-check"></i></div>
                    <div class="stat-content">
                        <h3>
                            <?php echo $bookings_count; ?>+
                        </h3>
                        <p>Bookings</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Decorative Elements -->
    <div class="hero-decoration decoration-1"></div>
    <div class="hero-decoration decoration-2"></div>
</section>

<!-- Features Section -->
<section class="features-section">
    <div class="container">
        <div class="section-header text-center animated fade-in">
            <h2>Why Choose Our Services</h2>
            <p>Experience divine blessings with our authentic and professional puja services</p>
        </div>

        <div class="features-grid">
            <div class="feature-card animated fade-in-up delay-100">
                <div class="feature-icon">
                    <i class="fas fa-user-graduate"></i>
                </div>
                <h3>Experienced Priests</h3>
                <p>Qualified and experienced priests well-versed in Vedic rituals and traditions</p>
            </div>

            <div class="feature-card animated fade-in-up delay-200">
                <div class="feature-icon">
                    <i class="fas fa-home"></i>
                </div>
                <h3>Home Service</h3>
                <p>Puja services at your home with all necessary samagri and arrangements</p>
            </div>

            <div class="feature-card animated fade-in-up delay-300">
                <div class="feature-icon">
                    <i class="fas fa-calendar-check"></i>
                </div>
                <h3>Easy Booking</h3>
                <p>Simple online booking system with instant confirmation and scheduling</p>
            </div>

            <div class="feature-card animated fade-in-up delay-400">
                <div class="feature-icon">
                    <i class="fas fa-shield-alt"></i>
                </div>
                <h3>Authentic Rituals</h3>
                <p>Traditional and authentic Vedic ceremonies performed with devotion</p>
            </div>
        </div>
    </div>
</section>

<!-- Featured Pujas Section -->
<section class="pujas-section">
    <div class="container">
        <div class="section-header text-center animated fade-in">
            <h2>Popular Pujas</h2>
            <p>Explore our most sought-after sacred rituals and ceremonies</p>
        </div>

        <div class="pujas-grid">
            <?php if ($featured_pujas && $featured_pujas->num_rows > 0): ?>
                <?php $delay = 100; ?>
                <?php while ($puja = $featured_pujas->fetch_assoc()): ?>
                    <div class="puja-card animated fade-in-up delay-<?php echo $delay; ?>">
                        <div class="puja-image">
                            <?php if ($puja['image']): ?>
                                <img src="<?php echo SITE_URL; ?>/assets/images/pujas/<?php echo $puja['image']; ?>"
                                    alt="<?php echo htmlspecialchars($puja['name']); ?>">
                            <?php else: ?>
                                <div class="puja-placeholder">
                                    <i class="fas fa-om"></i>
                                </div>
                            <?php endif; ?>
                            <div class="puja-overlay">
                                <a href="<?php echo SITE_URL; ?>/book-puja.php?puja_id=<?php echo $puja['id']; ?>"
                                    class="btn btn-primary">
                                    Book Now
                                </a>
                            </div>
                        </div>
                        <div class="puja-content">
                            <h3>
                                <?php echo htmlspecialchars($puja['name']); ?>
                            </h3>
                            <p>
                                <?php echo truncate($puja['description'], 100); ?>
                            </p>
                            <div class="puja-footer">
                                <span class="puja-price">₹
                                    <?php echo number_format($puja['price'], 0); ?>
                                </span>
                                <a href="<?php echo SITE_URL; ?>/puja-details.php?id=<?php echo $puja['id']; ?>"
                                    class="puja-link">
                                    Learn More <i class="fas fa-arrow-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    <?php $delay += 50; ?>
                <?php endwhile; ?>
            <?php endif; ?>
        </div>

        <div class="text-center" style="margin-top: 40px;">
            <a href="<?php echo SITE_URL; ?>/pujas.php" class="btn btn-outline btn-lg">
                View All Pujas <i class="fas fa-arrow-right"></i>
            </a>
        </div>
    </div>
</section>

<!-- How It Works Section -->
<section class="how-it-works-section">
    <div class="container">
        <div class="section-header text-center animated fade-in">
            <h2>How It Works</h2>
            <p>Simple and easy process to book your puja</p>
        </div>

        <div class="steps-container">
            <div class="step-card animated fade-in-up delay-100">
                <div class="step-number">1</div>
                <div class="step-icon"><i class="fas fa-search"></i></div>
                <h3>Choose Puja</h3>
                <p>Browse and select the puja service that suits your needs</p>
            </div>

            <div class="step-connector"></div>

            <div class="step-card animated fade-in-up delay-200">
                <div class="step-number">2</div>
                <div class="step-icon"><i class="fas fa-calendar"></i></div>
                <h3>Select Date & Time</h3>
                <p>Pick your preferred date and time for the ceremony</p>
            </div>

            <div class="step-connector"></div>

            <div class="step-card animated fade-in-up delay-300">
                <div class="step-number">3</div>
                <div class="step-icon"><i class="fas fa-check-circle"></i></div>
                <h3>Confirm Booking</h3>
                <p>Complete the booking and receive instant confirmation</p>
            </div>

            <div class="step-connector"></div>

            <div class="step-card animated fade-in-up delay-400">
                <div class="step-number">4</div>
                <div class="step-icon"><i class="fas fa-pray"></i></div>
                <div>
                    <h3>Experience Divine Blessings</h3>
                    <p>Priest arrives and performs the puja with devotion</p>
                </div>
            </div>
        </div>
</section>

<!-- CTA Section -->
<section class="cta-section">
    <div class="container">
        <div class="cta-content animated fade-in-up">
            <h2>Ready to Book Your Puja?</h2>
            <p>Join thousands of devotees who have experienced divine blessings through our services</p>
            <a href="<?php echo SITE_URL; ?>/book-puja.php" class="btn btn-primary btn-lg">
                <i class="fas fa-calendar-plus"></i> Book Your Puja Now
            </a>
        </div>
    </div>
</section>

<style>
    /* Hero Section */
    .hero-section {
        position: relative;
        min-height: 90vh;
        display: flex;
        align-items: center;
        background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);
        overflow: hidden;
    }

    .hero-overlay {
        position: absolute;
        inset: 0;
        background: url('data:image/svg+xml,<svg width="100" height="100" xmlns="http://www.w3.org/2000/svg"><defs><pattern id="grid" width="100" height="100" patternUnits="userSpaceOnUse"><path d="M 100 0 L 0 0 0 100" fill="none" stroke="rgba(255,255,255,0.05)" stroke-width="1"/></pattern></defs><rect width="100%" height="100%" fill="url(%23grid)"/></svg>');
        opacity: 0.5;
    }

    .hero-content {
        position: relative;
        z-index: 2;
        width: 100%;
        padding: 80px 0;
    }

    .hero-text {
        text-align: center;
        color: white;
        margin-bottom: 60px;
    }

    .hero-title {
        font-size: 3.5rem;
        font-weight: 800;
        margin-bottom: 20px;
        line-height: 1.2;
    }

    .hero-title .highlight {
        background: linear-gradient(135deg, #D4AF37, #F4E5BC);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
    }

    .hero-subtitle {
        font-size: 1.3rem;
        opacity: 0.9;
        margin-bottom: 40px;
        max-width: 700px;
        margin-left: auto;
        margin-right: auto;
    }

    .hero-buttons {
        display: flex;
        gap: 20px;
        justify-content: center;
        flex-wrap: wrap;
    }

    .hero-stats {
        display: flex;
        justify-content: center;
        gap: 30px;
        flex-wrap: wrap;
    }

    .stat-card {
        background: rgba(255, 255, 255, 0.1);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 16px;
        padding: 25px 35px;
        display: flex;
        align-items: center;
        gap: 20px;
        transition: all 0.3s ease;
    }

    .stat-card:hover {
        transform: translateY(-5px);
        background: rgba(255, 255, 255, 0.15);
    }

    .stat-icon {
        width: 60px;
        height: 60px;
        background: linear-gradient(135deg, #D4AF37, #F4E5BC);
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 24px;
        color: #1a1a2e;
    }

    .stat-content h3 {
        font-size: 2rem;
        font-weight: 800;
        color: white;
        margin: 0;
    }

    .stat-content p {
        font-size: 0.9rem;
        color: rgba(255, 255, 255, 0.8);
        margin: 0;
    }

    /* Hero Decorations */
    .hero-decoration {
        position: absolute;
        border-radius: 50%;
        background: radial-gradient(circle, rgba(212, 175, 55, 0.15) 0%, transparent 70%);
    }

    .decoration-1 {
        width: 500px;
        height: 500px;
        top: -200px;
        right: -100px;
    }

    .decoration-2 {
        width: 400px;
        height: 400px;
        bottom: -150px;
        left: -100px;
    }

    /* Features Section */
    .features-section {
        padding: 100px 0;
        background: #f9fafb;
    }

    .features-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 30px;
        margin-top: 60px;
    }

    .feature-card {
        background: white;
        padding: 40px 30px;
        border-radius: 16px;
        text-align: center;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
        transition: all 0.3s ease;
    }

    .feature-card:hover {
        transform: translateY(-8px);
        box-shadow: 0 12px 40px rgba(0, 0, 0, 0.12);
    }

    .feature-icon {
        width: 80px;
        height: 80px;
        background: linear-gradient(135deg, #D4AF37, #F4E5BC);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 25px;
        font-size: 32px;
        color: #1a1a2e;
    }

    .feature-card h3 {
        font-size: 1.3rem;
        margin-bottom: 15px;
        color: #1a1a2e;
    }

    .feature-card p {
        color: #6b7280;
        line-height: 1.6;
    }

    /* Pujas Section */
    .pujas-section {
        padding: 100px 0;
    }

    .pujas-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
        gap: 30px;
        margin-top: 60px;
    }

    .puja-card {
        background: white;
        border-radius: 16px;
        overflow: hidden;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
        transition: all 0.3s ease;
    }

    .puja-card:hover {
        transform: translateY(-8px);
        box-shadow: 0 12px 40px rgba(0, 0, 0, 0.15);
    }

    .puja-image {
        position: relative;
        height: 220px;
        overflow: hidden;
    }

    .puja-image img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        transition: transform 0.5s ease;
    }

    .puja-card:hover .puja-image img {
        transform: scale(1.1);
    }

    .puja-placeholder {
        width: 100%;
        height: 100%;
        background: linear-gradient(135deg, #D4AF37, #F4E5BC);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 60px;
        color: white;
    }

    .puja-overlay {
        position: absolute;
        inset: 0;
        background: rgba(26, 26, 46, 0.8);
        display: flex;
        align-items: center;
        justify-content: center;
        opacity: 0;
        transition: opacity 0.3s ease;
    }

    .puja-card:hover .puja-overlay {
        opacity: 1;
    }

    .puja-content {
        padding: 25px;
    }

    .puja-content h3 {
        font-size: 1.3rem;
        margin-bottom: 12px;
        color: #1a1a2e;
    }

    .puja-content p {
        color: #6b7280;
        line-height: 1.6;
        margin-bottom: 20px;
    }

    .puja-footer {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding-top: 20px;
        border-top: 1px solid #e5e7eb;
    }

    .puja-price {
        font-size: 1.5rem;
        font-weight: 700;
        color: #D4AF37;
    }

    .puja-link {
        color: #1a1a2e;
        font-weight: 600;
        text-decoration: none;
        transition: color 0.3s ease;
    }

    .puja-link:hover {
        color: #D4AF37;
    }

    /* How It Works */
    .how-it-works-section {
        padding: 100px 0;
        background: #f9fafb;
    }

    .steps-container {
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 20px;
        margin-top: 60px;
        flex-wrap: wrap;
    }

    .step-card {
        background: white;
        padding: 40px 30px;
        border-radius: 16px;
        text-align: center;
        max-width: 220px;
        position: relative;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
    }

    .step-number {
        position: absolute;
        top: -15px;
        left: 50%;
        transform: translateX(-50%);
        width: 40px;
        height: 40px;
        background: linear-gradient(135deg, #D4AF37, #F4E5BC);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 800;
        color: #1a1a2e;
        font-size: 1.2rem;
    }

    .step-icon {
        width: 70px;
        height: 70px;
        background: #f3f4f6;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 20px;
        font-size: 28px;
        color: #D4AF37;
    }

    .step-card h3 {
        font-size: 1.1rem;
        margin-bottom: 10px;
        color: #1a1a2e;
    }

    .step-card p {
        color: #6b7280;
        font-size: 0.9rem;
    }

    .step-connector {
        width: 80px;
        height: 2px;
        background: linear-gradient(to right, #D4AF37, #F4E5BC);
        display: none;
    }

    /* CTA Section */
    .cta-section {
        padding: 100px 0;
        background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
    }

    .cta-content {
        text-align: center;
        color: white;
    }

    .cta-content h2 {
        font-size: 2.5rem;
        margin-bottom: 20px;
    }

    .cta-content p {
        font-size: 1.2rem;
        opacity: 0.9;
        margin-bottom: 40px;
        max-width: 600px;
        margin-left: auto;
        margin-right: auto;
    }

    /* Responsive */
    @media (min-width: 768px) {
        .step-connector {
            display: block;
        }
    }

    @media (max-width: 768px) {
        .hero-title {
            font-size: 2.2rem;
        }

        .hero-subtitle {
            font-size: 1rem;
        }

        .hero-stats {
            flex-direction: column;
            align-items: center;
        }

        .stat-card {
            width: 100%;
            max-width: 300px;
        }
    }

    /* Animations */
    @keyframes fadeIn {
        from {
            opacity: 0;
        }

        to {
            opacity: 1;
        }
    }

    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(30px);
        }

        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .animated {
        animation-duration: 0.8s;
        animation-fill-mode: both;
    }

    .fade-in {
        animation-name: fadeIn;
    }

    .fade-in-up {
        animation-name: fadeInUp;
    }

    .delay-100 {
        animation-delay: 0.1s;
    }

    .delay-200 {
        animation-delay: 0.2s;
    }

    .delay-300 {
        animation-delay: 0.3s;
    }

    .delay-400 {
        animation-delay: 0.4s;
    }
</style>

<?php
$conn->close();
include 'includes/footer.php';
?>