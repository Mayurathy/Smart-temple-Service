-- Puja Services Database Structure
-- Updated with all required columns and proper schema

CREATE DATABASE IF NOT EXISTS puja_services CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE puja_services;

-- Admin Users Table with role support
CREATE TABLE IF NOT EXISTS admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL UNIQUE,
    email VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('superadmin', 'content', 'operations', 'manager') DEFAULT 'superadmin',
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_username (username),
    INDEX idx_email (email),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Frontend Users Table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    phone VARCHAR(25) NOT NULL,
    password VARCHAR(255) NOT NULL,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_email (email),
    INDEX idx_phone (phone)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Priests Table
CREATE TABLE IF NOT EXISTS priests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    phone VARCHAR(20) NOT NULL,
    experience INT DEFAULT 0,
    specialization TEXT,
    location VARCHAR(255),
    image VARCHAR(255),
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_status (status),
    INDEX idx_location (location)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Temples Table
CREATE TABLE IF NOT EXISTS temples (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    location VARCHAR(255) NOT NULL,
    city VARCHAR(100),
    state VARCHAR(100),
    description TEXT,
    image VARCHAR(255),
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_city (city),
    INDEX idx_state (state),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Pujas Table with category support
CREATE TABLE IF NOT EXISTS pujas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    slug VARCHAR(255) NOT NULL UNIQUE,
    description TEXT,
    significance TEXT,
    when_to_perform TEXT,
    advantages TEXT,
    image VARCHAR(255),
    category VARCHAR(50) DEFAULT 'general',
    price DECIMAL(10, 2) DEFAULT 0.00,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_slug (slug),
    INDEX idx_category (category),
    INDEX idx_status (status),
    INDEX idx_price (price)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Bookings Table
CREATE TABLE IF NOT EXISTS bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    booking_id VARCHAR(50) UNIQUE NOT NULL,
    user_name VARCHAR(255) NOT NULL,
    user_email VARCHAR(255) NOT NULL,
    user_phone VARCHAR(20) NOT NULL,
    puja_id INT DEFAULT NULL,
    temple_id INT DEFAULT NULL,
    priest_id INT DEFAULT NULL,
    booking_type ENUM('home', 'temple', 'online') NOT NULL DEFAULT 'home',
    booking_date DATE NOT NULL,
    booking_time TIME,
    address TEXT,
    special_requests TEXT,
    status ENUM('pending', 'confirmed', 'completed', 'cancelled') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_booking_id (booking_id),
    INDEX idx_user_email (user_email),
    INDEX idx_booking_date (booking_date),
    INDEX idx_status (status),
    FOREIGN KEY (puja_id) REFERENCES pujas(id) ON DELETE SET NULL,
    FOREIGN KEY (temple_id) REFERENCES temples(id) ON DELETE SET NULL,
    FOREIGN KEY (priest_id) REFERENCES priests(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Contact Messages Table
CREATE TABLE IF NOT EXISTS contacts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(20),
    subject VARCHAR(255),
    message TEXT NOT NULL,
    status ENUM('new', 'read', 'replied') DEFAULT 'new',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_status (status),
    INDEX idx_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Subscribers Table
CREATE TABLE IF NOT EXISTS subscribers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL UNIQUE,
    status ENUM('active', 'unsubscribed') DEFAULT 'active',
    subscribed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_email (email),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Donations Table
CREATE TABLE IF NOT EXISTS donations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    donor_name VARCHAR(255) NOT NULL,
    donor_email VARCHAR(255) NOT NULL,
    donor_phone VARCHAR(20),
    amount DECIMAL(10, 2) NOT NULL,
    purpose VARCHAR(255),
    payment_method VARCHAR(50),
    payment_status ENUM('pending', 'completed', 'failed') DEFAULT 'pending',
    transaction_id VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_payment_status (payment_status),
    INDEX idx_donor_email (donor_email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Gallery Table
CREATE TABLE IF NOT EXISTS gallery (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    image VARCHAR(255) NOT NULL,
    category VARCHAR(50) DEFAULT 'general',
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_category (category),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Testimonials Table
CREATE TABLE IF NOT EXISTS testimonials (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255),
    rating INT DEFAULT 5,
    message TEXT NOT NULL,
    status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_status (status),
    INDEX idx_rating (rating)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert default admins (password: password)
-- Password hash for 'password': $2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi
INSERT INTO admins (username, email, password, role, status) VALUES 
('admin', 'admin@pujaservices.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'superadmin', 'active'),
('content', 'content@pujaservices.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'content', 'active'),
('operations', 'ops@pujaservices.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'operations', 'active'),
('manager', 'manager@pujaservices.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'manager', 'active')
ON DUPLICATE KEY UPDATE username=username;

-- Insert sample pujas
INSERT INTO pujas (name, slug, description, significance, when_to_perform, advantages, price, category, status) VALUES
('Sri Sathyanarayana Vratham', 'sri-sathyanarayana-vratham', 
'Lord Satyanarayana is the "highest being who is an embodiment of truth". Satyanarayana puja is performed to Lord Vishnu which bestows us with good health and wealth.',
'Bestows success in business and academic lives. Eradicates all the evil and the negative energies. Marks the auspicious beginnings.',
'Ekadashi, Pournami and Saturdays are considered to be the auspicious days to perform this puja.',
'Protects from evil and negative forces. Removes all the sins. Grants success in all the aspects of life.',
500.00, 'wealth', 'active'),

('Sri Varalaxmi Vratham', 'sri-varalaxmi-vratham',
'Every year Varalakshmi Vratham is observed in the Sravana month. It is celebrated on Friday preceding the full moon day.',
'To acquire wealth and prosperity. Varalakshmi is a goddess who gives all the boons and wishes.',
'Vara Lakshmi Vratham usually performed during Shravana Fridays.',
'Varalakshmi pooja will help one attain High Financial Status in life. Performing this Pooja helps in getting rid of all the obstacles and problems.',
450.00, 'wealth', 'active'),

('Sri Kedareshwara Swamy Vratham', 'sri-kedareshwara-swamy-vratham',
'The Kedareswara Vratha Puja implicates the importance of women being equal to men. This was performed by Parvathi Devi to become a part of Lord Shiva.',
'This Puja is performed to get all the wishes fulfilled. This is performed during Diwali on Amavasya.',
'This Puja is performed during the Amavasya of Diwali season.',
'By performing this Puja, we please Lord Shiva. All the desires and wishes are granted. Peace, Health and Prosperity are bestowed.',
600.00, 'general', 'active'),

('Navagraha Shanti Puja', 'navagraha-shanti-puja',
'Navagraha Puja is performed to reduce the negative effects and improve the positive energies of the nine planets.',
'This puja brings harmony and balance to life by appeasing the nine celestial bodies that influence our destiny.',
'Performed when experiencing planetary doshas or during inauspicious planetary periods.',
'Removes planetary doshas, brings peace and prosperity, improves health, career and relationships.',
800.00, 'dosha', 'active'),

('Kalyana Puja for Marriage', 'kalyana-puja-marriage',
'Special puja performed for early marriage and to remove obstacles in getting married.',
'Invokes blessings for finding the right life partner and ensuring a harmonious married life.',
'Performed during auspicious muhurtas, especially on Fridays and during Sukla Paksha.',
'Removes marriage delays, helps find suitable partner, ensures happy married life.',
350.00, 'marriage', 'active')
ON DUPLICATE KEY UPDATE name=name;

-- Insert sample temples
INSERT INTO temples (name, location, city, state, description, status) VALUES
('Sri Venkateswara Temple', 'Tirumala', 'Tirupati', 'Andhra Pradesh', 'One of the most famous temples dedicated to Lord Vishnu', 'active'),
('Meenakshi Temple', 'Madurai', 'Madurai', 'Tamil Nadu', 'Historic temple dedicated to Goddess Meenakshi', 'active'),
('Golden Temple', 'Amritsar', 'Amritsar', 'Punjab', 'Most sacred gurdwara of Sikhism', 'active'),
('Kashi Vishwanath Temple', 'Varanasi', 'Varanasi', 'Uttar Pradesh', 'One of the twelve Jyotirlingas dedicated to Lord Shiva', 'active')
ON DUPLICATE KEY UPDATE name=name;

-- Insert sample priests
INSERT INTO priests (name, email, phone, experience, specialization, location, status) VALUES
('Sri Ravi Shankar', 'ravi@pujaservices.com', '9876543210', 15, 'Vratham Pujas, Archana', 'Hyderabad', 'active'),
('Sri Krishna Murthy', 'krishna@pujaservices.com', '9876543211', 20, 'Rudrabhishekam, Shiva Pujas', 'Bangalore', 'active'),
('Sri Venkateswara Rao', 'venkat@pujaservices.com', '9876543212', 18, 'Satyanarayana Vratham, Vishnu Pujas', 'Chennai', 'active'),
('Sri Balaji Sharma', 'balaji@pujaservices.com', '9876543213', 12, 'Navagraha Puja, Graha Shanti', 'Mumbai', 'active')
ON DUPLICATE KEY UPDATE name=name;
