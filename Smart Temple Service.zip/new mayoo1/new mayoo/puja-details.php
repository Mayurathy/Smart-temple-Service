<?php
require_once 'config/config.php';

$conn = getDBConnection();
$slug = isset($_GET['slug']) ? sanitize($_GET['slug']) : '';

if (empty($slug)) {
    redirect('/pujas.php');
}

$puja_query = "SELECT * FROM pujas WHERE slug = ? AND status = 'active'";
$stmt = $conn->prepare($puja_query);
$stmt->bind_param("s", $slug);
$stmt->execute();
$puja_result = $stmt->get_result();

if ($puja_result->num_rows == 0) {
    redirect('/pujas.php');
}

$puja = $puja_result->fetch_assoc();
$page_title = $puja['name'] . ' - Puja Services';
include 'includes/header.php';
?>

<section class="services-section">
    <div class="container">
        <div style="max-width: 900px; margin: 0 auto;">
            <div class="puja-card">
                <div style="background: linear-gradient(135deg, #d97706 0%, #f59e0b 100%); height: 300px; display: flex; align-items: center; justify-content: center; color: white; font-size: 72px;">
                    <i class="fas fa-om"></i>
                </div>
                <div class="puja-card-content">
                    <h1 style="font-size: 32px; margin-bottom: 20px;"><?php echo htmlspecialchars($puja['name']); ?></h1>
                    <div class="price" style="font-size: 28px; margin-bottom: 20px;">₹<?php echo number_format($puja['price'], 2); ?></div>
                    
                    <div style="margin: 30px 0;">
                        <h3 style="color: var(--primary-color); margin-bottom: 15px;">Description</h3>
                        <p style="line-height: 1.8;"><?php echo nl2br(htmlspecialchars($puja['description'])); ?></p>
                    </div>
                    
                    <?php if (!empty($puja['significance'])): ?>
                    <div style="margin: 30px 0;">
                        <h3 style="color: var(--primary-color); margin-bottom: 15px;">Significance</h3>
                        <p style="line-height: 1.8;"><?php echo nl2br(htmlspecialchars($puja['significance'])); ?></p>
                    </div>
                    <?php endif; ?>
                    
                    <?php if (!empty($puja['when_to_perform'])): ?>
                    <div style="margin: 30px 0;">
                        <h3 style="color: var(--primary-color); margin-bottom: 15px;">When to Perform this Puja</h3>
                        <p style="line-height: 1.8;"><?php echo nl2br(htmlspecialchars($puja['when_to_perform'])); ?></p>
                    </div>
                    <?php endif; ?>
                    
                    <?php if (!empty($puja['advantages'])): ?>
                    <div style="margin: 30px 0;">
                        <h3 style="color: var(--primary-color); margin-bottom: 15px;">Advantages of this Puja</h3>
                        <p style="line-height: 1.8;"><?php echo nl2br(htmlspecialchars($puja['advantages'])); ?></p>
                    </div>
                    <?php endif; ?>
                    
                    <div style="margin-top: 40px; text-align: center;">
                        <a href="<?php echo SITE_URL; ?>/book-puja.php?puja_id=<?php echo $puja['id']; ?>" class="btn btn-primary" style="font-size: 18px; padding: 15px 40px;">Book Now</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php
$stmt->close();
$conn->close();
include 'includes/footer.php';
?>

