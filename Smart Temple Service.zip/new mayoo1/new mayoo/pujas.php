<?php
require_once 'config/config.php';
$page_title = 'All Pujas - Puja Services';
include 'includes/header.php';

$conn = getDBConnection();
$pujas_query = "SELECT * FROM pujas WHERE status = 'active' ORDER BY name ASC";
$pujas_result = $conn->query($pujas_query);
?>
<link rel="stylesheet" href="<?php echo SITE_URL; ?>/assets/css/pujas-premium.css?v=<?php echo time(); ?>">

<!-- Hero Section -->
<section class="pujas-hero">
    <div class="container">
        <h1 class="animated zoom-in">Sacred Rituals for Every Occasion</h1>
        <p class="animated fade-in-up delay-200">Explore our extensive collection of Vedic pujas, homams, and ceremonies
            designed to bring peace, prosperity, and divine blessings into your life.</p>
    </div>
</section>

<!-- Trust Strip -->
<div class="trust-strip">
    <div class="container">
        <div class="trust-grid">
            <div class="trust-item animated fade-in-up delay-100">
                <div class="trust-icon">
                    <i class="fas fa-om"></i>
                </div>
                <div class="trust-text">
                    <h4>Vedic Rituals</h4>
                    <p>Authentic & Traditional</p>
                </div>
            </div>
            <div class="trust-item animated fade-in-up delay-200">
                <div class="trust-icon">
                    <i class="fas fa-user-tie"></i>
                </div>
                <div class="trust-text">
                    <h4>Expert Pandits</h4>
                    <p>Certified & Experienced</p>
                </div>
            </div>
            <div class="trust-item animated fade-in-up delay-300">
                <div class="trust-icon">
                    <i class="fas fa-globe"></i>
                </div>
                <div class="trust-text">
                    <h4>Global Access</h4>
                    <p>Online & Offline Services</p>
                </div>
            </div>
            <div class="trust-item animated fade-in-up delay-400">
                <div class="trust-icon">
                    <i class="fas fa-heart"></i>
                </div>
                <div class="trust-text">
                    <h4>100% Satisfaction</h4>
                    <p>Devotee Focused</p>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Upcoming Auspicious Dates -->
<section class="upcoming-dates-section animated fade-in-up delay-100">
    <div class="container">
        <div class="section-header text-center">
            <span class="section-label">UPCOMING</span>
            <h2>Auspicious Dates</h2>
        </div>
        <div class="dates-grid">
            <div class="date-card animated zoom-in delay-100">
                <div class="date-box">
                    <div class="date-day">12</div>
                    <div class="date-month">NOV</div>
                </div>
                <div class="date-info">
                    <h4>Ekadashi</h4>
                    <p>Ideal for Vishnu Puja</p>
                </div>
            </div>
            <div class="date-card animated zoom-in delay-200">
                <div class="date-box">
                    <div class="date-day">15</div>
                    <div class="date-month">NOV</div>
                </div>
                <div class="date-info">
                    <h4>Pradosham</h4>
                    <p>Shiva Abhishekam</p>
                </div>
            </div>
            <div class="date-card animated zoom-in delay-300">
                <div class="date-box">
                    <div class="date-day">27</div>
                    <div class="date-month">NOV</div>
                </div>
                <div class="date-info">
                    <h4>Purnima</h4>
                    <p>Satyanarayan Puja</p>
                </div>
            </div>
            <div class="date-card animated zoom-in delay-400">
                <div class="date-box">
                    <div class="date-day">02</div>
                    <div class="date-month">DEC</div>
                </div>
                <div class="date-info">
                    <h4>Sankashti</h4>
                    <p>Ganpati Homa</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Search & Filter Section -->
<section class="search-section animated fade-in-up delay-200">
    <div class="container">
        <div class="search-box">
            <div class="search-input-wrapper">
                <i class="fas fa-search"></i>
                <input type="text" id="pujaSearch" class="search-input"
                    placeholder="Search for a puja (e.g., Ganpati, Satyanarayan)...">
            </div>

            <div class="category-filters">
                <button class="cat-btn active" onclick="filterPujas('all', this)"><i class="fas fa-th-large"></i>
                    All</button>
                <button class="cat-btn" onclick="filterPujas('wealth', this)"><i class="fas fa-coins"></i>
                    Wealth</button>
                <button class="cat-btn" onclick="filterPujas('health', this)"><i class="fas fa-heartbeat"></i>
                    Health</button>
                <button class="cat-btn" onclick="filterPujas('marriage', this)"><i class="fas fa-ring"></i>
                    Marriage</button>
                <button class="cat-btn" onclick="filterPujas('dosha', this)"><i class="fas fa-exclamation-triangle"></i>
                    Dosha</button>
            </div>
        </div>
    </div>
</section>

<!-- Pujas Grid -->
<section class="puja-list-section">
    <div class="container">
        <div class="puja-grid" id="pujaGrid">
            <?php if ($pujas_result && $pujas_result->num_rows > 0): ?>
                    <?php
                    $count = 0;
                    while ($puja = $pujas_result->fetch_assoc()):
                        $count++;
                        $delay = ($count % 6) * 100; // Stagger effect
                        ?>
                            <div class="puja-card animated zoom-in delay-<?php echo $delay; ?>"
                                data-category="<?php echo strtolower($puja['category']); ?>"
                                data-name="<?php echo strtolower($puja['name']); ?>">
                                <div class="puja-image-wrapper">
                                    <img src="assets/images/pujas/<?php echo $puja['image']; ?>" alt="<?php echo $puja['name']; ?>"
                                        onerror="this.src='https://via.placeholder.com/400x300?text=Puja'">
                                    <span class="puja-tag"><?php echo $puja['category']; ?></span>
                                </div>
                                <div class="puja-content">
                                    <h3><?php echo $puja['name']; ?></h3>
                                    <p class="puja-desc"><?php echo $puja['description']; ?></p>
                                    <div class="puja-meta">
                                        <span class="puja-price">₹<?php echo number_format($puja['price']); ?></span>
                                        <a href="book-puja.php?id=<?php echo $puja['id']; ?>" class="btn-book">Book Now</a>
                                    </div>
                                </div>
                            </div>
                    <?php endwhile; ?>
            <?php else: ?>
                    <p class="text-center">No pujas available at the moment.</p>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- How It Works -->
<section class="how-it-works-section">
    <div class="container">
        <div class="text-center">
            <span class="section-label animated fade-in-up">Process</span>
            <h2 class="section-heading animated fade-in-up delay-100">How It Works</h2>
        </div>
        <div class="steps-grid">
            <div class="step-card animated fade-in-left delay-100">
                <div class="step-number">1</div>
                <div class="step-icon">
                    <i class="fas fa-search"></i>
                </div>
                <h3>Select Service</h3>
                <p>Choose from our wide range of pujas and spiritual services.</p>
            </div>
            <div class="step-card animated fade-in-left delay-200">
                <div class="step-number">2</div>
                <div class="step-icon">
                    <i class="fas fa-calendar-check"></i>
                </div>
                <h3>Book & Pay</h3>
                <p>Provide details and make a secure online payment.</p>
            </div>
            <div class="step-card animated fade-in-left delay-300">
                <div class="step-number">3</div>
                <div class="step-icon">
                    <i class="fas fa-praying-hands"></i>
                </div>
                <h3>We Perform</h3>
                <p>Our pandits perform the puja with full Vedic rituals.</p>
            </div>
            <div class="step-card animated fade-in-left delay-400">
                <div class="step-number">4</div>
                <div class="step-icon">
                    <i class="fas fa-gift"></i>
                </div>
                <h3>Receive Prasad</h3>
                <p>Get the divine blessings (Prasad) delivered to your doorstep.</p>
            </div>
        </div>
    </div>
</section>

<!-- Why Perform Puja -->
<section class="why-puja-section">
    <div class="container">
        <div class="section-header text-center">
            <span class="section-label">BENEFITS</span>
            <h2 class="section-heading animated fade-in-up">Why Perform Puja?</h2>
        </div>
        <div class="why-grid">
            <div class="why-card animated fade-in-left delay-100">
                <div class="why-icon">
                    <i class="fas fa-spa"></i>
                </div>
                <h4>Inner Peace</h4>
                <p>Pujas create a positive vibration that calms the mind and reduces stress.</p>
            </div>
            <div class="why-card animated fade-in-left delay-200">
                <div class="why-icon">
                    <i class="fas fa-balance-scale"></i>
                </div>
                <h4>Karmic Balance</h4>
                <p>Vedic rituals help in reducing the effects of past karma and doshas.</p>
            </div>
            <div class="why-card animated fade-in-left delay-300">
                <div class="why-icon">
                    <i class="fas fa-users"></i>
                </div>
                <h4>Family Harmony</h4>
                <p>Collective prayers bring unity, understanding, and prosperity to the family.</p>
            </div>
        </div>
    </div>
</section>

<!-- FAQ Section -->
<section class="faq-section">
    <div class="container">
        <div class="section-header text-center">
            <span class="section-label" style="color: #dc2626; font-weight: 700; letter-spacing: 2px;">FAQ</span>
            <h2 class="section-heading" style="font-size: 42px; font-weight: 900; margin-top: 10px;">Common Questions
            </h2>
        </div>
        <div class="faq-grid">
            <div class="faq-item animated fade-in-up delay-100">
                <h3><i class="fas fa-question-circle"></i> How do Online Pujas work?</h3>
                <p>Our priests perform the puja at the temple/venue while you participate via live video call. Prasad is
                    shipped to your address.</p>
            </div>
            <div class="faq-item animated fade-in-up delay-200">
                <h3><i class="fas fa-user-check"></i> Are the priests verified?</h3>
                <p>Yes, all our priests are certified Vedic scholars with years of experience in performing rituals.</p>
            </div>
            <div class="faq-item animated fade-in-up delay-300">
                <h3><i class="fas fa-calendar-alt"></i> Can I choose the date and time?</h3>
                <p>Absolutely! You can select your preferred date and time during the booking process.</p>
            </div>
            <div class="faq-item animated fade-in-up delay-400">
                <h3><i class="fas fa-credit-card"></i> Is payment secure?</h3>
                <p>We use industry-standard encryption and secure payment gateways to ensure your transaction is safe.
                </p>
            </div>
        </div>
    </div>
</section>

<!-- Search & Filter Logic -->
<script>
    // Search Function
    document.getElementById('pujaSearch').addEventListener('keyup', function () {
        let filter = this.value.toLowerCase();
        filterItems(filter, getCurrentCategory());
    });

    // Category Filter Function
    function filterPujas(category, btn) {
        // Update active button
        if (btn) {
            document.querySelectorAll('.cat-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
        }

        let searchTerm = document.getElementById('pujaSearch').value.toLowerCase();
        filterItems(searchTerm, category);
    }

    // Helper to get current active category
    function getCurrentCategory() {
        let activeBtn = document.querySelector('.cat-btn.active');
        let text = activeBtn.innerText.trim().toLowerCase();
        if (text.includes('all')) return 'all';
        if (text.includes('wealth')) return 'wealth';
        if (text.includes('health')) return 'health';
        if (text.includes('marriage')) return 'marriage';
        if (text.includes('dosha')) return 'dosha';
        return 'all';
    }

    // Main Filter Logic
    function filterItems(searchTerm, category) {
        let cards = document.querySelectorAll('.puja-card');

        cards.forEach(card => {
            let name = card.getAttribute('data-name');
            let cat = card.getAttribute('data-category');

            let matchesSearch = name.includes(searchTerm);
            let matchesCategory = (category === 'all' || cat === category);

            if (matchesSearch && matchesCategory) {
                card.style.display = 'flex';
                // Reset animation to replay it
                card.style.animation = 'none';
                card.offsetHeight; /* trigger reflow */
                card.style.animation = 'fadeInUp 0.5s ease forwards';
            } else {
                card.style.display = 'none';
            }
        });
    }
</script>

<?php
include 'includes/footer.php';
?>