<?php
require_once 'config/config.php';
$page_title = 'Shopping Cart - Puja Services';
include 'includes/header.php';

// Initialize cart session
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

$conn = getDBConnection();

// Handle remove from cart
if (isset($_GET['remove'])) {
    $remove_id = intval($_GET['remove']);
    unset($_SESSION['cart'][$remove_id]);
    header('Location: cart.php');
    exit;
}

// Get cart items details
$cart_items = [];
$total = 0;

if (!empty($_SESSION['cart'])) {
    $ids = array_keys($_SESSION['cart']);
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $query = "SELECT * FROM pujas WHERE id IN ($placeholders)";
    $stmt = $conn->prepare($query);
    $types = str_repeat('i', count($ids));
    $stmt->bind_param($types, ...$ids);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($puja = $result->fetch_assoc()) {
        $cart_items[] = $puja;
        $total += $puja['price'];
    }
    $stmt->close();
}
?>

<link rel="stylesheet" href="assets/css/cart-premium.css">

<section class="cart-hero">
    <div class="container">
        <h1>Shopping Cart</h1>
        <p>Review your selected pujas and proceed to booking</p>
    </div>
</section>

<section class="cart-section">
    <div class="container">
        <?php if (empty($cart_items)): ?>
            <div class="empty-cart">
                <i class="fas fa-shopping-cart"></i>
                <h2>Your cart is empty</h2>
                <p>Add pujas to your cart to start booking</p>
                <a href="pujas.php" class="btn-shop">Browse Pujas</a>
            </div>
        <?php else: ?>
            <div class="cart-grid">
                <div class="cart-items">
                    <?php foreach ($cart_items as $item): ?>
                        <div class="cart-item-card">
                            <div class="item-info">
                                <h3><?php echo htmlspecialchars($item['name']); ?></h3>
                                <p><?php echo htmlspecialchars(substr($item['description'], 0, 100)) . '...'; ?></p>
                            </div>
                            <div class="item-price">
                                <span class="price">₹<?php echo number_format($item['price'], 2); ?></span>
                                <a href="?remove=<?php echo $item['id']; ?>" class="btn-remove">Remove</a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <div class="cart-summary">
                    <h3>Order Summary</h3>
                    <div class="summary-row">
                        <span>Subtotal</span>
                        <span>₹<?php echo number_format($total, 2); ?></span>
                    </div>
                    <div class="summary-row total">
                        <span>Total</span>
                        <span>₹<?php echo number_format($total, 2); ?></span>
                    </div>
                    <a href="book-puja.php" class="btn-checkout">Proceed to Booking</a>
                </div>
            </div>
        <?php endif; ?>
    </div>
</section>

<?php
$conn->close();
include 'includes/footer.php';
?>