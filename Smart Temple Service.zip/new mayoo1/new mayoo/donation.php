<?php
require_once 'config/config.php';

$conn = getDBConnection();
$page_title = 'Donate - Puja Services';

// Ensure donations table exists (lightweight, no card storage)
$conn->query("CREATE TABLE IF NOT EXISTS donations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    donor_name VARCHAR(255) NOT NULL,
    donor_email VARCHAR(255) NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    purpose VARCHAR(255) DEFAULT NULL,
    card_last4 VARCHAR(4) DEFAULT NULL,
    status ENUM('received','failed') DEFAULT 'received',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$message = '';
$message_type = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $donor_name = sanitize($_POST['donor_name'] ?? '');
    $donor_email = sanitize($_POST['donor_email'] ?? '');
    $amount = (float) ($_POST['amount'] ?? 0);
    $purpose = sanitize($_POST['purpose'] ?? 'General Donation');
    $card_number = preg_replace('/\D+/', '', $_POST['card_number'] ?? '');
    $card_last4 = substr($card_number, -4);

    if ($donor_name && $donor_email && $amount > 0) {
        // This is a demo flow – no payment processing. We only record a receipt.
        $stmt = $conn->prepare("INSERT INTO donations (donor_name, donor_email, amount, purpose, card_last4) VALUES (?,?,?,?,?)");
        $stmt->bind_param('ssdss', $donor_name, $donor_email, $amount, $purpose, $card_last4);
        if ($stmt->execute()) {
            $message = 'Thank you for your donation of ₹' . number_format($amount, 2) . '. A receipt has been recorded.';
            $message_type = 'success';
        } else {
            $message = 'Unable to record donation at the moment.';
            $message_type = 'error';
        }
        $stmt->close();
    } else {
        $message = 'Please complete all required fields and enter a valid amount.';
        $message_type = 'error';
    }
}

include 'includes/header.php';
?>

<link rel="stylesheet" href="assets/css/donation-premium.css">

<!-- Hero Section -->
<section class="donation-hero">
    <div class="container">
        <h1>Support Our Mission</h1>
        <p>Your contribution helps us preserve and promote Sanatana Dharma through our services, content, and temple
            connectivity initiatives.</p>
    </div>
</section>

<section class="donation-section">
    <div class="donation-container">

        <?php if ($message): ?>
            <div class="alert <?php echo $message_type === 'success' ? 'alert-success' : 'alert-error'; ?>">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <div class="donation-form-card">
            <div class="form-header">
                <h3>Make a Donation</h3>
                <p>Secure Payment • Tax Deductible</p>
            </div>

            <form method="POST" action="" id="donationForm">

                <!-- Amount Selection -->
                <div class="form-group full-width">
                    <label>Select Amount</label>
                    <div class="amount-options">
                        <div class="amount-option" onclick="selectAmount(101)">₹101</div>
                        <div class="amount-option" onclick="selectAmount(501)">₹501</div>
                        <div class="amount-option" onclick="selectAmount(1001)">₹1001</div>
                        <div class="amount-option" onclick="selectAmount(5001)">₹5001</div>
                    </div>
                    <input type="number" name="amount" id="customAmount" min="1" step="1"
                        placeholder="Enter custom amount" required>
                </div>

                <div class="form-grid">
                    <div class="form-group">
                        <label>Your Name *</label>
                        <input type="text" name="donor_name" required placeholder="Full Name">
                    </div>
                    <div class="form-group">
                        <label>Email Address *</label>
                        <input type="email" name="donor_email" required placeholder="email@example.com">
                    </div>
                </div>

                <div class="form-group full-width">
                    <label>Purpose of Donation</label>
                    <select name="purpose">
                        <option value="General Donation">General Donation</option>
                        <option value="Temple Maintenance">Temple Maintenance</option>
                        <option value="Annadanam">Annadanam (Food Donation)</option>
                        <option value="Education Fund">Vedic Education Fund</option>
                    </select>
                </div>

                <!-- Payment Section -->
                <div class="payment-card-box">
                    <div class="card-header">
                        <span>Credit / Debit Card</span>
                        <div class="card-icons">
                            <img src="https://upload.wikimedia.org/wikipedia/commons/0/04/Visa.svg" alt="Visa">
                            <img src="https://upload.wikimedia.org/wikipedia/commons/2/2a/Mastercard-logo.svg"
                                alt="Mastercard">
                        </div>
                    </div>

                    <div class="form-group card-input-group">
                        <label>Card Number</label>
                        <input type="text" name="card_number" inputmode="numeric" placeholder="0000 0000 0000 0000"
                            maxlength="19" id="cardNumber">
                    </div>

                    <div class="form-grid" style="gap: 15px;">
                        <div class="form-group card-input-group">
                            <label>Expiry Date</label>
                            <input type="text" name="card_exp" inputmode="numeric" placeholder="MM/YY" maxlength="5"
                                id="cardExp">
                        </div>
                        <div class="form-group card-input-group">
                            <label>CVV</label>
                            <input type="password" name="card_cvv" inputmode="numeric" placeholder="123" maxlength="4">
                        </div>
                    </div>
                    <p style="font-size: 11px; opacity: 0.6; margin-top: 10px; text-align: center;">
                        <i class="fas fa-lock"></i> This is a secure 256-bit SSL encrypted payment.
                    </p>
                </div>

                <button type="submit" class="btn-donate">
                    <span>Donate Now</span>
                    <i class="fas fa-heart"></i>
                </button>

                <p style="text-align: center; margin-top: 15px; font-size: 12px; color: var(--text-light);">
                    By donating, you agree to our Terms of Service and Privacy Policy.
                </p>
            </form>
        </div>
    </div>
</section>

<script>
    function selectAmount(amount) {
        document.getElementById('customAmount').value = amount;

        // Update active state
        document.querySelectorAll('.amount-option').forEach(opt => opt.classList.remove('active'));
        event.target.classList.add('active');
    }

    // Simple formatting for card inputs (visual only)
    document.getElementById('cardNumber').addEventListener('input', function (e) {
        e.target.value = e.target.value.replace(/[^\d]/g, '').replace(/(.{4})/g, '$1 ').trim();
    });

    document.getElementById('cardExp').addEventListener('input', function (e) {
        var input = e.target.value.replace(/\D/g, '').substring(0, 4);
        var month = input.substring(0, 2);
        var year = input.substring(2, 4);
        if (input.length > 2) {
            e.target.value = month + '/' + year;
        } else {
            e.target.value = input;
        }
    });
</script>

<?php include 'includes/footer.php'; ?>