<?php
/**
 * Main Configuration File
 * Enhanced with security features and helper functions
 */

// Start session with secure settings
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_only_cookies', 1);
    ini_set('session.cookie_secure', 0); // Set to 1 if using HTTPS
    ini_set('session.cookie_samesite', 'Lax');
    session_start();
}

// Site Configuration
define('SITE_NAME', 'Puja Services');
define('SITE_URL', 'http://localhost/new mayoo1/new mayoo');
define('ADMIN_EMAIL', 'admin@pujaservices.com');

// Paths
define('BASE_PATH', dirname(__DIR__));
define('INCLUDES_PATH', BASE_PATH . '/includes');
define('ADMIN_PATH', BASE_PATH . '/admin');
define('UPLOAD_PATH', BASE_PATH . '/assets/images');

// Security settings
define('CSRF_TOKEN_NAME', 'csrf_token');
define('CSRF_TOKEN_TIME_NAME', 'csrf_token_time');
define('CSRF_TOKEN_EXPIRY', 3600); // 1 hour

// Include database connection
require_once BASE_PATH . '/config/database.php';

// ============ SECURITY FUNCTIONS ============

/**
 * Sanitize input data
 */
function sanitize($data)
{
    if (is_array($data)) {
        return array_map('sanitize', $data);
    }
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    return $data;
}

/**, * Sanitize for database (prevents SQL injection)
 */
function sanitizeDB($conn, $data)
{
    return $conn->real_escape_string(trim($data));
}

/**
 * Validate email
 */
function validateEmail($email)
{
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

/**
 * Validate phone number (Indian format)
 */
function validatePhone($phone)
{
    $phone = preg_replace('/[^0-9]/', '', $phone);
    return strlen($phone) >= 10 && strlen($phone) <= 15;
}

/**
 * Generate CSRF token
 */
function generateCSRFToken()
{
    if (
        empty($_SESSION[CSRF_TOKEN_NAME]) ||
        empty($_SESSION[CSRF_TOKEN_TIME_NAME]) ||
        (time() - $_SESSION[CSRF_TOKEN_TIME_NAME]) > CSRF_TOKEN_EXPIRY
    ) {
        $_SESSION[CSRF_TOKEN_NAME] = bin2hex(random_bytes(32));
        $_SESSION[CSRF_TOKEN_TIME_NAME] = time();
    }
    return $_SESSION[CSRF_TOKEN_NAME];
}

/**
 * Get CSRF token HTML input
 */
function csrfTokenInput()
{
    return '<input type="hidden" name="' . CSRF_TOKEN_NAME . '" value="' . generateCSRFToken() . '">';
}

/**
 * Verify CSRF token
 */
function verifyCSRFToken($token = null)
{
    if ($token === null) {
        $token = $_POST[CSRF_TOKEN_NAME] ?? '';
    }

    if (empty($_SESSION[CSRF_TOKEN_NAME]) || empty($token)) {
        return false;
    }

    if ((time() - ($_SESSION[CSRF_TOKEN_TIME_NAME] ?? 0)) > CSRF_TOKEN_EXPIRY) {
        return false;
    }

    return hash_equals($_SESSION[CSRF_TOKEN_NAME], $token);
}

// ============ NAVIGATION & REDIRECT ============

/**
 * Redirect to URL
 */
function redirect($url)
{
    if (strpos($url, 'http') === 0) {
        header("Location: " . $url);
    } elseif (strpos($url, '/') === 0) {
        header("Location: " . SITE_URL . $url);
    } else {
        header("Location: " . SITE_URL . "/" . ltrim($url, '/'));
    }
    exit();
}

/**
 * Redirect with message
 */
function redirectWithMessage($url, $message, $type = 'success')
{
    $_SESSION['flash_message'] = $message;
    $_SESSION['flash_type'] = $type;
    redirect($url);
}

/**
 * Get and clear flash message
 */
function getFlashMessage()
{
    $message = $_SESSION['flash_message'] ?? null;
    $type = $_SESSION['flash_type'] ?? 'info';

    unset($_SESSION['flash_message']);
    unset($_SESSION['flash_type']);

    return $message ? ['message' => $message, 'type' => $type] : null;
}

// ============ ADMIN AUTHENTICATION ============

/**
 * Check if admin is logged in
 */
function isLoggedIn()
{
    return isset($_SESSION['admin_id']) && !empty($_SESSION['admin_id']);
}

/**
 * Require admin login
 */
function requireLogin()
{
    if (!isLoggedIn()) {
        redirectWithMessage('/admin/login.php', 'Please login to continue', 'error');
    }
}

/**
 * Get admin role
 */
function getAdminRole()
{
    return $_SESSION['admin_role'] ?? 'superadmin';
}

/**
 * Check if admin has specific role(s)
 */
function adminHasRole($roles)
{
    $role = getAdminRole();
    if (is_string($roles)) {
        $roles = [$roles];
    }
    return in_array($role, $roles, true);
}

/**
 * Require specific admin role(s)
 */
function requireAdminRole($roles)
{
    if (!isLoggedIn()) {
        redirectWithMessage('/admin/login.php', 'Please login to continue', 'error');
    }

    if (!adminHasRole($roles)) {
        redirectWithMessage('/admin/index.php', 'Access denied. Insufficient permissions.', 'error');
    }
}

/**
 * Get logged in admin info
 */
function getAdminInfo()
{
    if (!isLoggedIn()) {
        return null;
    }

    return [
        'id' => $_SESSION['admin_id'] ?? null,
        'username' => $_SESSION['admin_username'] ?? null,
        'role' => $_SESSION['admin_role'] ?? 'superadmin'
    ];
}

// ============ USER AUTHENTICATION ============

/**
 * Check if user is logged in
 */
function isUserLoggedIn()
{
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

/**
 * Get logged in user name
 */
function getLoggedInUserName()
{
    return $_SESSION['user_name'] ?? '';
}

/**
 * Get logged in user ID
 */
function getLoggedInUserId()
{
    return $_SESSION['user_id'] ?? null;
}

/**
 * Require user login
 */
function requireUserLogin()
{
    if (!isUserLoggedIn()) {
        redirectWithMessage('/signin.php', 'Please sign in to continue', 'error');
    }
}

// ============ UTILITY FUNCTIONS ============

/**
 * Generate unique booking ID
 */
function generateBookingId()
{
    return 'PUJA' . date('Ymd') . strtoupper(substr(uniqid(), -4));
}

/**
 * Format currency
 */
function formatCurrency($amount)
{
    return '₹' . number_format($amount, 2);
}

/**
 * Format date
 */
function formatDate($date, $format = 'd M Y')
{
    return date($format, strtotime($date));
}

/**
 * Format datetime
 */
function formatDateTime($datetime, $format = 'd M Y h:i A')
{
    return date($format, strtotime($datetime));
}

/**
 * Time ago format
 */
function timeAgo($datetime)
{
    $timestamp = strtotime($datetime);
    $diff = time() - $timestamp;

    if ($diff < 60)
        return 'Just now';
    if ($diff < 3600)
        return floor($diff / 60) . ' minutes ago';
    if ($diff < 86400)
        return floor($diff / 3600) . ' hours ago';
    if ($diff < 604800)
        return floor($diff / 86400) . ' days ago';

    return date('d M Y', $timestamp);
}

/**
 * Truncate text
 */
function truncate($text, $length = 100, $suffix = '...')
{
    if (strlen($text) <= $length) {
        return $text;
    }
    return substr($text, 0, $length) . $suffix;
}

/**
 * Generate slug from text
 */
function generateSlug($text)
{
    $text = strtolower($text);
    $text = preg_replace('/[^a-z0-9-]/', '-', $text);
    $text = preg_replace('/-+/', '-', $text);
    return trim($text, '-');
}

/**
 * Get status badge HTML
 */
function getStatusBadge($status)
{
    $colors = [
        'pending' => '#fbbf24',
        'confirmed' => '#3b82f6',
        'completed' => '#10b981',
        'cancelled' => '#ef4444',
        'active' => '#10b981',
        'inactive' => '#6b7280',
        'new' => '#3b82f6',
        'read' => '#6b7280',
        'replied' => '#10b981'
    ];

    $color = $colors[$status] ?? '#6b7280';
    return '<span style="padding:4px 12px;background:' . $color . ';color:white;border-radius:12px;font-size:12px;font-weight:500;">' .
        ucfirst($status) . '</span>';
}

// ============ FILE UPLOAD HELPERS ============

/**
 * Validate and upload image
 */
function uploadImage($file, $uploadDir, $allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'], $maxSize = 5242880)
{
    // Check if file was uploaded
    if (!isset($file) || $file['error'] !== UPLOAD_ERR_OK) {
        return ['success' => false, 'error' => 'No file uploaded or upload error'];
    }

    // Check file size (default 5MB)
    if ($file['size'] > $maxSize) {
        return ['success' => false, 'error' => 'File size exceeds limit (5MB max)'];
    }

    // Check file type
    $fileType = $file['type'];
    if (!in_array($fileType, $allowedTypes)) {
        return ['success' => false, 'error' => 'Invalid file type. Only JPG, PNG, and WEBP allowed'];
    }

    // Create upload directory if not exists
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }

    // Generate unique filename
    $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = uniqid() . '_' . time() . '.' . $extension;
    $uploadPath = $uploadDir . '/' . $filename;

    // Move uploaded file
    if (move_uploaded_file($file['tmp_name'], $uploadPath)) {
        return ['success' => true, 'filename' => $filename, 'path' => $uploadPath];
    }

    return ['success' => false, 'error' => 'Failed to move uploaded file'];
}

/**
 * Delete file safely
 */
function deleteFile($filepath)
{
    if (file_exists($filepath) && is_file($filepath)) {
        return @unlink($filepath);
    }
    return false;
}
?>