<?php
/**
 * Database Configuration
 * Enhanced with error handling and connection management
 */

// Database credentials
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'puja_services');

// Error reporting for development (disable in production)
define('DB_DEBUG', true);

/**
 * Get database connection with error handling
 * Uses singleton pattern to reuse connection
 */
function getDBConnection()
{
    static $conn = null;

    if ($conn === null) {
        // Suppress warnings in production
        if (!DB_DEBUG) {
            error_reporting(0);
        }

        try {
            // Create connection
            $conn = @new mysqli(DB_HOST, DB_USER, DB_PASS);

            if ($conn->connect_error) {
                logError("MySQL Connection Error: " . $conn->connect_error);
                if (DB_DEBUG) {
                    die("<div style='padding:20px;background:#fee;border:1px solid #c00;color:#c00;'>
                        <h3>Database Connection Error</h3>
                        <p>Could not connect to MySQL server. Please check:</p>
                        <ul>
                            <li>XAMPP MySQL service is running</li>
                            <li>Database credentials in config/database.php are correct</li>
                            <li>Port 3306 is not blocked</li>
                        </ul>
                        <p><small>Error: " . htmlspecialchars($conn->connect_error) . "</small></p>
                    </div>");
                } else {
                    die("Database connection error. Please contact administrator.");
                }
            }

            // Create database if not exists
            $dbCreateQuery = "CREATE DATABASE IF NOT EXISTS `" . DB_NAME . "` 
                             CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci";
            $conn->query($dbCreateQuery);

            // Select database
            if (!$conn->select_db(DB_NAME)) {
                logError("Database selection error: " . $conn->error);
                if (DB_DEBUG) {
                    die("<div style='padding:20px;background:#fee;border:1px solid #c00;color:#c00;'>
                        <h3>Database Error</h3>
                        <p>Database '" . DB_NAME . "' does not exist or cannot be selected.</p>
                        <p>Please run: <a href='database-migration.php'>database-migration.php</a></p>
                    </div>");
                } else {
                    die("Database error. Please contact administrator.");
                }
            }

            // Set charset
            if (!$conn->set_charset("utf8mb4")) {
                logError("Charset error: " . $conn->error);
            }

            // Set timezone
            $conn->query("SET time_zone = '+05:30'"); // IST

        } catch (Exception $e) {
            logError("Database exception: " . $e->getMessage());
            if (DB_DEBUG) {
                die("<div style='padding:20px;background:#fee;border:1px solid #c00;color:#c00;'>
                    <h3>Database Exception</h3>
                    <p>" . htmlspecialchars($e->getMessage()) . "</p>
                </div>");
            } else {
                die("Database error. Please contact administrator.");
            }
        }
    }

    return $conn;
}

/**
 * Close database connection
 */
function closeDBConnection($conn)
{
    if ($conn && $conn instanceof mysqli && !$conn->connect_error) {
        $conn->close();
    }
}

/**
 * Log database errors
 */
function logError($message)
{
    $logFile = __DIR__ . '/../logs/db_errors.log';
    $logDir = dirname($logFile);

    if (!is_dir($logDir)) {
        @mkdir($logDir, 0755, true);
    }

    $timestamp = date('Y-m-d H:i:s');
    $logMessage = "[$timestamp] $message\n";
    @file_put_contents($logFile, $logMessage, FILE_APPEND);
}

/**
 * Execute prepared statement with error handling
 */
function executeQuery($conn, $query, $types = '', $params = [])
{
    $stmt = $conn->prepare($query);

    if (!$stmt) {
        logError("Prepare failed: " . $conn->error);
        return false;
    }

    if ($types && $params) {
        $stmt->bind_param($types, ...$params);
    }

    if (!$stmt->execute()) {
        logError("Execute failed: " . $stmt->error);
        $stmt->close();
        return false;
    }

    return $stmt;
}
?>