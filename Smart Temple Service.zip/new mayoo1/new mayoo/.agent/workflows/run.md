---
description: How to run the Puja Services website
---

# Running the Puja Services Website

This workflow explains how to run the PHP-based Puja Services website on XAMPP.

## Prerequisites

- XAMPP installed on your system
- Project files located at: `C:\xampp\htdocs\new mayoo1\new mayoo\`

## Steps to Run

### 1. Start XAMPP Services

Open the **XAMPP Control Panel** and start:
- **Apache** - Web server for PHP
- **MySQL** - Database server

Make sure both services show "Running" status with green indicators.

### 2. Verify Database Setup

- Open phpMyAdmin: http://localhost/phpmyadmin
- Check if database `puja_services` exists
- If not, import `database.sql` from the project root

### 3. Access the Website

**Main Website (Frontend):**
```
http://localhost/new%20mayoo1/new%20mayoo/
```

**Admin Panel:**
```
http://localhost/new%20mayoo1/new%20mayoo/admin/login.php
```

**Admin Login Credentials:**
- Username: `admin`
- Password: `admin123`

### 4. Available Pages

**Frontend Pages:**
- Homepage: `/index.php`
- Services: `/services.php`
- Pujas: `/pujas.php`
- Temples: `/temples.php`
- About: `/about.php`
- Contact: `/contact.php`
- Sign In: `/signin.php`
- Sign Up: `/signup.php`

**Admin Pages:**
- Dashboard: `/admin/index.php`
- Bookings: `/admin/bookings.php`
- Pujas Management: `/admin/pujas.php`
- Temples Management: `/admin/temples.php`
- Contacts: `/admin/contacts.php`

## Troubleshooting

**If pages don't load:**
- Ensure Apache is running in XAMPP
- Check the URL has correct path: `new%20mayoo1/new%20mayoo/`
- Clear browser cache

**Database connection errors:**
- Ensure MySQL is running in XAMPP
- Verify credentials in `config/database.php`
- Check database `puja_services` exists

**Admin login fails:**
- Default password: `admin123`
- Check database table `admins` has the admin user

## Development Mode

For development, you can edit files directly and refresh the browser to see changes.

**CSS Files:** `assets/css/`
**JavaScript Files:** `assets/js/`
**PHP Files:** Root directory and `admin/` folder
