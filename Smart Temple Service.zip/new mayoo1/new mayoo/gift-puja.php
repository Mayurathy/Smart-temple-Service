<?php
require_once 'config/config.php';
$page_title = 'Gift A Puja - Vedic Ashirvaad - Puja Services';
include 'includes/header.php';

$conn = getDBConnection();
$pujas_query = "SELECT * FROM pujas WHERE status = 'active'";
$pujas_result = $conn->query($pujas_query);
?>

<link rel="stylesheet" href="assets/css/gift-puja-premium.css">

<!-- Hero Section -->
<section class="gift-hero">
    <div class="container">
        <h1>Vedic Ashirvaad</h1>
        <p>Divine Blessings for a Prosperous Life</p>
    </div>
</section>

<section class="gift-section">
    <div class="container">

        <div class="gift-intro-card">
            <p>
                Mark your special occasions with the divine power of <span class="highlight">Vedic Ashirvaad</span>.
                Whether it's a birthday, wedding, anniversary, or any milestone, receive sacred blessings through
                authentic Vedic rituals performed by experienced priests.
                Invoke positive energy, prosperity, and spiritual well-being for you and your loved ones.
            </p>
        </div>

        <div class="premium-puja-grid">
            <?php if ($pujas_result && $pujas_result->num_rows > 0): ?>
                <?php while ($puja = $pujas_result->fetch_assoc()): ?>
                    <div class="premium-puja-card">
                        <div class="card-image-box">
                            <i class="fas fa-om"></i>
                        </div>
                        <div class="card-content">
                            <h3><?php echo htmlspecialchars($puja['name']); ?></h3>
                            <p><?php echo htmlspecialchars(substr($puja['description'], 0, 120)) . '...'; ?></p>

                            <div class="card-footer">
                                <div class="price-tag">₹<?php echo number_format($puja['price'], 0); ?></div>
                                <a href="<?php echo SITE_URL; ?>/book-puja.php?puja_id=<?php echo $puja['id']; ?>"
                                    class="btn-gift">
                                    Gift Now <i class="fas fa-arrow-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p class="text-center" style="grid-column: 1/-1; padding: 40px; color: var(--text-light);">No pujas
                    available at the moment.</p>
            <?php endif; ?>
        </div>
    </div>
</section>

<?php
$conn->close();
include 'includes/footer.php';
?>