<?php
require_once 'config/config.php';
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$conn = getDBConnection();
$message = '';
$message_type = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = sanitize($_POST['name']);
    $email = sanitize($_POST['email']);
    $phone = sanitize($_POST['phone']);
    $subject = sanitize($_POST['subject']);
    $msg = sanitize($_POST['message']);

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = "Please enter a valid email address.";
        $message_type = 'error';
    } else {
        $insert_query = "INSERT INTO contacts (name, email, phone, subject, message) VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($insert_query);
        $stmt->bind_param("sssss", $name, $email, $phone, $subject, $msg);

        if ($stmt->execute()) {
            $message = "Thank you for contacting us! We will get back to you soon.";
            $message_type = 'success';
        } else {
            $message = "Error: " . $conn->error;
            $message_type = 'error';
        }
        $stmt->close();
    }
}

$page_title = 'Contact Us - Puja Services';
include 'includes/header.php';
?>
<link rel="stylesheet" href="<?php echo SITE_URL; ?>/assets/css/contact-premium.css">

<!-- Hero Section -->
<section class="contact-hero">
    <div class="container">
        <h1>Get in Touch</h1>
        <p>Have questions about our services or need spiritual guidance? We are here to help you on your divine journey.</p>
    </div>
</section>

<section class="contact-page-section">
    <div class="container">
        <?php if ($message): ?>
            <div class="<?php echo $message_type == 'success' ? 'success-message' : 'error-message'; ?>"
                style="max-width: 600px; margin: 0 auto 30px;">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <div class="contact-grid">
            <!-- Contact Info -->
            <div class="contact-info-card animated fade-in">
                <h3 class="animated fade-in-down delay-100">Contact Information</h3>

                <div class="contact-info-item animated fade-in-left delay-200">
                    <div class="contact-icon-box">
                        <i class="fas fa-map-marker-alt"></i>
                    </div>
                    <div class="contact-details">
                        <h4>Location</h4>
                        <p>Telangana | Andhra Pradesh | Bengaluru | USA</p>
                    </div>
                </div>

                <div class="contact-info-item animated fade-in-left delay-300">
                    <div class="contact-icon-box">
                        <i class="fas fa-envelope"></i>
                    </div>
                    <div class="contact-details">
                        <h4>Email Us</h4>
                        <p><?php echo ADMIN_EMAIL; ?></p>
                    </div>
                </div>

                <div class="contact-info-item animated fade-in-left delay-400">
                    <div class="contact-icon-box">
                        <i class="fas fa-phone"></i>
                    </div>
                    <div class="contact-details">
                        <h4>Call Us</h4>
                        <p>+91-9876543210</p>
                    </div>
                </div>
            </div>

            <!-- Contact Form -->
            <div class="contact-form-card animated fade-in">
                <form method="POST" action="">
                    <div class="modern-form-group animated fade-in-up delay-200">
                        <label>Name *</label>
                        <input type="text" name="name" required placeholder="Enter your full name">
                    </div>

                    <div class="modern-form-group animated fade-in-up delay-300">
                        <label>Email *</label>
                        <input type="email" name="email" required placeholder="Enter your email address">
                    </div>

                    <div class="modern-form-group animated fade-in-up delay-400">
                        <label>Phone</label>
                        <input type="tel" name="phone" placeholder="Enter your phone number">
                    </div>

                    <div class="modern-form-group animated fade-in-up delay-500">
                        <label>Subject *</label>
                        <input type="text" name="subject" required placeholder="What is this regarding?">
                    </div>

                    <div class="modern-form-group animated fade-in-up delay-600">
                        <label>Message *</label>
                        <textarea name="message" required placeholder="Write your message here..."></textarea>
                    </div>

                    <button type="submit" class="btn-submit-modern pulse-animation delay-700 animated zoom-in">Send
                        Message Now</button>
                </form>
            </div>
        </div>
    </div>
</section>

<?php
$conn->close();
include 'includes/footer.php';
?>