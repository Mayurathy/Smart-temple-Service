# Puja Services Website - Clone

A complete PHP-based website clone of pujaservices.com with all features including admin panel.

## Features

### Frontend Pages
- **Homepage** - Hero sections, featured services, and puja listings
- **Services** - Online Puja Booking, Temple Puja Booking, Priest Services
- **Pujas** - List of all available pujas with details
- **Puja Details** - Individual puja pages with full information
- **Temples** - List of available temples
- **About Us** - About page
- **Gift A Puja** - Vedic Ashirvaad section
- **Contact Us** - Contact form
- **Booking System** - Complete booking functionality

### Admin Panel
- **Dashboard** - Statistics and recent bookings overview
- **Bookings Management** - View, update status of all bookings
- **Pujas Management** - Add, edit, delete pujas
- **Temples Management** - Add, edit, delete temples
- **Priests Management** - Add, edit, delete priests
- **Contacts Management** - View and manage contact messages
- **Subscribers Management** - Manage email subscribers

## Installation

### Prerequisites
- XAMPP (or any PHP server with MySQL)
- PHP 7.4 or higher
- MySQL 5.7 or higher

### Setup Steps

1. **Place files in XAMPP**
   - Copy all files to `C:\xampp\htdocs\new mayoo\`

2. **Create Database**
   - Open phpMyAdmin (http://localhost/phpmyadmin)
   - Import the `database.sql` file
   - Or run the SQL queries manually

3. **Configure Database**
   - Edit `config/database.php` if needed (default settings work for XAMPP):
     - DB_HOST: 'localhost'
     - DB_USER: 'root'
     - DB_PASS: '' (empty for XAMPP)
     - DB_NAME: 'puja_services'

4. **Configure Site URL**
   - Edit `config/config.php` and update the SITE_URL if needed:
     ```php
     define('SITE_URL', 'http://localhost/new mayoo');
     ```

5. **Access the Website**
   - Frontend: http://localhost/new mayoo/
   - Admin Panel: http://localhost/new mayoo/admin/login.php
   - Default Admin Login:
     - Username: `admin`
     - Password: `admin123`

## File Structure

```
new mayoo/
├── admin/
│   ├── includes/
│   │   ├── header.php
│   │   └── footer.php
│   ├── index.php (Dashboard)
│   ├── login.php
│   ├── logout.php
│   ├── bookings.php
│   ├── view-booking.php
│   ├── pujas.php
│   ├── temples.php
│   ├── priests.php
│   ├── contacts.php
│   ├── view-contact.php
│   └── subscribers.php
├── assets/
│   ├── css/
│   │   └── style.css
│   └── js/
│       └── main.js
├── config/
│   ├── config.php
│   └── database.php
├── includes/
│   ├── header.php
│   └── footer.php
├── index.php (Homepage)
├── about.php
├── services.php
├── pujas.php
├── puja-details.php
├── temples.php
├── gift-puja.php
├── book-puja.php
├── contact.php
├── subscribe.php
├── signin.php
├── signup.php
└── database.sql
```

## Database Tables

- **admins** - Admin users
- **pujas** - Puja listings
- **temples** - Temple listings
- **priests** - Priest information
- **bookings** - Customer bookings
- **contacts** - Contact form submissions
- **subscribers** - Email subscribers

## Usage

### Adding a New Puja
1. Login to admin panel
2. Go to "Pujas" section
3. Click "Add New Puja"
4. Fill in the details and submit

### Managing Bookings
1. Go to Admin Panel → Bookings
2. View booking details by clicking "View"
3. Update booking status using the dropdown

### Adding Temples/Priests
- Similar process as adding pujas
- Go to respective sections in admin panel

## Security Notes

- Change the default admin password after first login
- The default password hash is for "admin123"
- Consider changing the admin username
- Use prepared statements (already implemented) to prevent SQL injection
- Sanitize all inputs (already implemented)

## Customization

### Colors
Edit `assets/css/style.css` and modify CSS variables:
```css
:root {
    --primary-color: #d97706;
    --secondary-color: #f59e0b;
    --dark-color: #1f2937;
}
```

### Content
- Edit page content directly in PHP files
- Puja descriptions can be updated from admin panel or database

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## Notes

- All images are represented using Font Awesome icons
- Responsive design for mobile devices
- No framework used - pure PHP, HTML, CSS, JavaScript

## Troubleshooting

**Database connection error:**
- Check if MySQL is running in XAMPP
- Verify database credentials in `config/database.php`
- Ensure database `puja_services` exists

**Admin login not working:**
- Default password is `admin123`
- If changed, update via database or use password_hash() function

**404 errors on pages:**
- Check SITE_URL in `config/config.php`
- Ensure .htaccess or rewrite rules are configured (if needed)

## Support

For issues or questions, check the code comments or database structure.

