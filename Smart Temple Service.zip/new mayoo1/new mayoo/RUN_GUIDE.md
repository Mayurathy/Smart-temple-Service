# 🚀 Localhost-ல எப்படி Run பண்றது?

## Step 1: XAMPP-ஐ Start பண்ணுங்க

1. **XAMPP Control Panel-ஐ Open பண்ணுங்க**
   - Start Menu-ல தேடுங்க: "XAMPP"
   - அல்லது இங்க போங்க: `C:\xampp\xampp-control.exe`

2. **Apache & MySQL-ஐ Start பண்ணுங்க**
   - Apache-க்கு பக்கத்துல உள்ள "Start" button-ஐ click பண்ணுங்க
   - MySQL-க்கு பக்கத்துல உள்ள "Start" button-ஐ click பண்ணுங்க
   - Green color-ல மாறினா, successfully start ஆகிடுச்சு

⚠️ **பிரச்சனை வந்தா:**
- Port already in use error வந்தா, Skype அல்லது வேற programs-ஐ close பண்ணுங்க
- அல்லது XAMPP-ல Port settings மாத்துங்க

---

## Step 2: Database Setup பண்ணுங்க

### முதல் முறை மட்டும்:

1. **Browser-ல இந்த link-ஐ open பண்ணுங்க:**
   ```
   http://localhost/new%20mayoo1/new%20mayoo/database-migration.php
   ```

2. **Migration complete ஆனதும்:**
   - Database tables எல்லாம் create ஆகிடும்
   - Sample data insert ஆகிடும்
   - Default admin accounts create ஆகிடும்

3. **Success message பாத்ததும், website-க்கு போங்க!**

---

## Step 3: Website-ஐ Access பண்ணுங்க

### 🏠 Frontend (User Side):
```
http://localhost/new%20mayoo1/new%20mayoo/index.php
```
அல்லது
```
http://localhost/new%20mayoo1/new%20mayoo/
```

**Frontend pages:**
- Home: `http://localhost/new%20mayoo1/new%20mayoo/index.php`
- Pujas: `http://localhost/new%20mayoo1/new%20mayoo/pujas.php`
- Temples: `http://localhost/new%20mayoo1/new%20mayoo/temples.php`
- Services: `http://localhost/new%20mayoo1/new%20mayoo/services.php`
- Contact: `http://localhost/new%20mayoo1/new%20mayoo/contact.php`
- Sign Up: `http://localhost/new%20mayoo1/new%20mayoo/signup.php`
- Sign In: `http://localhost/new%20mayoo1/new%20mayoo/signin.php`

---

### 🔐 Admin Panel:
```
http://localhost/new%20mayoo1/new%20mayoo/admin/login.php
```

**Default Admin Credentials:**

| Username | Password | Role |
|----------|----------|------|
| `admin` | `password` | Superadmin (Full Access) |
| `content` | `password` | Content Manager |
| `operations` | `password` | Operations Manager |
| `manager` | `password` | General Manager |

⚠️ **Important:** உடனே password மாத்துங்க!

**Admin pages:**
- Dashboard: `http://localhost/new%20mayoo1/new%20mayoo/admin/index.php`
- Bookings: `http://localhost/new%20mayoo1/new%20mayoo/admin/bookings.php`
- Pujas: `http://localhost/new%20mayoo1/new%20mayoo/admin/pujas.php`
- Temples: `http://localhost/new%20mayoo1/new%20mayoo/admin/temples.php`
- Priests: `http://localhost/new%20mayoo1/new%20mayoo/admin/priests.php`
- Users: `http://localhost/new%20mayoo1/new%20mayoo/admin/users.php`
- Contacts: `http://localhost/new%20mayoo1/new%20mayoo/admin/contacts.php`

---

## 📁 Project Structure:

```
C:\xampp\htdocs\new mayoo1\new mayoo\
├── index.php                  (Homepage)
├── signin.php                 (User Login)
├── signup.php                 (User Registration)
├── pujas.php                  (Pujas List)
├── book-puja.php              (Booking Form)
├── contact.php                (Contact Form)
├── admin/
│   ├── login.php              (Admin Login)
│   ├── index.php              (Admin Dashboard)
│   ├── pujas.php              (Manage Pujas)
│   ├── bookings.php           (Manage Bookings)
│   └── ...
├── config/
│   ├── config.php             (Main Config)
│   └── database.php           (DB Connection)
├── assets/
│   ├── css/                   (Stylesheets)
│   ├── js/                    (JavaScript)
│   └── images/                (Images)
└── database-migration.php     (DB Setup)
```

---

## 🐛 Common Errors & Solutions:

### 1. **White Screen / Blank Page**
```
Solution: 
- Apache running-ஆ check பண்ணுங்க
- File path correct-ஆ இருக்கா பாருங்க
```

### 2. **Database Connection Error**
```
Solution:
- MySQL running-ஆ இருக்கா check பண்ணுங்க
- database-migration.php run பண்ணுங்க
```

### 3. **404 Not Found**
```
Solution:
- URL correct-ஆ இருக்கா பாருங்க
- File இருக்கா check பண்ணுங்க
```

### 4. **Column not found error**
```
Solution:
- database-migration.php மறுபடியும் run பண்ணுங்க
```

---

## 🔄 How to Stop the Server:

1. XAMPP Control Panel-ல போங்க
2. Apache-க்கு பக்கத்துல "Stop" click பண்ணுங்க
3. MySQL-க்கு பக்கத்துல "Stop" click பண்ணுங்க

---

## 📝 Quick Commands:

### Database Reset (எல்லாம் மறுபடியும் setup பண்ண):
1. phpMyAdmin open பண்ணுங்க: `http://localhost/phpmyadmin`
2. `puja_services` database-ஐ drop பண்ணுங்க
3. `database-migration.php` மறுபடியும் run பண்ணுங்க

### Fresh Start:
```
1. Stop Apache & MySQL
2. Delete database: puja_services
3. Start Apache & MySQL
4. Run: http://localhost/new%20mayoo1/new%20mayoo/database-migration.php
```

---

## ✅ Testing Checklist:

- [ ] XAMPP Apache & MySQL running-ஆ இருக்கு
- [ ] Database migration complete ஆச்சா
- [ ] Frontend pages open ஆகுதா
- [ ] Admin login work ஆகுதா
- [ ] User registration work ஆகுதா
- [ ] Booking form submit ஆகுதா
- [ ] Admin dashboard load ஆகுதா

---

## 🎯 Next Steps:

1. **Test Everything:**
   - User registration & login
   - Puja booking
   - Admin CRUD operations
   - Contact form submission

2. **Change Default Passwords:**
   - Login to admin panel
   - Go to Settings/Profile
   - Change password

3. **Add Your Content:**
   - Add real pujas
   - Add real temples
   - Add real priests
   - Upload images

---

## 📞 எதாவது doubt இருந்தா:

1. Error logs பாருங்க: `C:\xampp\htdocs\new mayoo1\new mayoo\logs\db_errors.log`
2. Browser console-ல errors check பண்ணுங்க (F12)
3. XAMPP logs பாருங்க

---

## 🚀 வெற்றி! (Success!)

இப்போ உங்க website localhost-ல successfully run ஆகிடுச்சு! 🎉

**Main URLs நினைவில் வச்சுக்கங்க:**
- Frontend: `http://localhost/new%20mayoo1/new%20mayoo/`
- Admin: `http://localhost/new%20mayoo1/new%20mayoo/admin/login.php`
- Migration: `http://localhost/new%20mayoo1/new%20mayoo/database-migration.php`
