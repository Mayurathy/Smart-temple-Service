<?php
require_once 'config/config.php';
$page_title = 'Gallery - Temple Photos & Puja Videos';
include 'includes/header.php';
?>

<link rel="stylesheet" href="assets/css/gallery-premium.css">

<!-- Hero Section -->
<section class="gallery-hero">
    <div class="container">
        <h1>Divine Gallery</h1>
        <p>Experience the spiritual ambiance through our collection of temple photos and sacred puja videos.</p>
    </div>
</section>

<section class="gallery-section">
    <div class="container">

        <!-- Temple Photos Section -->
        <div class="section-header">
            <h2>Temple Photos</h2>
            <p>Glimpses of divine architecture and sacred spaces</p>
        </div>

        <div class="photo-grid">
            <!-- Placeholder Images -->
            <div class="photo-item">
                <img src="https://images.unsplash.com/photo-1561361513-2d000a50f0dc?auto=format&fit=crop&w=800&q=80"
                    alt="Temple Architecture">
                <div class="photo-overlay">
                    <h4>Ancient Temple Architecture</h4>
                </div>
            </div>
            <div class="photo-item">
                <img src="https://images.unsplash.com/photo-1582510003544-4d00b7f74220?auto=format&fit=crop&w=800&q=80"
                    alt="Sacred Diya">
                <div class="photo-overlay">
                    <h4>Divine Light</h4>
                </div>
            </div>
            <div class="photo-item">
                <img src="https://images.unsplash.com/photo-1606216794074-735e91aa2c92?auto=format&fit=crop&w=800&q=80"
                    alt="Lord Ganesha">
                <div class="photo-overlay">
                    <h4>Lord Ganesha</h4>
                </div>
            </div>
            <div class="photo-item">
                <img src="https://images.unsplash.com/photo-1598890777032-bde835ba27c2?auto=format&fit=crop&w=800&q=80"
                    alt="Temple Bells">
                <div class="photo-overlay">
                    <h4>Temple Bells</h4>
                </div>
            </div>
            <div class="photo-item">
                <img src="https://images.unsplash.com/photo-1514539079130-25950c84af65?auto=format&fit=crop&w=800&q=80"
                    alt="Gopuram">
                <div class="photo-overlay">
                    <h4>Majestic Gopuram</h4>
                </div>
            </div>
            <div class="photo-item">
                <img src="https://images.unsplash.com/photo-1524492412937-b28074a5d7da?auto=format&fit=crop&w=800&q=80"
                    alt="India Temple">
                <div class="photo-overlay">
                    <h4>Sacred Sanctum</h4>
                </div>
            </div>
        </div>

        <!-- Puja Videos Section -->
        <div class="section-header">
            <h2>Puja Videos</h2>
            <p>Watch sacred rituals and divine ceremonies</p>
        </div>

        <div class="video-grid">
            <!-- Placeholder Videos (YouTube Embeds) -->
            <div class="video-item">
                <div class="video-wrapper">
                    <iframe src="https://www.youtube.com/embed/tgbNymZ7vqY" title="YouTube video player"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                        allowfullscreen></iframe>
                </div>
                <div class="video-info">
                    <h4>Morning Aarti</h4>
                    <p>Experience the divine morning prayers.</p>
                </div>
            </div>
            <div class="video-item">
                <div class="video-wrapper">
                    <iframe src="https://www.youtube.com/embed/ScMzIvxBSi4" title="YouTube video player"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                        allowfullscreen></iframe>
                </div>
                <div class="video-info">
                    <h4>Special Puja Ceremony</h4>
                    <p>Highlights from the grand festival puja.</p>
                </div>
            </div>
            <div class="video-item">
                <div class="video-wrapper">
                    <iframe src="https://www.youtube.com/embed/LXb3EKWsInQ" title="YouTube video player"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                        allowfullscreen></iframe>
                </div>
                <div class="video-info">
                    <h4>Vedic Chanting</h4>
                    <p>Powerful mantras for peace and prosperity.</p>
                </div>
            </div>
        </div>

    </div>
</section>

<?php include 'includes/footer.php'; ?>