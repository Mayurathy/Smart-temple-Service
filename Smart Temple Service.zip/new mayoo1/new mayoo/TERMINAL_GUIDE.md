# 💻 Terminal-ல எப்படி Run பண்றது?

## Option 1: XAMPP மூலமாக (Recommended)

### Step 1: XAMPP Services Start பண்ணுங்க

```powershell
# XAMPP Control Panel Open பண்ணுங்க (GUI)
cd C:\xampp
.\xampp-control.exe
```

**அல்லது Terminal-லேயே Start பண்ணலாம்:**

```powershell
# Apache Start
C:\xampp\apache\bin\httpd.exe

# MySQL Start (new terminal window)
C:\xampp\mysql\bin\mysqld.exe
```

---

## Option 2: PHP Built-in Server (Development Only)

### நேரடியா PHP server-ஐ run பண்ணுங்க:

```powershell
# Project directory-க்கு போங்க
cd "C:\xampp\htdocs\new mayoo1\new mayoo"

# PHP Development Server Start பண்ணுங்க
php -S localhost:8000
```

**அப்புறம் browser-ல:**
```
http://localhost:8000
```

⚠️ **Note:** இது development-க்கு மட்டும். Production-க்கு இல்ல.

---

## Option 3: Full Terminal Workflow (Expert Mode)

### 1️⃣ MySQL Service Start பண்ணுங்க

```powershell
# MySQL Start
net start mysql
```

**அல்லது XAMPP-ல இருந்து:**
```powershell
C:\xampp\mysql\bin\mysqld --console
```

### 2️⃣ Apache Service Start பண்ணுங்க

```powershell
# Apache Start
net start apache2.4
```

**அல்லது XAMPP-ல இருந்து:**
```powershell
C:\xampp\apache\bin\httpd.exe
```

### 3️⃣ Database Setup பண்ணுங்க (First Time)

```powershell
# Project directory-க்கு போங்க
cd "C:\xampp\htdocs\new mayoo1\new mayoo"

# MySQL CLI Open பண்ணுங்க
C:\xampp\mysql\bin\mysql.exe -u root

# MySQL-ல இந்த commands run பண்ணுங்க:
CREATE DATABASE IF NOT EXISTS puja_services CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE puja_services;
SOURCE database.sql;
EXIT;
```

**அல்லது Browser-ல Migration Run பண்ணுங்க:**
```
http://localhost/new%20mayoo1/new%20mayoo/database-migration.php
```

### 4️⃣ Website Access பண்ணுங்க

```
http://localhost/new%20mayoo1/new%20mayoo/
```

---

## 🚀 Quick Start Commands (Copy & Paste)

### Windows PowerShell:

```powershell
# 1. Navigate to project
cd "C:\xampp\htdocs\new mayoo1\new mayoo"

# 2. Check PHP version
php -v

# 3. Start PHP development server
php -S localhost:8000

# 4. Open in browser (separate terminal)
start http://localhost:8000
```

### Windows Command Prompt (CMD):

```cmd
REM 1. Navigate to project
cd "C:\xampp\htdocs\new mayoo1\new mayoo"

REM 2. Check PHP version
php -v

REM 3. Start PHP development server
php -S localhost:8000

REM 4. Open in browser (separate terminal)
start http://localhost:8000
```

---

## 📝 Common Terminal Commands

### Check Services Status:

```powershell
# Check if Apache is running
netstat -ano | findstr :80

# Check if MySQL is running
netstat -ano | findstr :3306

# Check PHP version
php -v

# Check MySQL version
C:\xampp\mysql\bin\mysql.exe --version
```

### Stop Services:

```powershell
# Stop Apache
net stop apache2.4

# Stop MySQL
net stop mysql

# Or kill specific processes
taskkill /F /IM httpd.exe
taskkill /F /IM mysqld.exe
```

### View Logs:

```powershell
# Apache error log
type C:\xampp\apache\logs\error.log

# MySQL error log
type C:\xampp\mysql\data\*.err

# PHP error log (if configured)
type C:\xampp\php\logs\php_error_log

# Your custom error log
type "C:\xampp\htdocs\new mayoo1\new mayoo\logs\db_errors.log"
```

---

## 🔧 Database Commands (Terminal)

### MySQL CLI-ல Database Manage பண்ணுங்க:

```powershell
# MySQL CLI Open பண்ணுங்க
C:\xampp\mysql\bin\mysql.exe -u root -p

# Database list பாருங்க
SHOW DATABASES;

# Database select பண்ணுங்க
USE puja_services;

# Tables list பாருங்க
SHOW TABLES;

# Table structure பாருங்க
DESCRIBE admins;

# Data select பண்ணுங்க
SELECT * FROM admins;

# Exit
EXIT;
```

### Database Export (Backup):

```powershell
# Full database export
C:\xampp\mysql\bin\mysqldump.exe -u root puja_services > backup.sql

# Specific table export
C:\xampp\mysql\bin\mysqldump.exe -u root puja_services admins > admins_backup.sql
```

### Database Import:

```powershell
# Import SQL file
C:\xampp\mysql\bin\mysql.exe -u root puja_services < database.sql

# Or from MySQL CLI
SOURCE C:/xampp/htdocs/new mayoo1/new mayoo/database.sql;
```

---

## 🎯 Development Workflow (Terminal)

### Complete Setup from Scratch:

```powershell
# 1. Start MySQL
cd C:\xampp
.\mysql\bin\mysqld --console

# 2. New terminal: Create database
.\mysql\bin\mysql.exe -u root -e "CREATE DATABASE IF NOT EXISTS puja_services CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"

# 3. Navigate to project
cd "C:\xampp\htdocs\new mayoo1\new mayoo"

# 4. Import database
C:\xampp\mysql\bin\mysql.exe -u root puja_services < database.sql

# 5. Start PHP server
php -S localhost:8000

# 6. Open browser
start http://localhost:8000/database-migration.php
```

---

## 🐛 Troubleshooting Commands

### Port Already in Use:

```powershell
# விட்டுக்கோங்க என்ன Port 80-ல run ஆகுது
netstat -ano | findstr :80

# அந்த process-ஐ kill பண்ணுங்க (replace PID with actual process ID)
taskkill /F /PID <PID>
```

### Permission Errors:

```powershell
# Run as Administrator
# Right-click PowerShell/CMD -> Run as Administrator
```

### Clear Cache:

```powershell
# Clear PHP OPcache (if enabled)
# Restart Apache or create clear-cache.php:
echo "<?php opcache_reset(); echo 'Cache cleared!'; ?>" > clear-cache.php
```

---

## 📊 Testing Commands

### Test Database Connection:

```powershell
# Create test file
cd "C:\xampp\htdocs\new mayoo1\new mayoo"
echo "<?php require_once 'config/database.php'; $conn = getDBConnection(); echo 'Connected successfully!'; ?>" > test-db.php

# Test via browser
start http://localhost/new%20mayoo1/new%20mayoo/test-db.php
```

### Run PHP Scripts:

```powershell
# Run migration from terminal
php database-migration.php

# Run any PHP file
php -f yourfile.php

# Check syntax
php -l signin.php
```

---

## 🔄 Auto-Start Script (Advanced)

உங்களுக்கு எளிதா இருக்க startup script create பண்ணலாம்:

### `start-project.bat` Create பண்ணுங்க:

```batch
@echo off
echo Starting Puja Services Application...
echo.

echo [1/3] Starting MySQL...
start /B C:\xampp\mysql\bin\mysqld.exe
timeout /t 3 >nul

echo [2/3] Starting Apache...
start /B C:\xampp\apache\bin\httpd.exe
timeout /t 2 >nul

echo [3/3] Opening browser...
start http://localhost/new%%20mayoo1/new%%20mayoo/

echo.
echo ✓ Server is running!
echo Press any key to stop servers...
pause >nul

echo Stopping servers...
taskkill /F /IM httpd.exe >nul 2>&1
taskkill /F /IM mysqld.exe >nul 2>&1
echo Done!
```

**Use பண்றது:**
```powershell
# Just double-click the .bat file or run:
.\start-project.bat
```

---

## 💡 Useful Aliases (PowerShell Profile)

PowerShell-ல shortcuts create பண்ணுங்க:

```powershell
# PowerShell profile edit பண்ணுங்க
notepad $PROFILE

# இந்த aliases add பண்ணுங்க:
function Start-Puja {
    cd "C:\xampp\htdocs\new mayoo1\new mayoo"
    php -S localhost:8000
}

function Start-XAMPP {
    & "C:\xampp\xampp-control.exe"
}

function DB-Connect {
    & "C:\xampp\mysql\bin\mysql.exe" -u root
}

# Save and reload
. $PROFILE
```

**இப்போ நீங்க run பண்ணலாம்:**
```powershell
Start-Puja      # Starts PHP server
Start-XAMPP     # Opens XAMPP control
DB-Connect      # Opens MySQL CLI
```

---

## 🎓 Summary

### XAMPP-ல (Recommended):
1. `C:\xampp\xampp-control.exe` - Open XAMPP Control Panel
2. Start Apache & MySQL
3. Browser: `http://localhost/new%20mayoo1/new%20mayoo/`

### PHP Built-in Server-ல:
1. `cd "C:\xampp\htdocs\new mayoo1\new mayoo"`
2. `php -S localhost:8000`
3. Browser: `http://localhost:8000`

### Database Setup:
1. Browser: `http://localhost/new%20mayoo1/new%20mayoo/database-migration.php`
2. Or MySQL CLI: Import `database.sql`

---

## 📞 Quick Reference

| Command | Purpose |
|---------|---------|
| `php -S localhost:8000` | Start dev server |
| `php -v` | Check PHP version |
| `netstat -ano \| findstr :80` | Check port 80 |
| `C:\xampp\mysql\bin\mysql.exe -u root` | Open MySQL CLI |
| `taskkill /F /IM httpd.exe` | Stop Apache |
| `taskkill /F /IM mysqld.exe` | Stop MySQL |

---

**Happy Coding! 🚀**
