<?php
/**
 * Database Migration Script
 * Safely updates existing database with new columns and tables
 */

require_once 'config/database.php';

echo "<!DOCTYPE html><html><head><title>Database Migration</title>";
echo "<style>body{font-family:Arial;padding:20px;max-width:800px;margin:0 auto;}";
echo ".success{color:green;}.error{color:red;}.info{color:blue;}</style></head><body>";
echo "<h1>Database Migration Tool</h1>";

$conn = getDBConnection();

if (!$conn) {
    echo "<p class='error'>❌ Database connection failed!</p></body></html>";
    exit;
}

echo "<p class='success'>✓ Connected to database successfully</p>";

// Function to safely add column if not exists
function addColumnIfNotExists($conn, $table, $column, $definition)
{
    $check = $conn->query("SHOW COLUMNS FROM `$table` LIKE '$column'");
    if ($check && $check->num_rows == 0) {
        $sql = "ALTER TABLE `$table` ADD COLUMN `$column` $definition";
        if ($conn->query($sql)) {
            echo "<p class='success'>✓ Added column '$column' to table '$table'</p>";
            return true;
        } else {
            echo "<p class='error'>❌ Error adding column '$column' to '$table': " . $conn->error . "</p>";
            return false;
        }
    } else {
        echo "<p class='info'>ℹ Column '$column' already exists in table '$table'</p>";
        return true;
    }
}

// Function to create table if not exists
function createTableIfNotExists($conn, $tableName, $createSQL)
{
    $check = $conn->query("SHOW TABLES LIKE '$tableName'");
    if ($check && $check->num_rows == 0) {
        if ($conn->query($createSQL)) {
            echo "<p class='success'>✓ Created table '$tableName'</p>";
            return true;
        } else {
            echo "<p class='error'>❌ Error creating table '$tableName': " . $conn->error . "</p>";
            return false;
        }
    } else {
        echo "<p class='info'>ℹ Table '$tableName' already exists</p>";
        return true;
    }
}

echo "<h2>Step 1: Creating Missing Tables</h2>";

// Create users table
createTableIfNotExists($conn, 'users', "
    CREATE TABLE users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL UNIQUE,
        phone VARCHAR(25) NOT NULL,
        password VARCHAR(255) NOT NULL,
        status ENUM('active', 'inactive') DEFAULT 'active',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_email (email)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
");

// Create donations table
createTableIfNotExists($conn, 'donations', "
    CREATE TABLE donations (
        id INT AUTO_INCREMENT PRIMARY KEY,
        donor_name VARCHAR(255) NOT NULL,
        donor_email VARCHAR(255) NOT NULL,
        donor_phone VARCHAR(20),
        amount DECIMAL(10, 2) NOT NULL,
        purpose VARCHAR(255),
        payment_method VARCHAR(50),
        payment_status ENUM('pending', 'completed', 'failed') DEFAULT 'pending',
        transaction_id VARCHAR(100),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_payment_status (payment_status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
");

// Create gallery table
createTableIfNotExists($conn, 'gallery', "
    CREATE TABLE gallery (
        id INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        description TEXT,
        image VARCHAR(255) NOT NULL,
        category VARCHAR(50) DEFAULT 'general',
        status ENUM('active', 'inactive') DEFAULT 'active',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_category (category)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
");

// Create testimonials table
createTableIfNotExists($conn, 'testimonials', "
    CREATE TABLE testimonials (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255),
        rating INT DEFAULT 5,
        message TEXT NOT NULL,
        status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_status (status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
");

echo "<h2>Step 2: Adding Missing Columns to Existing Tables</h2>";

// Add role column to admins table
addColumnIfNotExists(
    $conn,
    'admins',
    'role',
    "ENUM('superadmin', 'content', 'operations', 'manager') DEFAULT 'superadmin' AFTER password"
);

addColumnIfNotExists(
    $conn,
    'admins',
    'status',
    "ENUM('active', 'inactive') DEFAULT 'active' AFTER role"
);

addColumnIfNotExists(
    $conn,
    'admins',
    'updated_at',
    "TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER created_at"
);

// Add category column to pujas table
addColumnIfNotExists(
    $conn,
    'pujas',
    'category',
    "VARCHAR(50) DEFAULT 'general' AFTER image"
);

addColumnIfNotExists(
    $conn,
    'pujas',
    'updated_at',
    "TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER created_at"
);

// Add status to users table if exists
$checkUsers = $conn->query("SHOW TABLES LIKE 'users'");
if ($checkUsers && $checkUsers->num_rows > 0) {
    addColumnIfNotExists(
        $conn,
        'users',
        'status',
        "ENUM('active', 'inactive') DEFAULT 'active' AFTER password"
    );
    addColumnIfNotExists(
        $conn,
        'users',
        'updated_at',
        "TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER created_at"
    );
}

// Add updated_at to other tables
addColumnIfNotExists(
    $conn,
    'priests',
    'updated_at',
    "TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER created_at"
);

addColumnIfNotExists(
    $conn,
    'temples',
    'updated_at',
    "TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER created_at"
);

addColumnIfNotExists(
    $conn,
    'bookings',
    'updated_at',
    "TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER created_at"
);

addColumnIfNotExists(
    $conn,
    'contacts',
    'updated_at',
    "TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER created_at"
);

// Add image column to priests if missing
addColumnIfNotExists(
    $conn,
    'priests',
    'image',
    "VARCHAR(255) AFTER location"
);

// Add status to subscribers
addColumnIfNotExists(
    $conn,
    'subscribers',
    'status',
    "ENUM('active', 'unsubscribed') DEFAULT 'active' AFTER email"
);

echo "<h2>Step 3: Seeding Default Data</h2>";

// Insert default admins if not exists
$checkAdmin = $conn->query("SELECT id FROM admins WHERE username = 'admin'");
if ($checkAdmin && $checkAdmin->num_rows == 0) {
    $defaultHash = '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi'; // password
    $insertAdmins = "INSERT INTO admins (username, email, password, role, status) VALUES 
        ('admin', 'admin@pujaservices.com', '$defaultHash', 'superadmin', 'active'),
        ('content', 'content@pujaservices.com', '$defaultHash', 'content', 'active'),
        ('operations', 'ops@pujaservices.com', '$defaultHash', 'operations', 'active'),
        ('manager', 'manager@pujaservices.com', '$defaultHash', 'manager', 'active')
    ON DUPLICATE KEY UPDATE username=username";

    if ($conn->query($insertAdmins)) {
        echo "<p class='success'>✓ Default admin users created</p>";
    } else {
        echo "<p class='error'>❌ Error creating admin users: " . $conn->error . "</p>";
    }
} else {
    echo "<p class='info'>ℹ Admin users already exist</p>";
}

echo "<h2>Migration Complete!</h2>";
echo "<p class='success'><strong>Database migration completed successfully!</strong></p>";
echo "<p>Default admin credentials:</p>";
echo "<ul>";
echo "<li><strong>Username:</strong> admin | <strong>Password:</strong> password</li>";
echo "<li><strong>Username:</strong> content | <strong>Password:</strong> password</li>";
echo "<li><strong>Username:</strong> operations | <strong>Password:</strong> password</li>";
echo "<li><strong>Username:</strong> manager | <strong>Password:</strong> password</li>";
echo "</ul>";
echo "<p class='error'><strong>⚠️ IMPORTANT:</strong> Change these passwords immediately after logging in!</p>";
echo "<p><a href='admin/login.php' style='padding:10px 20px;background:#ff6b35;color:white;text-decoration:none;border-radius:5px;'>Go to Admin Login</a></p>";
echo "<p><a href='index.php' style='padding:10px 20px;background:#004e89;color:white;text-decoration:none;border-radius:5px;margin-left:10px;'>Go to Homepage</a></p>";

$conn->close();
echo "</body></html>";
?>