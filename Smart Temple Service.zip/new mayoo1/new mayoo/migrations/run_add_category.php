<?php
/**
 * Migration Runner - Add Category to Pujas
 * Run this script once to add the category column to your pujas table
 */

require_once '../config/config.php';

$conn = getDBConnection();

echo "Starting migration: Adding category column to pujas table...\n\n";

// Add category column
$sql1 = "ALTER TABLE pujas ADD COLUMN category VARCHAR(50) DEFAULT 'wealth' AFTER price";

try {
    if ($conn->query($sql1) === TRUE) {
        echo "✓ Successfully added 'category' column to pujas table\n";
    } else {
        // Check if column already exists
        if (strpos($conn->error, 'Duplicate column') !== false) {
            echo "ℹ Column 'category' already exists\n";
        } else {
            echo "✗ Error adding category column: " . $conn->error . "\n";
        }
    }
} catch (Exception $e) {
    if (strpos($e->getMessage(), 'Duplicate column') !== false) {
        echo "ℹ Column 'category' already exists\n";
    } else {
        echo "✗ Error: " . $e->getMessage() . "\n";
    }
}

// Update existing records to have default category
$sql2 = "UPDATE pujas SET category = 'wealth' WHERE category IS NULL OR category = ''";

try {
    if ($conn->query($sql2) === TRUE) {
        echo "✓ Updated existing pujas with default category\n";
    } else {
        echo "✗ Error updating existing pujas: " . $conn->error . "\n";
    }
} catch (Exception $e) {
    echo "✗ Error: " . $e->getMessage() . "\n";
}

echo "\nMigration complete!\n";
echo "You can now upload images and assign categories to your pujas.\n";

$conn->close();
?>