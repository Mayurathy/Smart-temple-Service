-- Add category column to pujas table if it doesn't exist
ALTER TABLE pujas 
ADD COLUMN IF NOT EXISTS category VARCHAR(50) DEFAULT 'wealth' AFTER price;

-- Update existing pujas to have a default category if needed
UPDATE pujas SET category = 'wealth' WHERE category IS NULL OR category = '';
