<?php
require_once 'config/config.php';
$page_title = 'About Us - Puja Services';
include 'includes/header.php';
?>
<link rel="stylesheet" href="<?php echo SITE_URL; ?>/assets/css/about-sections.css">
<link rel="stylesheet" href="<?php echo SITE_URL; ?>/assets/css/about-new-sections.css">
<!-- About Section -->
<section class="about-section animated fade-in-up">
    <div class="container">
        <div class="section-header">
            <span class="section-label">ABOUT US</span>
            <h2 class="section-heading">Puja Services – Your Digital Gateway to Hindu Spirituality!</h2>
        </div>
        <div class="about-grid">
            <div class="about-image">
                <img src="<?php echo SITE_URL; ?>/assets/viratham/v1.jpg" alt="Deity">
            </div>
            <div class="about-content">
                <p>
                    Puja Services is the leading digital platform for all Hindu devotional needs and spiritual services.
                    Designed to seamlessly connect the present and future generations to Hinduism, our portal is
                    accessible through a Web Portal, Android, and iOS apps. In today’s fast‑paced world, ancient
                    traditions, values, and customs are at risk of being lost. Puja Services is dedicated to preserving
                    and passing down the rich heritage, history, and spiritual essence of Hinduism to future
                    generations.
                </p>
                <div class="about-cards">
                    <div class="about-card">
                        <div class="about-card-icon"><i class="fas fa-heart"></i></div>
                        <div>
                            <h3>Our vision</h3>
                            <p>To inspire and instil devotion in future generations toward Hindu Dharma through
                                advanced technology.</p>
                        </div>
                    </div>
                    <div class="about-card">
                        <div class="about-card-icon"><i class="fas fa-bullseye"></i></div>
                        <div>
                            <h3>Our Mission</h3>
                            <p>To bring all Spiritual Services and Traditions of Hindu Dharma on to a Single Digital
                                Platform.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Statistics Section -->
<section class="stats-section animated fade-in-up">
    <div class="container">
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon"><i class="fas fa-users"></i></div>
                <div class="stat-number" data-target="50000">0</div>
                <div class="stat-label">Happy Devotees</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon"><i class="fas fa-hands-praying"></i></div>
                <div class="stat-number" data-target="100000">0</div>
                <div class="stat-label">Pujas Performed</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon"><i class="fas fa-user-tie"></i></div>
                <div class="stat-number" data-target="500">0</div>
                <div class="stat-label">Verified Priests</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon"><i class="fas fa-city"></i></div>
                <div class="stat-number" data-target="100">0</div>
                <div class="stat-label">Cities Served</div>
            </div>
        </div>
    </div>
</section>

<script>
    document.addEventListener('DOMContentLoaded', () => {
        const counters = document.querySelectorAll('.stat-number');
        const speed = 200; // The lower the slower

        const animateCounters = () => {
            counters.forEach(counter => {
                const updateCount = () => {
                    const target = +counter.getAttribute('data-target');
                    const count = +counter.innerText;
                    const inc = target / speed;

                    if (count < target) {
                        counter.innerText = Math.ceil(count + inc);
                        setTimeout(updateCount, 20);
                    } else {
                        counter.innerText = target + "+";
                    }
                };
                updateCount();
            });
        }

        // Trigger animation when section is in view
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    animateCounters();
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.5 });

        const statsSection = document.querySelector('.stats-section');
        if (statsSection) {
            observer.observe(statsSection);
        }
    });
</script>

<!-- Why Choose Us Section -->
<section class="why-choose-section animated fade-in-up">
    <div class="container">
        <div class="section-header text-center">
            <span class="section-label">WHY CHOOSE US</span>
            <h2 class="section-heading">What Makes Us Different</h2>
        </div>
        <div class="why-choose-grid">
            <div class="why-card">
                <div class="why-icon"><i class="fas fa-certificate"></i></div>
                <h3>Authenticity Guaranteed</h3>
                <p>All our priests are verified Vedic scholars with years of experience in performing traditional
                    rituals.</p>
            </div>
            <div class="why-card">
                <div class="why-icon"><i class="fas fa-shield-alt"></i></div>
                <h3>Secure & Trusted</h3>
                <p>100% secure payment gateway and data protection. Your privacy and security are our top priorities.
                </p>
            </div>
            <div class="why-card">
                <div class="why-icon"><i class="fas fa-clock"></i></div>
                <h3>24/7 Accessibility</h3>
                <p>Book pujas anytime, anywhere through our web portal, Android, and iOS apps at your convenience.</p>
            </div>
            <div class="why-card">
                <div class="why-icon"><i class="fas fa-heart"></i></div>
                <h3>Tradition Meets Tech</h3>
                <p>Ancient spiritual practices enhanced with modern technology for seamless devotee experience.</p>
            </div>
            <div class="why-card">
                <div class="why-icon"><i class="fas fa-mobile-alt"></i></div>
                <h3>Multi-Platform</h3>
                <p>Access our services from web browsers, Android devices, or iOS devices - your choice, your comfort.
                </p>
            </div>
            <div class="why-card">
                <div class="why-icon"><i class="fas fa-headset"></i></div>
                <h3>Dedicated Support</h3>
                <p>Our customer care team is always ready to assist you with any queries or concerns.</p>
            </div>
        </div>
    </div>
</section>

<!-- Testimonials Section -->
<section class="testimonials-section animated fade-in-up">
    <div class="container">
        <div class="section-header text-center">
            <span class="section-label">TESTIMONIALS</span>
            <h2 class="section-heading">What Our Devotees Say</h2>
        </div>
        <div class="testimonials-grid">
            <div class="testimonial-card">
                <div class="testimonial-quote"><i class="fas fa-quote-left"></i></div>
                <p class="testimonial-text">"Puja Services made it so easy for me to book a Satyanarayan Puja for my new
                    home. The priest was knowledgeable and the entire process was smooth. Highly recommended!"</p>
                <div class="testimonial-author">
                    <div class="author-avatar"><i class="fas fa-user-circle"></i></div>
                    <div>
                        <h4>Rajesh Kumar</h4>
                        <p>Hyderabad, India</p>
                    </div>
                </div>
            </div>
            <div class="testimonial-card">
                <div class="testimonial-quote"><i class="fas fa-quote-left"></i></div>
                <p class="testimonial-text">"Living abroad, I missed performing traditional pujas. This platform
                    connected me with authentic priests who conducted the rituals online. It felt like being back home!"
                </p>
                <div class="testimonial-author">
                    <div class="author-avatar"><i class="fas fa-user-circle"></i></div>
                    <div>
                        <h4>Priya Sharma</h4>
                        <p>New York, USA</p>
                    </div>
                </div>
            </div>
            <div class="testimonial-card">
                <div class="testimonial-quote"><i class="fas fa-quote-left"></i></div>
                <p class="testimonial-text">"The convenience of booking temple pujas through the app is amazing. I can
                    now offer prayers at famous temples without the long journey. Thank you, Puja Services!"</p>
                <div class="testimonial-author">
                    <div class="author-avatar"><i class="fas fa-user-circle"></i></div>
                    <div>
                        <h4>Venkat Reddy</h4>
                        <p>Bangalore, India</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Team Section -->
<section class="team-section animated fade-in-up">
    <div class="container">
        <div class="section-header text-center">
            <span class="section-label">TEAM</span>
            <h2 class="section-heading">Our Management</h2>
        </div>
        <div class="team-grid">
            <div class="team-card">
                <div class="team-photo">
                    <img src="https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=600&h=600&fit=crop&q=80"
                        alt="Nagaraju Penumetsa">
                </div>
                <div class="team-info">
                    <h4>R.Mayurathy</h4>
                    <p>Co-Founder | President</p>
                </div>
            </div>
            <div class="team-card">
                <div class="team-photo">
                    <img src="https://images.unsplash.com/photo-1527980965255-d3b416303d12?w=600&h=600&fit=crop&q=80"
                        alt="Tanikella Bharani">
                </div>
                <div class="team-info">
                    <h4>Premasiri Thivvikan</h4>
                    <p>Advisory Director</p>
                </div>
            </div>
            <div class="team-card">
                <div class="team-photo">
                    <img src="https://images.unsplash.com/photo-1547425260-76bcadfb4f2c?w=600&h=600&fit=crop&q=80"
                        alt="Rao Cherukuri">
                </div>
                <div class="team-info">
                    <h4>Ramachanthiran Kajakaran</h4>
                    <p>Director</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Our Journey Timeline Section -->
<section class="journey-section animated fade-in-up">
    <div class="container">
        <div class="section-header text-center">
            <span class="section-label">OUR STORY</span>
            <h2 class="section-heading">Our Journey</h2>
        </div>
        <div class="timeline">
            <div class="timeline-item">
                <div class="timeline-dot"></div>
                <div class="timeline-content">
                    <h3>2020 - Founded</h3>
                    <p>Started with a vision to digitize Hindu spiritual services and make them accessible to everyone
                    </p>
                </div>
            </div>
            <div class="timeline-item">
                <div class="timeline-dot"></div>
                <div class="timeline-content">
                    <h3>2021 - First 10K Users</h3>
                    <p>Reached our first milestone of 10,000 devotees using our platform for online pujas</p>
                </div>
            </div>
            <div class="timeline-item">
                <div class="timeline-dot"></div>
                <div class="timeline-content">
                    <h3>2022 - Mobile Apps Launch</h3>
                    <p>Launched Android and iOS apps, making spiritual services available on-the-go</p>
                </div>
            </div>
            <div class="timeline-item">
                <div class="timeline-dot"></div>
                <div class="timeline-content">
                    <h3>2023 - Pan India Expansion</h3>
                    <p>Extended services to 100+ cities across India with 500+ verified priests</p>
                </div>
            </div>
            <div class="timeline-item">
                <div class="timeline-dot"></div>
                <div class="timeline-content">
                    <h3>2024 - Global Reach</h3>
                    <p>Serving devotees worldwide with 100,000+ pujas performed and counting</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Core Values Section -->
<section class="values-section animated fade-in-up">
    <div class="container">
        <div class="section-header text-center">
            <span class="section-label">VALUES</span>
            <h2 class="section-heading">Our Core Values</h2>
        </div>
        <div class="values-grid">
            <div class="value-card">
                <div class="value-icon"><i class="fas fa-certificate"></i></div>
                <h3>Authenticity</h3>
                <p>100% authentic Vedic rituals performed by certified priests following traditional scriptures</p>
            </div>
            <div class="value-card">
                <div class="value-icon"><i class="fas fa-shield-alt"></i></div>
                <h3>Trust</h3>
                <p>Building lasting relationships through transparency, security, and reliable service delivery</p>
            </div>
            <div class="value-card">
                <div class="value-icon"><i class="fas fa-lightbulb"></i></div>
                <h3>Innovation</h3>
                <p>Leveraging cutting-edge technology to preserve and promote ancient spiritual traditions</p>
            </div>
            <div class="value-card">
                <div class="value-icon"><i class="fas fa-praying-hands"></i></div>
                <h3>Devotion</h3>
                <p>Dedicated to serving devotees with utmost respect, care, and spiritual commitment</p>
            </div>
        </div>
    </div>
</section>

<!-- Awards & Recognition Section -->
<section class="awards-section animated fade-in-up">
    <div class="container">
        <div class="section-header text-center">
            <span class="section-label">RECOGNITION</span>
            <h2 class="section-heading">Awards & Recognition</h2>
        </div>
        <div class="awards-grid">
            <div class="award-card">
                <div class="award-icon"><i class="fas fa-trophy"></i></div>
                <h3>Best Spiritual Platform 2023</h3>
                <p>Digital India Awards</p>
            </div>
            <div class="award-card">
                <div class="award-icon"><i class="fas fa-award"></i></div>
                <h3>Excellence in Service</h3>
                <p>Hindu Heritage Foundation</p>
            </div>
            <div class="award-card">
                <div class="award-icon"><i class="fas fa-star"></i></div>
                <h3>Top Rated App</h3>
                <p>Google Play Store - 4.8★</p>
            </div>
            <div class="award-card">
                <div class="award-icon"><i class="fas fa-medal"></i></div>
                <h3>Innovation Award</h3>
                <p>Tech for Good Initiative</p>
            </div>
        </div>
    </div>
</section>

<!-- Our Presence Section - Premium Design -->
<section class="presence-section animated fade-in-up"
    style="background: linear-gradient(135deg, #7f1d1d 0%, #450a0a 100%); padding: 100px 0; position: relative; overflow: hidden;">
    <!-- Decorative Pattern Overlay -->
    <div
        style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; background-image: url('data:image/svg+xml,%3Csvg width=\'60\' height=\'60\' viewBox=\'0 0 60 60\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cg fill=\'none\' fill-rule=\'evenodd\'%3E%3Cg fill=\'%23d4af37\' fill-opacity=\'0.05\'%3E%3Cpath d=\'M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z\'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E'); pointer-events: none; opacity: 0.3;">
    </div>

    <div class="container" style="position: relative; z-index: 1;">
        <div class="section-header text-center" style="margin-bottom: 60px;">
            <span class="section-label"
                style="color: #fcd34d; font-weight: 700; letter-spacing: 3px; font-size: 14px; text-transform: uppercase;">GLOBAL
                REACH</span>
            <h2 class="section-heading"
                style="font-size: 48px; font-weight: 900; color: white; margin-top: 15px; font-family: 'Playfair Display', serif;">
                Our Presence</h2>
            <p style="color: rgba(255,255,255,0.8); max-width: 600px; margin: 15px auto 0; font-size: 18px;">Serving
                devotees across the globe with authentic spiritual services</p>
        </div>

        <div class="presence-grid"
            style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 40px; max-width: 1200px; margin: 0 auto;">
            <!-- Cities Card -->
            <div class="presence-card animated zoom-in delay-100"
                style="background: rgba(255,255,255,0.1); backdrop-filter: blur(10px); border-radius: 24px; padding: 50px 30px; text-align: center; border: 2px solid rgba(255,255,255,0.2); transition: all 0.4s ease; position: relative; overflow: hidden;">
                <div
                    style="position: absolute; top: -50px; right: -50px; width: 150px; height: 150px; background: radial-gradient(circle, rgba(212,175,55,0.2) 0%, transparent 70%); border-radius: 50%;">
                </div>
                <div
                    style="width: 90px; height: 90px; background: linear-gradient(135deg, #d4af37, #fcd34d); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 25px; box-shadow: 0 10px 30px rgba(212,175,55,0.4); position: relative; z-index: 1;">
                    <i class="fas fa-city" style="font-size: 40px; color: #450a0a;"></i>
                </div>
                <div class="presence-number"
                    style="font-size: 56px; font-weight: 900; color: #fcd34d; margin-bottom: 10px; font-family: 'Playfair Display', serif; text-shadow: 0 4px 10px rgba(0,0,0,0.3);">
                    100+</div>
                <h3 style="font-size: 24px; font-weight: 700; color: white; margin-bottom: 8px;">Cities</h3>
                <p style="color: rgba(255,255,255,0.7); font-size: 15px; margin: 0;">Across India</p>
            </div>

            <!-- Temples Card -->
            <div class="presence-card animated zoom-in delay-200"
                style="background: rgba(255,255,255,0.1); backdrop-filter: blur(10px); border-radius: 24px; padding: 50px 30px; text-align: center; border: 2px solid rgba(255,255,255,0.2); transition: all 0.4s ease; position: relative; overflow: hidden;">
                <div
                    style="position: absolute; top: -50px; right: -50px; width: 150px; height: 150px; background: radial-gradient(circle, rgba(212,175,55,0.2) 0%, transparent 70%); border-radius: 50%;">
                </div>
                <div
                    style="width: 90px; height: 90px; background: linear-gradient(135deg, #d4af37, #fcd34d); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 25px; box-shadow: 0 10px 30px rgba(212,175,55,0.4); position: relative; z-index: 1;">
                    <i class="fas fa-gopuram" style="font-size: 40px; color: #450a0a;"></i>
                </div>
                <div class="presence-number"
                    style="font-size: 56px; font-weight: 900; color: #fcd34d; margin-bottom: 10px; font-family: 'Playfair Display', serif; text-shadow: 0 4px 10px rgba(0,0,0,0.3);">
                    250+</div>
                <h3 style="font-size: 24px; font-weight: 700; color: white; margin-bottom: 8px;">Temples</h3>
                <p style="color: rgba(255,255,255,0.7); font-size: 15px; margin: 0;">Partner Temples</p>
            </div>

            <!-- Priests Card -->
            <div class="presence-card animated zoom-in delay-300"
                style="background: rgba(255,255,255,0.1); backdrop-filter: blur(10px); border-radius: 24px; padding: 50px 30px; text-align: center; border: 2px solid rgba(255,255,255,0.2); transition: all 0.4s ease; position: relative; overflow: hidden;">
                <div
                    style="position: absolute; top: -50px; right: -50px; width: 150px; height: 150px; background: radial-gradient(circle, rgba(212,175,55,0.2) 0%, transparent 70%); border-radius: 50%;">
                </div>
                <div
                    style="width: 90px; height: 90px; background: linear-gradient(135deg, #d4af37, #fcd34d); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 25px; box-shadow: 0 10px 30px rgba(212,175,55,0.4); position: relative; z-index: 1;">
                    <i class="fas fa-user-tie" style="font-size: 40px; color: #450a0a;"></i>
                </div>
                <div class="presence-number"
                    style="font-size: 56px; font-weight: 900; color: #fcd34d; margin-bottom: 10px; font-family: 'Playfair Display', serif; text-shadow: 0 4px 10px rgba(0,0,0,0.3);">
                    500+</div>
                <h3 style="font-size: 24px; font-weight: 700; color: white; margin-bottom: 8px;">Priests</h3>
                <p style="color: rgba(255,255,255,0.7); font-size: 15px; margin: 0;">Verified Pandits</p>
            </div>

            <!-- Countries Card -->
            <div class="presence-card animated zoom-in delay-400"
                style="background: rgba(255,255,255,0.1); backdrop-filter: blur(10px); border-radius: 24px; padding: 50px 30px; text-align: center; border: 2px solid rgba(255,255,255,0.2); transition: all 0.4s ease; position: relative; overflow: hidden;">
                <div
                    style="position: absolute; top: -50px; right: -50px; width: 150px; height: 150px; background: radial-gradient(circle, rgba(212,175,55,0.2) 0%, transparent 70%); border-radius: 50%;">
                </div>
                <div
                    style="width: 90px; height: 90px; background: linear-gradient(135deg, #d4af37, #fcd34d); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 25px; box-shadow: 0 10px 30px rgba(212,175,55,0.4); position: relative; z-index: 1;">
                    <i class="fas fa-globe-asia" style="font-size: 40px; color: #450a0a;"></i>
                </div>
                <div class="presence-number"
                    style="font-size: 56px; font-weight: 900; color: #fcd34d; margin-bottom: 10px; font-family: 'Playfair Display', serif; text-shadow: 0 4px 10px rgba(0,0,0,0.3);">
                    15+</div>
                <h3 style="font-size: 24px; font-weight: 700; color: white; margin-bottom: 8px;">Countries</h3>
                <p style="color: rgba(255,255,255,0.7); font-size: 15px; margin: 0;">Global Reach</p>
            </div>
        </div>
    </div>
</section>

<style>
    .presence-card:hover {
        transform: translateY(-10px);
        border-color: #d4af37 !important;
        box-shadow: 0 20px 40px rgba(212, 175, 55, 0.3);
    }

    .presence-card:hover .presence-number {
        transform: scale(1.1);
        transition: transform 0.3s ease;
    }

    @media (max-width: 1024px) {
        .presence-grid {
            grid-template-columns: repeat(2, 1fr) !important;
        }
    }

    @media (max-width: 640px) {
        .presence-grid {
            grid-template-columns: 1fr !important;
        }
    }
</style>

<!-- Partners & Collaborations Section -->
<section class="partners-section animated fade-in-up">
    <div class="container">
        <div class="section-header text-center">
            <span class="section-label">PARTNERSHIPS</span>
            <h2 class="section-heading">Our Partners & Collaborations</h2>
        </div>
        <div class="partners-grid">
            <div class="partner-category">
                <h3><i class="fas fa-gopuram"></i> Temple Partnerships</h3>
                <ul>
                    <li>Tirupati Balaji Temple</li>
                    <li>Shirdi Sai Baba Temple</li>
                    <li>Madurai Meenakshi Temple</li>
                    <li>Vaishno Devi Shrine</li>
                </ul>
            </div>
            <div class="partner-category">
                <h3><i class="fas fa-hands-helping"></i> NGO Collaborations</h3>
                <ul>
                    <li>Annadanam Foundation</li>
                    <li>Vedic Heritage Trust</li>
                    <li>Spiritual Education Forum</li>
                    <li>Hindu Culture Preservation Society</li>
                </ul>
            </div>
            <div class="partner-category">
                <h3><i class="fas fa-laptop-code"></i> Technology Partners</h3>
                <ul>
                    <li>Google Cloud Platform</li>
                    <li>Razorpay Payment Gateway</li>
                    <li>AWS Infrastructure</li>
                    <li>Firebase Services</li>
                </ul>
            </div>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>