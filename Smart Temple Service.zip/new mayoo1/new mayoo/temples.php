<?php
require_once 'config/config.php';
$page_title = 'Temples - Puja Services';
include 'includes/header.php';

$conn = getDBConnection();
$temples_query = "SELECT * FROM temples WHERE status = 'active' ORDER BY name ASC";
$temples_result = $conn->query($temples_query);
?>
<link rel="stylesheet" href="<?php echo SITE_URL; ?>/assets/css/temples-premium.css">

<!-- Hero Section -->
<section class="temples-hero">
    <div class="container">
        <h1>Pilgrimage to the Divine</h1>
        <p>Connect with the most sacred energy centers. Book pujas at renowned ancient temples from the comfort of your
            home.</p>
    </div>
</section>

<!-- Featured Temple Spotlight (Static Example or First from DB) -->
<section class="featured-temple-section animated fade-in-up">
    <div class="container">
        <div class="featured-grid">
            <div class="featured-image">
                <img src="https://images.unsplash.com/photo-1582555172866-f73bb12a2ab3?q=80&w=2080&auto=format&fit=crop"
                    alt="Featured Temple" style="width: 100%; display: block;">
            </div>
            <div class="featured-content">
                <span style="color: #ea580c; font-weight: 700; letter-spacing: 1px; text-transform: uppercase;">Temple
                    of the Month</span>
                <h2>Kashi Vishwanath Temple</h2>
                <p>Experience the divine aura of Varanasi. The Kashi Vishwanath Temple is one of the most famous Hindu
                    temples dedicated to Lord Shiva. It is located in Varanasi, Uttar Pradesh, India. The temple stands
                    on the western bank of the holy river Ganga.</p>
                <div style="display: flex; gap: 20px; margin-top: 30px;">
                    <div style="text-align: center;">
                        <h4 style="font-size: 24px; font-weight: 800; color: #1f2937; margin: 0;">12</h4>
                        <span style="font-size: 13px; color: #6b7280;">Jyotirlingas</span>
                    </div>
                    <div style="text-align: center; border-left: 1px solid #e5e7eb; padding-left: 20px;">
                        <h4 style="font-size: 24px; font-weight: 800; color: #1f2937; margin: 0;">1000+</h4>
                        <span style="font-size: 13px; color: #6b7280;">Years Old</span>
                    </div>
                </div>
                <a href="#" class="btn-book-temple"
                    style="display: inline-block; width: auto; margin-top: 30px; padding: 15px 40px;">Explore Now</a>
            </div>
        </div>
    </div>
</section>

<!-- Temple List Section -->
<section class="temple-list-section">
    <div class="container">
        <div class="section-header text-center mb-5">
            <h2 style="font-size: 36px; font-weight: 900; color: #1f2937;">Explore Sacred Temples</h2>
            <p style="color: #6b7280; max-width: 600px; margin: 10px auto;">Choose from our network of verified temples
                for your puja.</p>
        </div>

        <div class="temple-grid">
            <?php if ($temples_result && $temples_result->num_rows > 0): ?>
                <?php
                $count = 0;
                while ($temple = $temples_result->fetch_assoc()):
                    $count++;
                    $delay = ($count % 3) * 100;

                    // Placeholder images based on ID to give variety
                    $images = [
                        'https://images.unsplash.com/photo-1561361513-2d000a50f0dc?q=80&w=2076&auto=format&fit=crop',
                        'https://images.unsplash.com/photo-1623945205686-2619732158d7?q=80&w=1974&auto=format&fit=crop',
                        'https://images.unsplash.com/photo-1542622320-e7456db9783f?q=80&w=1974&auto=format&fit=crop',
                        'https://images.unsplash.com/photo-1590077423771-7958f3d04494?q=80&w=1974&auto=format&fit=crop'
                    ];
                    $bg_image = $images[$temple['id'] % count($images)];
                    ?>
                    <div class="temple-card animated fade-in-up" style="animation-delay: <?php echo $delay; ?>ms;">
                        <div class="temple-image-wrapper">
                            <img src="<?php echo $bg_image; ?>" alt="<?php echo htmlspecialchars($temple['name']); ?>">
                            <div class="temple-overlay">
                                <div class="temple-location">
                                    <i class="fas fa-map-marker-alt"></i>
                                    <?php echo htmlspecialchars($temple['city'] . ', ' . $temple['state']); ?>
                                </div>
                            </div>
                        </div>
                        <div class="temple-content">
                            <h3><?php echo htmlspecialchars($temple['name']); ?></h3>
                            <p><?php echo htmlspecialchars(substr($temple['description'], 0, 100)) . '...'; ?></p>

                            <div class="temple-features">
                                <span class="feature-tag">Ancient</span>
                                <span class="feature-tag">Powerful</span>
                            </div>

                            <a href="<?php echo SITE_URL; ?>/book-puja.php?type=temple&temple_id=<?php echo $temple['id']; ?>"
                                class="btn-book-temple">
                                Book Puja Here <i class="fas fa-arrow-right" style="margin-left: 5px;"></i>
                            </a>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="col-12 text-center">
                    <p>No temples available at the moment.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<link rel="stylesheet" href="assets/css/temple-services-premium.css">

<!-- Temple Services Section -->
<section class="temple-services-section">
    <div class="container">
        <div class="section-header text-center">
            <h2 style="font-size: 36px; font-weight: 900; color: #1f2937;">Our Temple Services</h2>
            <p style="color: #6b7280; max-width: 600px; margin: 10px auto;">Beyond simple darshan, we offer
                comprehensive spiritual services to fulfill your devotional needs.</p>
        </div>

        <div class="services-grid-new">
            <div class="service-card-new">
                <div class="service-icon-box">
                    <i class="fas fa-fire"></i>
                </div>
                <h4>Special Homas</h4>
                <p>Perform sacred fire rituals like Ganapati Homa, Navagraha Homa, and more for peace and prosperity.
                </p>
            </div>
            <div class="service-card-new">
                <div class="service-icon-box">
                    <i class="fas fa-water"></i>
                </div>
                <h4>Abhishekam</h4>
                <p>Offer sacred baths to deities with milk, honey, and holy water to wash away sins and bring purity.
                </p>
            </div>
            <div class="service-card-new">
                <div class="service-icon-box">
                    <i class="fas fa-utensils"></i>
                </div>
                <h4>Annadanam</h4>
                <p>Participate in the noble act of feeding devotees. Your contribution ensures no one goes hungry.</p>
            </div>
            <div class="service-card-new">
                <div class="service-icon-box">
                    <i class="fas fa-music"></i>
                </div>
                <h4>Bhajan Seva</h4>
                <p>Sponsor devotional singing sessions to create a divine atmosphere and spread positive vibrations.</p>
            </div>
        </div>
    </div>
</section>

<!-- Upcoming Festivals Section -->
<section class="festivals-section">
    <div class="container">
        <div class="section-header text-center">
            <h2 style="font-size: 36px; font-weight: 900; color: #1f2937;">Upcoming Festivals</h2>
            <p style="color: #6b7280; max-width: 600px; margin: 10px auto;">Join us in celebrating the grand festivals
                of the season.</p>
        </div>

        <div class="festival-timeline">
            <div class="festival-item">
                <div class="festival-dot"></div>
                <div class="festival-content">
                    <span class="festival-date">Oct 24, 2025</span>
                    <h4>Diwali - Festival of Lights</h4>
                    <p>Grand Lakshmi Puja and lighting of 100,000 diyas at Kashi Vishwanath Temple.</p>
                </div>
            </div>
            <div class="festival-item">
                <div class="festival-dot"></div>
                <div class="festival-content">
                    <span class="festival-date">Nov 15, 2025</span>
                    <h4>Kartik Purnima</h4>
                    <p>Special river Ganga Aarti and Dev Deepawali celebrations in Varanasi.</p>
                </div>
            </div>
            <div class="festival-item">
                <div class="festival-dot"></div>
                <div class="festival-content">
                    <span class="festival-date">Jan 14, 2026</span>
                    <h4>Makar Sankranti</h4>
                    <p>Harvest festival celebrations with special Surya Puja and Pongal offerings.</p>
                </div>
            </div>
            <div class="festival-item">
                <div class="festival-dot"></div>
                <div class="festival-content">
                    <span class="festival-date">Mar 08, 2026</span>
                    <h4>Maha Shivaratri</h4>
                    <p>All-night vigil and Rudrabhishekam for Lord Shiva at all major Jyotirlingas.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Darshan Timings Section -->
<section class="timings-section">
    <div class="container">
        <h2 style="font-size: 36px; font-weight: 900; color: #fff; margin-bottom: 10px;">General Darshan Timings</h2>
        <p style="color: #9ca3af; max-width: 600px; margin: 0 auto;">Plan your visit accordingly. Timings may vary
            during festivals.</p>

        <div class="timings-grid">
            <div class="timing-card">
                <i class="fas fa-sun"></i>
                <h4>Morning</h4>
                <p>05:00 AM - 12:00 PM</p>
            </div>
            <div class="timing-card">
                <i class="fas fa-moon"></i>
                <h4>Evening</h4>
                <p>04:00 PM - 09:00 PM</p>
            </div>
            <div class="timing-card">
                <i class="fas fa-bell"></i>
                <h4>Aarti</h4>
                <p>06:00 AM & 07:00 PM</p>
            </div>
        </div>
    </div>
</section>

<?php
$conn->close();
include 'includes/footer.php';
?>