<?php
require_once 'config/config.php';

$message = '';
$message_type = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitize($_POST['name'] ?? '');
    $email = sanitize($_POST['email'] ?? '');
    $phone = sanitize($_POST['phone'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($name && $email && $phone && $password) {
        $conn = getDBConnection();

        // Ensure users table exists
        $conn->query("CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            email VARCHAR(255) NOT NULL UNIQUE,
            phone VARCHAR(25) NOT NULL,
            password VARCHAR(255) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        // Check email unique
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ? LIMIT 1");
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $res = $stmt->get_result();
        if ($res && $res->num_rows > 0) {
            $message = 'Email already registered. Please sign in.';
            $message_type = 'error';
        } else {
            $hash = password_hash($password, PASSWORD_BCRYPT);
            $stmt2 = $conn->prepare("INSERT INTO users (name, email, phone, password) VALUES (?, ?, ?, ?)");
            $stmt2->bind_param('ssss', $name, $email, $phone, $hash);
            if ($stmt2->execute()) {
                $_SESSION['user_id'] = $stmt2->insert_id;
                $_SESSION['user_name'] = $name;
                redirect('/index.php');
            } else {
                $message = 'Unable to sign up. Please try again.';
                $message_type = 'error';
            }
            $stmt2->close();
        }
        $stmt->close();
        $conn->close();
    } else {
        $message = 'Please fill all required fields.';
        $message_type = 'error';
    }
}

$page_title = 'Sign Up - Puja Services';
include 'includes/header.php';
?>

<link rel="stylesheet" href="assets/css/auth-premium.css">

<!-- Hero Section -->
<section class="auth-hero">
    <div class="container">
        <h1>Join Our Community</h1>
        <p>Create an account to book pujas, track services, and receive divine blessings.</p>
    </div>
</section>

<section class="auth-section">
    <div class="auth-container">

        <?php if ($message): ?>
            <div class="alert <?php echo $message_type === 'error' ? 'alert-error' : 'alert-success'; ?>">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <div class="auth-form-card">
            <div class="form-header">
                <h3>Create Account</h3>
            </div>
            <form method="POST" action="">
                <div class="form-group">
                    <label>Full Name</label>
                    <input type="text" name="name" required placeholder="Enter your full name">
                </div>

                <div class="form-group">
                    <label>Email Address</label>
                    <input type="email" name="email" required placeholder="email@example.com">
                </div>

                <div class="form-group">
                    <label>Phone Number</label>
                    <input type="tel" name="phone" required placeholder="Your phone number">
                </div>

                <div class="form-group">
                    <label>Password</label>
                    <div class="password-wrapper">
                        <input type="password" id="signupPassword" name="password" required
                            placeholder="Create a strong password">
                        <i class="fas fa-eye password-toggle" onclick="togglePassword('signupPassword', this)"></i>
                    </div>
                </div>

                <button type="submit" class="btn-auth">
                    <span>Sign Up</span>
                    <i class="fas fa-user-plus"></i>
                </button>
            </form>

            <div class="auth-footer">
                Already have an account? <a href="<?php echo SITE_URL; ?>/signin.php">Sign In</a>
            </div>
        </div>
    </div>
</section>

<style>
.password-wrapper {
    position: relative;
}

.password-toggle {
    position: absolute;
    right: 15px;
    top: 50%;
    transform: translateY(-50%);
    cursor: pointer;
    color: #6b7280;
    transition: color 0.3s ease;
    font-size: 16px;
}

.password-toggle:hover {
    color: var(--primary-crimson);
}

.password-wrapper input {
    padding-right: 45px;
}
</style>

<script>
function togglePassword(inputId, icon) {
    const input = document.getElementById(inputId);
    if (input.type === 'password') {
        input.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        input.type = 'password';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    }
}
</script>

<?php include 'includes/footer.php'; ?>