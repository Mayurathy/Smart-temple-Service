<?php
require_once 'config/config.php';
$page_title = 'Temple Products - Puja Services';

$conn = getDBConnection();

// Get category filter
$category_filter = isset($_GET['category']) ? sanitize($_GET['category']) : 'all';

// Build query
if ($category_filter === 'all') {
    $query = "SELECT * FROM products WHERE status = 'active' ORDER BY name ASC";
    $stmt = $conn->prepare($query);
} else {
    $query = "SELECT * FROM products WHERE status = 'active' AND category = ? ORDER BY name ASC";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('s', $category_filter);
}

$stmt->execute();
$products_result = $stmt->get_result();
$stmt->close();

include 'includes/header.php';
?>

<link rel="stylesheet" href="assets/css/products-premium.css">

<!-- Hero Section -->
<section class="products-hero">
    <div class="container">
        <h1>Temple Products Store</h1>
        <p>Sacred items for your puja and spiritual needs</p>
    </div>
</section>

<!-- Category Filter -->
<section class="category-filter-section">
    <div class="container">
        <div class="category-buttons">
            <a href="?category=all" class="category-btn <?php echo $category_filter === 'all' ? 'active' : ''; ?>">All
                Products</a>
            <a href="?category=puja_items"
                class="category-btn <?php echo $category_filter === 'puja_items' ? 'active' : ''; ?>">Puja Items</a>
            <a href="?category=prasad"
                class="category-btn <?php echo $category_filter === 'prasad' ? 'active' : ''; ?>">Prasad</a>
            <a href="?category=devotional"
                class="category-btn <?php echo $category_filter === 'devotional' ? 'active' : ''; ?>">Devotional</a>
            <a href="?category=miscellaneous"
                class="category-btn <?php echo $category_filter === 'miscellaneous' ? 'active' : ''; ?>">Miscellaneous</a>
        </div>
    </div>
</section>

<!-- Products Grid -->
<section class="products-section">
    <div class="container">
        <?php if ($products_result && $products_result->num_rows > 0): ?>
            <div class="products-grid">
                <?php while ($product = $products_result->fetch_assoc()): ?>
                    <div class="product-card">
                        <div class="product-image">
                            <?php if ($product['image']): ?>
                                <img src="<?php echo htmlspecialchars($product['image']); ?>"
                                    alt="<?php echo htmlspecialchars($product['name']); ?>">
                            <?php else: ?>
                                <div class="placeholder-image">
                                    <i class="fas fa-shopping-bag"></i>
                                </div>
                            <?php endif; ?>
                            <?php if ($product['stock_status'] === 'out_of_stock'): ?>
                                <span class="out-of-stock-badge">Out of Stock</span>
                            <?php elseif ($product['stock_status'] === 'seasonal'): ?>
                                <span class="seasonal-badge">Seasonal</span>
                            <?php endif; ?>
                        </div>
                        <div class="product-info">
                            <span
                                class="product-category"><?php echo ucfirst(str_replace('_', ' ', $product['category'])); ?></span>
                            <h3><?php echo htmlspecialchars($product['name']); ?></h3>
                            <p class="product-desc">
                                <?php echo htmlspecialchars(substr($product['description'], 0, 80)) . '...'; ?></p>
                            <?php if ($product['quantity_unit']): ?>
                                <p class="product-unit"><?php echo htmlspecialchars($product['quantity_unit']); ?></p>
                            <?php endif; ?>
                            <div class="product-footer">
                                <span class="product-price">₹<?php echo number_format($product['price'], 2); ?></span>
                                <?php if ($product['stock_status'] === 'in_stock' || $product['stock_status'] === 'seasonal'): ?>
                                    <button class="btn-add-cart" onclick="addToCart(<?php echo $product['id']; ?>)">
                                        <i class="fas fa-shopping-cart"></i> Add to Cart
                                    </button>
                                <?php else: ?>
                                    <button class="btn-add-cart disabled" disabled>Unavailable</button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        <?php else: ?>
            <div class="no-products">
                <i class="fas fa-box-open"></i>
                <h3>No products found</h3>
                <p>Check back soon for new items!</p>
            </div>
        <?php endif; ?>
    </div>
</section>

<script>
    function addToCart(productId) {
        fetch('add-to-cart.php?product_id=' + productId)
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Product added to cart!');
                } else {
                    alert('Failed to add product to cart');
                }
            });
    }
</script>

<?php
$conn->close();
include 'includes/footer.php';
?>