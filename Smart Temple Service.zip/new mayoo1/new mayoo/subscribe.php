<?php
require_once 'config/config.php';

$conn = getDBConnection();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = sanitize($_POST['email']);
    
    $check_query = "SELECT id FROM subscribers WHERE email = ?";
    $stmt = $conn->prepare($check_query);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows == 0) {
        $insert_query = "INSERT INTO subscribers (email) VALUES (?)";
        $stmt2 = $conn->prepare($insert_query);
        $stmt2->bind_param("s", $email);
        $stmt2->execute();
        $stmt2->close();
    }
    $stmt->close();
}

redirect('/index.php');

