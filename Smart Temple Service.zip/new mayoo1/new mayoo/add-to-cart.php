<?php
session_start();
header('Content-Type: application/json');

require_once 'config/config.php';

if (!isset($_SESSION['product_cart'])) {
    $_SESSION['product_cart'] = [];
}

$product_id = isset($_GET['product_id']) ? intval($_GET['product_id']) : 0;

if ($product_id > 0) {
    // Add or increment quantity
    if (isset($_SESSION['product_cart'][$product_id])) {
        $_SESSION['product_cart'][$product_id]++;
    } else {
        $_SESSION['product_cart'][$product_id] = 1;
    }

    echo json_encode(['success' => true, 'message' => 'Product added to cart']);
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid product ID']);
}
?>