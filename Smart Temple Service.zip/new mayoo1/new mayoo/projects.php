<?php
require_once 'config/config.php';
$page_title = 'Our Projects - Temple Services';
include 'includes/header.php';
?>

<link rel="stylesheet" href="assets/css/projects-premium.css">

<!-- Hero Section -->
<section class="projects-hero">
    <div class="container">
        <h1>Our Temple Projects</h1>
        <p>Discover our sacred initiatives and temple development programs</p>
    </div>
</section>

<!-- Projects Grid -->
<section class="projects-section">
    <div class="container">
        <div class="projects-grid">
            
            <!-- Project 1 -->
            <div class="project-card">
                <div class="project-image">
                    <img src="assets/projects/temple-construction.png" alt="Temple Construction">
                    <div class="project-overlay">
                        <span class="project-status ongoing">Ongoing</span>
                    </div>
                </div>
                <div class="project-content">
                    <h3>New Temple Construction</h3>
                    <p class="project-location"><i class="fas fa-map-marker-alt"></i> Hyderabad, Telangana</p>
                    <p class="project-desc">Building a magnificent new temple complex with modern facilities while preserving traditional architecture.</p>
                    <div class="project-meta">
                        <div class="meta-item">
                            <i class="fas fa-calendar"></i>
                            <span>Started: Jan 2024</span>
                        </div>
                        <div class="meta-item">
                            <i class="fas fa-chart-line"></i>
                            <span>Progress: 65%</span>
                        </div>
                    </div>
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: 65%"></div>
                    </div>
                </div>
            </div>

            <!-- Project 2 -->
            <div class="project-card">
                <div class="project-image">
                    <img src="assets/projects/temple-restoration.png" alt="Temple Renovation">
                    <div class="project-overlay">
                        <span class="project-status completed">Completed</span>
                    </div>
                </div>
                <div class="project-content">
                    <h3>Ancient Temple Restoration</h3>
                    <p class="project-location"><i class="fas fa-map-marker-alt"></i> Tirupati, Andhra Pradesh</p>
                    <p class="project-desc">Successfully restored the 500-year-old temple gopuram and sanctum with traditional craftsmanship.</p>
                    <div class="project-meta">
                        <div class="meta-item">
                            <i class="fas fa-calendar"></i>
                            <span>Completed: Dec 2023</span>
                        </div>
                        <div class="meta-item">
                            <i class="fas fa-check-circle"></i>
                            <span>₹2.5 Cr Investment</span>
                        </div>
                    </div>
                    <div class="progress-bar">
                        <div class="progress-fill completed" style="width: 100%"></div>
                    </div>
                </div>
            </div>

            <!-- Project 3 -->
            <div class="project-card">
                <div class="project-image">
                    <img src="assets/projects/community-kitchen.png" alt="Community Kitchen">
                    <div class="project-overlay">
                        <span class="project-status ongoing">Ongoing</span>
                    </div>
                </div>
                <div class="project-content">
                    <h3>Annadanam Community Kitchen</h3>
                    <p class="project-location"><i class="fas fa-map-marker-alt"></i> Chennai, Tamil Nadu</p>
                    <p class="project-desc">Establishing a modern kitchen facility to feed 5000+ devotees daily with prasad and meals.</p>
                    <div class="project-meta">
                        <div class="meta-item">
                            <i class="fas fa-calendar"></i>
                            <span>Started: Mar 2024</span>
                        </div>
                        <div class="meta-item">
                            <i class="fas fa-chart-line"></i>
                            <span>Progress: 80%</span>
                        </div>
                    </div>
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: 80%"></div>
                    </div>
                </div>
            </div>

            <!-- Project 4 -->
            <div class="project-card">
                <div class="project-image">
                    <img src="assets/projects/digital-temple.png" alt="Digital Temple">
                    <div class="project-overlay">
                        <span class="project-status planning">Planning</span>
                    </div>
                </div>
                <div class="project-content">
                    <h3>Digital Temple Services Platform</h3>
                    <p class="project-location"><i class="fas fa-map-marker-alt"></i> Pan India</p>
                    <p class="project-desc">Creating an integrated digital platform for online darshan, virtual pujas, and temple bookings nationwide.</p>
                    <div class="project-meta">
                        <div class="meta-item">
                            <i class="fas fa-calendar"></i>
                            <span>Launch: Q4 2024</span>
                        </div>
                        <div class="meta-item">
                            <i class="fas fa-chart-line"></i>
                            <span>Progress: 30%</span>
                        </div>
                    </div>
                    <div class="progress-bar">
                        <div class="progress-fill planning" style="width: 30%"></div>
                    </div>
                </div>
            </div>

            <!-- Project 5 -->
            <div class="project-card">
                <div class="project-image">
                    <img src="assets/projects/vedic-education.png" alt="Education Center">
                    <div class="project-overlay">
                        <span class="project-status ongoing">Ongoing</span>
                    </div>
                </div>
                <div class="project-content">
                    <h3>Vedic Education Center</h3>
                    <p class="project-location"><i class="fas fa-map-marker-alt"></i> Varanasi, Uttar Pradesh</p>
                    <p class="project-desc">Building a comprehensive center for teaching Vedic scriptures, Sanskrit, and traditional arts to students.</p>
                    <div class="project-meta">
                        <div class="meta-item">
                            <i class="fas fa-calendar"></i>
                            <span>Started: Jun 2024</span>
                        </div>
                        <div class="meta-item">
                            <i class="fas fa-chart-line"></i>
                            <span>Progress: 45%</span>
                        </div>
                    </div>
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: 45%"></div>
                    </div>
                </div>
            </div>

            <!-- Project 6 -->
            <div class="project-card">
                <div class="project-image">
                    <img src="assets/projects/water-conservation.png" alt="Water Conservation">
                    <div class="project-overlay">
                        <span class="project-status completed">Completed</span>
                    </div>
                </div>
                <div class="project-content">
                    <h3>Temple Water Conservation</h3>
                    <p class="project-location"><i class="fas fa-map-marker-alt"></i> Madurai, Tamil Nadu</p>
                    <p class="project-desc">Implemented rainwater harvesting and sustainable water management system for temple complex.</p>
                    <div class="project-meta">
                        <div class="meta-item">
                            <i class="fas fa-calendar"></i>
                            <span>Completed: Sep 2023</span>
                        </div>
                        <div class="meta-item">
                            <i class="fas fa-check-circle"></i>
                            <span>₹75 Lakh Investment</span>
                        </div>
                    </div>
                    <div class="progress-bar">
                        <div class="progress-fill completed" style="width: 100%"></div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>