<?php
require_once 'config/config.php';

$conn = getDBConnection();
$message = '';
$message_type = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_name = sanitize($_POST['user_name']);
    $user_email = sanitize($_POST['user_email']);
    $user_phone = sanitize($_POST['user_phone']);
    // Convert empty values to NULL to satisfy FK constraints
    $puja_id = (!empty($_POST['puja_id']) && intval($_POST['puja_id']) > 0) ? intval($_POST['puja_id']) : null;
    $temple_id = (!empty($_POST['temple_id']) && intval($_POST['temple_id']) > 0) ? intval($_POST['temple_id']) : null;
    $priest_id = (!empty($_POST['priest_id']) && intval($_POST['priest_id']) > 0) ? intval($_POST['priest_id']) : null;
    $booking_type = sanitize($_POST['booking_type']);
    $booking_date = sanitize($_POST['booking_date']);
    $booking_time = sanitize($_POST['booking_time']);
    $address = sanitize($_POST['address']);
    $special_requests = sanitize($_POST['special_requests']);
    $booking_id = generateBookingId();
    // Validation
    if (!filter_var($user_email, FILTER_VALIDATE_EMAIL)) {
        $message = "Please enter a valid email address.";
        $message_type = 'error';
    } elseif (strtotime($booking_date) < strtotime(date('Y-m-d'))) {
        $message = "Booking date cannot be in the past.";
        $message_type = 'error';
    } else {
        // Extra safety: validate that referenced rows exist, otherwise set NULL
        if ($puja_id) {
            $chk = $conn->prepare("SELECT id FROM pujas WHERE id = ?");
            $chk->bind_param('i', $puja_id);
            $chk->execute();
            $r = $chk->get_result();
            if (!$r || $r->num_rows === 0) { $puja_id = null; }
            $chk->close();
        }
        if ($temple_id) {
            $chk = $conn->prepare("SELECT id FROM temples WHERE id = ?");
            $chk->bind_param('i', $temple_id);
            $chk->execute();
            $r = $chk->get_result();
            if (!$r || $r->num_rows === 0) { $temple_id = null; }
            $chk->close();
        }
        if ($priest_id) {
            $chk = $conn->prepare("SELECT id FROM priests WHERE id = ?");
            $chk->bind_param('i', $priest_id);
            $chk->execute();
            $r = $chk->get_result();
            if (!$r || $r->num_rows === 0) { $priest_id = null; }
            $chk->close();
        }

        $insert_query = "INSERT INTO bookings (booking_id, user_name, user_email, user_phone, puja_id, temple_id, priest_id, booking_type, booking_date, booking_time, address, special_requests) 
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        $stmt = $conn->prepare($insert_query);
        $stmt->bind_param("ssssiiiissss", $booking_id, $user_name, $user_email, $user_phone, $puja_id, $temple_id, $priest_id, $booking_type, $booking_date, $booking_time, $address, $special_requests);
        
        if ($stmt->execute()) {
            $trackUrl = SITE_URL . '/track-booking.php?booking_id=' . urlencode($booking_id);
            $message = "Booking successful! Your Booking ID is: <strong>" . $booking_id . "</strong>. We will contact you soon. <br><a class=\"btn\" href=\"" . $trackUrl . "\" style=\"margin-top:10px; display:inline-block;\">Track this Booking</a>";
            $message_type = 'success';
        } else {
            $message = "Error: " . $conn->error;
            $message_type = 'error';
        }
        $stmt->close();
    }
    

}

// Get puja details if puja_id is provided
$puja = null;
$temple = null;
$priest = null;
$booking_type = isset($_GET['type']) ? $_GET['type'] : 'home';

if (isset($_GET['puja_id'])) {
    $puja_id = intval($_GET['puja_id']);
    $puja_query = "SELECT * FROM pujas WHERE id = ?";
    $stmt = $conn->prepare($puja_query);
    $stmt->bind_param("i", $puja_id);
    $stmt->execute();
    $puja_result = $stmt->get_result();
    if ($puja_result->num_rows > 0) {
        $puja = $puja_result->fetch_assoc();
        $booking_type = 'home';
    }
    $stmt->close();
}
if (isset($_GET['temple_id'])) {
    $temple_id = intval($_GET['temple_id']);
    $temple_query = "SELECT * FROM temples WHERE id = ?";
    $stmt = $conn->prepare($temple_query);
    $stmt->bind_param("i", $temple_id);
    $stmt->execute();
    $temple_result = $stmt->get_result();
    if ($temple_result->num_rows > 0) {
        $temple = $temple_result->fetch_assoc();
        $booking_type = 'temple';
    }
    $stmt->close();
}
if (isset($_GET['priest_id'])) {
    $priest_id = intval($_GET['priest_id']);
    $priest_query = "SELECT * FROM priests WHERE id = ?";
    $stmt = $conn->prepare($priest_query);
    $stmt->bind_param("i", $priest_id);
    $stmt->execute();
    $priest_result = $stmt->get_result();
    if ($priest_result->num_rows > 0) {
        $priest = $priest_result->fetch_assoc();
        $booking_type = 'home';
    }
    $stmt->close();
}
$page_title = 'Book Puja - Puja Services';
include 'includes/header.php';
?>
<link rel="stylesheet" href="<?php echo SITE_URL; ?>/assets/css/book-puja-premium.css">

<!-- Hero Section -->
<section class="booking-hero">
    <div class="container">
        <h1>Complete Your Booking</h1>
        <p>You are just one step away from your divine experience. Secure your puja slot now.</p>
    </div>
</section>

<section class="booking-section">
    <div class="container">
        <?php if ($message): ?>
            <div class="<?php echo $message_type == 'success' ? 'success-message' : 'error-message'; ?>">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>
        
        <div class="booking-container">
            <!-- Left Column: Order Summary -->
            <div class="order-summary-column animated fade-in-up">
                <div class="order-summary-card">
                    <div class="summary-header">
                        <h3>Booking Summary</h3>
                    </div>
                    
                    <?php if ($puja): ?>
                        <div class="summary-item">
                            <h4>Selected Puja</h4>
                            <p><?php echo htmlspecialchars($puja['name']); ?></p>
                            <p class="price">₹<?php echo number_format($puja['price'], 2); ?></p>
                        </div>
                    <?php endif; ?>
                    
                    <?php if ($temple): ?>
                        <div class="summary-item">
                            <h4>Temple Location</h4>
                            <p><strong><?php echo htmlspecialchars($temple['name']); ?></strong></p>
                            <p><i class="fas fa-map-marker-alt"></i> <?php echo htmlspecialchars($temple['location']); ?></p>
                        </div>
                    <?php endif; ?>
                    
                    <?php if ($priest): ?>
                        <div class="summary-item">
                            <h4>Priest Details</h4>
                            <p><strong><?php echo htmlspecialchars($priest['name']); ?></strong></p>
                            <p>Experience: <?php echo $priest['experience']; ?> Years</p>
                        </div>
                    <?php endif; ?>
                    
                    <?php if (!$puja && !$temple && !$priest): ?>
                        <div class="summary-item">
                            <p>No specific service selected. You can proceed with a general booking.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Right Column: Booking Form -->
            <div class="booking-form-column animated fade-in-up delay-200">
                <div class="booking-form-card">
                    <div class="form-header">
                        <h2>Enter Your Details</h2>
                    </div>
                    
                    <form method="POST" action="">
                        <input type="hidden" name="puja_id" value="<?php echo $puja ? $puja['id'] : ''; ?>">
                        <input type="hidden" name="temple_id" value="<?php echo $temple ? $temple['id'] : ''; ?>">
                        <input type="hidden" name="priest_id" value="<?php echo $priest ? $priest['id'] : ''; ?>">
                        <input type="hidden" name="booking_type" value="<?php echo $booking_type; ?>">
                        
                        <div class="form-grid">
                            <div class="form-group">
                                <label>Full Name *</label>
                                <input type="text" name="user_name" required placeholder="e.g. Rahul Sharma">
                            </div>
                            
                            <div class="form-group">
                                <label>Email Address *</label>
                                <input type="email" name="user_email" required placeholder="rahul@example.com">
                            </div>
                            
                            <div class="form-group">
                                <label>Phone Number *</label>
                                <input type="tel" name="user_phone" required placeholder="+91 98765 43210">
                            </div>
                            
                            <div class="form-group">
                                <label>Booking Date *</label>
                                <input type="date" name="booking_date" required min="<?php echo date('Y-m-d'); ?>">
                            </div>
                            
                            <div class="form-group">
                                <label>Preferred Time *</label>
                                <input type="time" name="booking_time" required>
                            </div>
                        </div>
                        
                        <?php if ($booking_type == 'home' || $booking_type == 'priest'): ?>
                        <div class="form-group">
                            <label>Address for Ritual *</label>
                            <textarea name="address" required placeholder="Enter your full address with landmark" rows="3"></textarea>
                        </div>
                        <?php endif; ?>
                        
                        <div class="form-group">
                            <label>Special Requests / Sankalpa Details</label>
                            <textarea name="special_requests" placeholder="Any specific requirements or names for Sankalpa?" rows="3"></textarea>
                        </div>
                        
                        <button type="submit" class="btn-confirm">Confirm Booking</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<?php
$conn->close();
include 'includes/footer.php';
?>

