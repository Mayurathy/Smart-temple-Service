<?php
$page_title = isset($page_title) ? $page_title : 'Puja Services - Divine Blessings for Every Occasion';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>/assets/css/style.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>

<body>
    <!-- Green Top Bar -->
    <div class="green-bar"></div>

    <!-- Orange Top Bar -->
    <div class="orange-top-bar">
        <div class="container">
            <div class="orange-bar-content">
                <div class="whatsapp-info">
                    <a href="https://wa.me/919876543210" target="_blank"
                        style="display: flex; align-items: center; gap: 10px; color: white; text-decoration: none;">
                        <i class="fab fa-whatsapp"></i>
                        <span>TempleHub</span>
                    </a>
                </div>
                <div class="top-utility-icons">
                    <a href="<?php echo SITE_URL; ?>/search.php"><i class="fas fa-search"></i></a>
                    <a href="<?php echo SITE_URL; ?>/signin.php"><i class="fas fa-user"></i></a>
                    <a href="<?php echo SITE_URL; ?>/products.php"><i class="fas fa-shopping-cart"></i></a>
                </div>
            </div>
        </div>
    </div>

    <!-- Header Navigation -->
    <header class="main-header-new">
        <div class="container">
            <nav class="navbar-new">
                <div class="logo-new">
                    <a href="<?php echo SITE_URL; ?>/index.php">
                        <img class="logo-img" src="<?php echo SITE_URL; ?>/assets/logo/logotem.jpg" alt="TempleHub">
                        <div class="logo-text">
                            <span>TempleHub</span>
                        </div>
                    </a>
                </div>
                <ul class="nav-menu-new">
                    <li><a href="<?php echo SITE_URL; ?>/index.php">HOME</a></li>
                    <li><a href="<?php echo SITE_URL; ?>/about.php">ABOUT US</a></li>
                    <li><a href="<?php echo SITE_URL; ?>/services.php">SERVICES</a></li>
                    <li><a href="<?php echo SITE_URL; ?>/pujas.php">PUJAS</a></li>
                    <li><a href="<?php echo SITE_URL; ?>/temples.php">TEMPLES</a></li>
                    <li><a href="<?php echo SITE_URL; ?>/gallery.php">GALLERY</a></li>

                    <li><a href="<?php echo SITE_URL; ?>/contact.php">CONTACT US</a></li>
                    <li class="nav-more">
                        <a href="#">MORE</a>
                        <ul class="dropdown">
                            <li><a href="<?php echo SITE_URL; ?>/donation.php">DONATION</a></li>
                            <li><a href="<?php echo SITE_URL; ?>/gift-puja.php">GIFT A PUJA</a></li>
                            <li><a href="<?php echo SITE_URL; ?>/track-booking.php">TRACK BOOKING</a></li>
                        </ul>
                    </li>
                </ul>
                <div class="header-buttons">
                    <?php if (function_exists('isUserLoggedIn') && isUserLoggedIn()): ?>
                        <span style="margin-right: 10px; font-weight: 600; color: var(--dark-color);">Hi,
                            <?php echo htmlspecialchars(getLoggedInUserName()); ?></span>
                        <a href="<?php echo SITE_URL; ?>/logout-user.php" class="btn-signin">LOG OUT</a>
                    <?php else: ?>
                        <a href="<?php echo SITE_URL; ?>/signup.php" class="btn-signup">SIGN UP</a>
                        <a href="<?php echo SITE_URL; ?>/signin.php" class="btn-signin">SIGN IN</a>
                    <?php endif; ?>
                </div>
                <div class="hamburger">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </nav>
        </div>
    </header>