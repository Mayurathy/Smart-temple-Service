<!-- Footer -->
<footer class="main-footer">
    <div class="container">
        <div class="footer-content">
            <div class="footer-section">
                <h3>About Puja Services</h3>
                <p>Puja Services is the leading digital platform for all Hindu devotional needs and spiritual services.
                </p>
            </div>

            <div class="footer-section">
                <h3>Quick Links</h3>
                <ul>
                    <li><a href="<?php echo SITE_URL; ?>/services.php?type=online">Online Puja Booking</a></li>
                    <li><a href="<?php echo SITE_URL; ?>/services.php?type=temple">Temple Puja Booking</a></li>
                    <li><a href="<?php echo SITE_URL; ?>/services.php?type=priest">Priest Booking</a></li>
                    <li><a href="<?php echo SITE_URL; ?>/gift-puja.php">Vedic Ashirvaad</a></li>
                    <li><a href="<?php echo SITE_URL; ?>/contact.php">Contact Us</a></li>
                </ul>
            </div>

            <div class="footer-section">
                <h3>Pujas</h3>
                <ul>
                    <li><a href="<?php echo SITE_URL; ?>/puja-details.php?slug=sri-sathyanarayana-vratham">Sri
                            Sathyanarayana Vratham</a></li>
                    <li><a href="<?php echo SITE_URL; ?>/puja-details.php?slug=sri-kedareshwara-swamy-vratham">Sri
                            Kedareshwara Swamy Vratham</a></li>
                </ul>
            </div>

            <div class="footer-section">
                <h3>Subscribe for Divine Updates!</h3>
                <p>Stay informed about upcoming pujas, spiritual insights, and special blessings.</p>
                <form class="subscribe-form" action="<?php echo SITE_URL; ?>/subscribe.php" method="POST">
                    <input type="email" name="email" placeholder="Enter your email" required>
                    <button type="submit">Subscribe</button>
                </form>
            </div>
        </div>

        <div class="footer-bottom">
            <p>Copyrights © <?php echo date('Y'); ?> Puja Services</p>
            <div class="footer-links">
                <a href="<?php echo SITE_URL; ?>/privacy.php">Privacy</a>
                <a href="<?php echo SITE_URL; ?>/terms.php">Terms And Conditions</a>
                <a href="<?php echo SITE_URL; ?>/contact.php">Contact Us</a>
            </div>
        </div>
    </div>
</footer>

<script src="<?php echo SITE_URL; ?>/assets/js/main.js"></script>

<!-- Premium Chatbot -->
<link rel="stylesheet" href="<?php echo SITE_URL; ?>/assets/css/chat-premium.css">
<script src="<?php echo SITE_URL; ?>/assets/js/chat-premium.js"></script>
</body>

</html>