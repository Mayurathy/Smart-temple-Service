# Image Upload Feature for Pujas - Implementation Guide

## ✅ What's Been Added

I've successfully added image upload functionality to your Pujas management system! Here's what's new:

### 1. **Database Support**
- Added `category` column to store puja categories (Wealth, Health, Marriage, Dosha)
- The `image` column already exists in your database schema

### 2. **Admin Panel Updates** (admin/pujas.php)
- ✅ **Image Upload Field**: Upload images directly from the admin form
- ✅ **Category Dropdown**: Assign categories to each puja
- ✅ **Image Preview**: View current image when editing a puja
- ✅ **File Validation**: Only JPG, PNG, and WEBP files allowed
- ✅ **Auto Directory Creation**: Creates `assets/images/pujas/` folder automatically

### 3. **File Upload Features**
- Secure file upload with type validation
- Automatic file naming (slug-timestamp.extension)
- Graceful handling of updates (keeps old image if no new one uploaded)
- Proper error messages for upload failures

---

## 📝 How to Use

### Step 1: Run the Migration
First, you need to add the category column to your database:

**Option A: Via Browser**
1. Open your browser
2. Navigate to: `http://localhost/new%20mayoo1/new%20mayoo/migrations/run_add_category.php`
3. You'll see a success message

**Option B: Via phpMyAdmin**
1. Open phpMyAdmin
2. Select your `puja_services` database
3. Go to SQL tab
4. Run this query:
```sql
ALTER TABLE pujas ADD COLUMN category VARCHAR(50) DEFAULT 'wealth' AFTER price;
UPDATE pujas SET category = 'wealth' WHERE category IS NULL OR category = '';
```

### Step 2: Add/Edit Pujas with Images

1. **Go to Admin Panel**: Navigate to `http://localhost/new%20mayoo1/new%20mayoo/admin/pujas.php`
2. **Click "Add New Puja"** or **Edit** an existing puja
3. **Fill in the form**:
   - **Name**: Enter the puja name (e.g., "Ganesh Puja")
   - **Category**: Select from Wealth, Health, Marriage, or Dosha
   - **Puja Image**: Click "Choose File" and upload an image
   - Fill in other fields (Description, Significance, etc.)
   - **Price**: Enter the price
4. **Click Submit**

### Step 3: View Your Pujas
Visit `http://localhost/new%20mayoo1/new%20mayoo/pujas.php` to see your pujas with images!

---

## 🎨 Image Guidelines

### Recommended Image Specifications:
- **Format**: JPG, PNG, or WEBP
- **Dimensions**: 400x300 pixels (or 4:3 ratio)
- **Size**: Under 500KB for fast loading
- **Content**: Clear images of deities, rituals, or temple scenes

### Where to Find Images:
1. **Free Stock Photos**:
   - [Unsplash](https://unsplash.com) - Search for "hindu deity", "puja", "temple"
   - [Pexels](https://pexels.com) - Search for religious/spiritual images
   - [Pixabay](https://pixabay.com) - Free Hindu deity images

2. **Create Your Own**: Use AI image generation below!

---

## 🖼️ Sample Image Suggestions

For each category, here are some theme suggestions:

### Wealth Category (Lakshmi, Kubera)
- Golden colors, coins, prosperity symbols
- Lakshmi Puja, Kubera Puja, Diwali Puja

### Health Category (Dhanvantari, Ayurveda)
- Green/healing colors, herbs, wellness symbols
- Maha Mrityunjaya Puja, Dhanvantari Puja

### Marriage Category (Wedding rituals)
- Red/pink colors, couples, marriage symbols
- Swayamvara Parvati Puja, Vivaha Puja

### Dosha Category (Planetary remedies)
- Dark/cosmic colors, planets, protection symbols
- Navagraha Puja, Kaal Sarp Dosha Puja, Rahu-Ketu Puja

---

## 🔧 Technical Details

### File Upload Security
- Type validation (only images allowed)
- Unique file naming prevents overwrites
- Files stored in: `assets/images/pujas/`
- Original filename not used (security)

### Database Fields
```sql
category VARCHAR(50)    -- 'wealth', 'health', 'marriage', 'dosha'
image VARCHAR(255)      -- filename (e.g., 'ganesh-puja-1703234567.jpg')
```

### Error Handling
- Invalid file type → Shows error message
- Upload failure → Shows error message, doesn't save puja
- Missing image → Uses placeholder image on frontend

---

## 🚀 Next Steps

1. ✅ Run the migration script
2. ✅ Upload images for your existing pujas
3. ✅ Test the category filtering on pujas.php

---

## 🐛 Troubleshooting

### "Failed to upload image"
- Check folder permissions (assets/images/pujas/ should be writable)
- Ensure file is under PHP's upload_max_filesize (usually 2MB)

### "Invalid image type"
- Only JPG, PNG, and WEBP are allowed
- Convert your image to one of these formats

### Category dropdown not showing saved value
- Make sure you ran the migration script first
- Check that the category column exists in your database

---

## 📞 Support

If you encounter any issues:
1. Check the browser console for JavaScript errors
2. Check PHP error logs
3. Verify database connection
4. Ensure all files have proper permissions

Happy managing your Pujas! 🙏
